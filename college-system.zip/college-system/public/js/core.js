/* =====================================================================
   النواة: الاتصال بالسيرفر، الجلسة، التوجيه، عناصر الواجهة، التزامن الفوري
   ===================================================================== */
(function () {
  const raw = window.__API_BASE__ || '';
  const API = raw.startsWith('__PORT_') ? '' : raw.replace(/\/$/, '');

  const ICONS = {
    home: '<path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><path d="M9 22V12h6v10"/>',
    book: '<path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/>',
    users: '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
    user: '<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
    bell: '<path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/>',
    chat: '<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>',
    inbox: '<polyline points="22 12 16 12 14 15 10 15 8 12 2 12"/><path d="M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z"/>',
    bot: '<rect x="3" y="11" width="18" height="10" rx="2"/><circle cx="12" cy="5" r="2"/><path d="M12 7v4"/><path d="M8 16h.01M16 16h.01"/>',
    sliders: '<path d="M4 21v-7M4 10V3M12 21v-9M12 8V3M20 21v-5M20 12V3M1 14h6M9 8h6M17 16h6"/>',
    logout: '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/>',
    login: '<path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"/><polyline points="10 17 15 12 10 7"/><line x1="15" y1="12" x2="3" y2="12"/>',
    check: '<polyline points="20 6 9 17 4 12"/>',
    x: '<line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>',
    plus: '<line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>',
    edit: '<path d="M12 20h9"/><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4Z"/>',
    trash: '<polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>',
    download: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/>',
    upload: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/>',
    file: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/>',
    clipboard: '<rect x="8" y="2" width="8" height="4" rx="1"/><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/><path d="m9 14 2 2 4-4"/>',
    chart: '<line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/>',
    building: '<rect x="4" y="2" width="16" height="20" rx="2"/><path d="M9 22v-4h6v4"/><path d="M8 6h.01M16 6h.01M12 6h.01M12 10h.01M12 14h.01M16 10h.01M16 14h.01M8 10h.01M8 14h.01"/>',
    shield: '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>',
    database: '<ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3"/><path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5"/>',
    history: '<path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5"/><path d="M12 7v5l4 2"/>',
    wifi: '<path d="M5 12.55a11 11 0 0 1 14.08 0"/><path d="M1.42 9a16 16 0 0 1 21.16 0"/><path d="M8.53 16.11a6 6 0 0 1 6.95 0"/><path d="M12 20h.01"/>',
    lock: '<rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>',
    unlock: '<rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 9.9-1"/>',
    send: '<line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/>',
    search: '<circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>',
    menu: '<line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="18" x2="21" y2="18"/>',
    key: '<circle cx="7.5" cy="15.5" r="5.5"/><path d="m21 2-9.6 9.6"/><path d="m15.5 7.5 3 3L22 7l-3-3"/>',
    eye: '<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/>',
    link: '<path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/>',
    alert: '<path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/>',
    grad: '<path d="M22 10 12 5 2 10l10 5 10-5z"/><path d="M6 12v5c3 3 9 3 12 0v-5"/>',
    pin: '<line x1="12" y1="17" x2="12" y2="22"/><path d="M5 17h14v-1.76a2 2 0 0 0-1.11-1.79l-1.78-.9A2 2 0 0 1 15 10.76V6h1a2 2 0 0 0 0-4H8a2 2 0 0 0 0 4h1v4.76a2 2 0 0 1-1.11 1.79l-1.78.9A2 2 0 0 0 5 15.24Z"/>',
    refresh: '<polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"/>',
    back: '<polyline points="9 18 15 12 9 6"/>',
    printer: '<polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="8"/>',
    help: '<circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17"/>',
    layers: '<polygon points="12 2 2 7 12 12 22 7 12 2"/><polyline points="2 17 12 22 22 17"/><polyline points="2 12 12 17 22 12"/>',
    monitor: '<rect x="2" y="3" width="20" height="14" rx="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/>',
    calendar: '<rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/>',
    star: '<polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>',
    mail: '<rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 7-10 5L2 7"/>',
    phone: '<path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.13.96.36 1.9.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.91.34 1.85.57 2.81.7A2 2 0 0 1 22 16.92z"/>',
    clock: '<circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>',
    arrowUp: '<line x1="12" y1="19" x2="12" y2="5"/><polyline points="5 12 12 5 19 12"/>',
    power: '<path d="M18.36 6.64a9 9 0 1 1-12.73 0"/><line x1="12" y1="2" x2="12" y2="12"/>',
  };
  const icon = (n, s = 18) => `<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICONS[n] || ''}</svg>`;

  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];

  const ROLE = { admin: 'رئيس القسم (الإدارة)', secretary: 'السكرتارية', faculty: 'تدريسي', student: 'طالب' };
  const STUDY = { morning: 'صباحي', evening: 'مسائي', both: 'صباحي ومسائي' };
  const ANN_CAT = { notice: 'تبليغ', rules: 'قوانين وتعليمات', exam: 'امتحانات', meeting: 'اجتماع', event: 'فعالية', circular: 'تعميم رسمي' };
  const PRIORITY = { normal: 'عادي', important: 'مهم', urgent: 'عاجل' };
  const MAT_CAT = { lecture: 'محاضرة', lab: 'مختبر/عملي', syllabus: 'مفردات المادة', assignment: 'واجب', exam: 'نماذج أسئلة', reference: 'مرجع', video: 'فيديو' };

  const state = { token: null, user: null, info: null, socket: null, online: false, unread: { ann: 0, dm: 0 }, departments: [], route: '', impersonating: false, defaultPassword: false };

  // ---------------- HTTP ----------------
  async function api(path, opts = {}) {
    const headers = { ...(opts.headers || {}) };
    if (state.token) headers.Authorization = `Bearer ${state.token}`;
    let body = opts.body;
    if (body && !(body instanceof FormData) && typeof body !== 'string') { headers['Content-Type'] = 'application/json'; body = JSON.stringify(body); }
    const res = await fetch(`${API}/api${path}`, { method: opts.method || (body ? 'POST' : 'GET'), headers, body, credentials: API ? 'omit' : 'same-origin' });
    let data = null;
    const ct = res.headers.get('content-type') || '';
    if (ct.includes('json')) data = await res.json(); else data = await res.text();
    if (!res.ok) {
      if (res.status === 401 && state.user && !opts.silent) { logout(true); }
      const err = new Error((data && data.error) || `خطأ ${res.status}`);
      err.status = res.status;
      throw err;
    }
    return data;
  }
  const get = (p) => api(p);
  const post = (p, b = {}) => api(p, { method: 'POST', body: b });
  const put = (p, b = {}) => api(p, { method: 'PUT', body: b });
  const del = (p) => api(p, { method: 'DELETE' });
  const fileUrl = (p) => `${API}/api${p}${p.includes('?') ? '&' : '?'}t=${encodeURIComponent(state.token || '')}`;
  const asset = (p) => (/^api\//.test(p) ? `${API}/${p}` : p);

  // ---------------- واجهة ----------------
  function toast(msg, type = 'ok', title) {
    const el = document.createElement('div');
    el.className = `toast ${type === 'error' ? 'error' : type === 'gold' ? 'gold' : ''}`;
    el.innerHTML = `${icon(type === 'error' ? 'alert' : type === 'gold' ? 'bell' : 'check', 18)}<div>${title ? `<b>${esc(title)}</b>` : ''}${esc(msg)}</div>`;
    $('#toasts').appendChild(el);
    setTimeout(() => { el.style.opacity = '0'; el.style.transition = 'opacity .3s'; setTimeout(() => el.remove(), 300); }, type === 'error' ? 5000 : 3200);
  }
  const fail = (e) => toast(e.message || String(e), 'error');

  function modal({ title, body, actions = [], wide = false, onOpen }) {
    return new Promise((resolve) => {
      const back = document.createElement('div');
      back.className = 'modal-back';
      back.innerHTML = `<div class="modal ${wide ? 'wide' : ''}" role="dialog" aria-modal="true" aria-label="${esc(title)}">
        <div class="modal-head"><h3>${esc(title)}</h3><button class="btn btn-ghost btn-icon x" data-x aria-label="إغلاق">${icon('x')}</button></div>
        <div class="modal-body"></div>
        ${actions.length ? '<div class="modal-foot"></div>' : ''}</div>`;
      const bodyEl = $('.modal-body', back);
      if (typeof body === 'string') bodyEl.innerHTML = body; else if (body) bodyEl.appendChild(body);
      const close = (v) => { back.remove(); document.removeEventListener('keydown', onKey); resolve(v); };
      const onKey = (e) => { if (e.key === 'Escape') close(null); };
      document.addEventListener('keydown', onKey);
      $('[data-x]', back).onclick = () => close(null);
      back.addEventListener('mousedown', (e) => { if (e.target === back) close(null); });
      const foot = $('.modal-foot', back);
      for (const a of actions) {
        const b = document.createElement('button');
        b.className = `btn ${a.cls || 'btn-ghost'}`;
        b.innerHTML = a.label;
        b.onclick = async () => {
          if (!a.onClick) return close(a.value ?? null);
          b.disabled = true;
          try { const r = await a.onClick(bodyEl, close); if (r !== false) close(r ?? a.value ?? true); } catch (e) { fail(e); } finally { b.disabled = false; }
        };
        foot.appendChild(b);
      }
      $('#modal-root').appendChild(back);
      const first = $('input, select, textarea', bodyEl);
      if (first) setTimeout(() => first.focus(), 30);
      onOpen && onOpen(bodyEl, close);
    });
  }
  const confirmBox = (title, text, okLabel = 'تأكيد', danger = true) => modal({
    title, body: `<p style="margin:0">${esc(text)}</p>`,
    actions: [{ label: okLabel, cls: danger ? 'btn-danger' : 'btn-primary', value: true }, { label: 'إلغاء', value: false }],
  }).then((v) => v === true);

  function formData(root) {
    const out = {};
    for (const el of $$('[name]', root)) {
      if (el.type === 'checkbox') out[el.name] = el.checked;
      else if (el.type === 'file') continue;
      else out[el.name] = el.value;
    }
    return out;
  }
  const opt = (v, label, sel) => `<option value="${esc(v)}" ${String(sel ?? '') === String(v) ? 'selected' : ''}>${esc(label)}</option>`;
  const deptOptions = (sel, empty = 'كل الأقسام') => (empty !== null ? opt('', empty, sel) : '') + state.departments.map((d) => opt(d.id, d.name, sel)).join('');
  const stageOptions = (sel, empty = 'كل المراحل') => (empty !== null ? opt('', empty, sel) : '') + [1, 2, 3, 4, 5, 6].slice(0, Number(state.info?.stages_count || 4)).map((s) => opt(s, `المرحلة ${['الأولى', 'الثانية', 'الثالثة', 'الرابعة', 'الخامسة', 'السادسة'][s - 1]}`, sel)).join('');
  const stageName = (s) => (s ? `المرحلة ${['الأولى', 'الثانية', 'الثالثة', 'الرابعة', 'الخامسة', 'السادسة'][s - 1] || s}` : '');
  const initials = (n) => String(n || '?').trim().split(/\s+/).slice(0, 2).map((w) => w[0]).join('');
  const fmtDate = (s) => (s ? String(s).slice(0, 10) : '');
  const fmtTime = (s) => (s ? String(s).slice(11, 16) : '');
  const fmtSize = (b) => (!b ? '' : b < 1024 * 1024 ? `${Math.round(b / 1024)} KB` : `${(b / 1048576).toFixed(1)} MB`);
  const progress = (pct, cls = '') => `<div class="progress ${cls}"><span style="width:${Math.max(0, Math.min(100, pct || 0))}%"></span></div>`;
  const empty = (title, text = '', ic = 'layers') => `<div class="empty">${icon(ic, 44)}<b>${esc(title)}</b>${esc(text)}</div>`;
  const skeleton = (n = 3) => `<div class="stack">${Array.from({ length: n }, () => '<div class="card card-pad"><div class="skeleton" style="width:40%;height:18px"></div><div class="skeleton" style="margin-top:12px;height:12px"></div><div class="skeleton" style="margin-top:8px;height:12px;width:70%"></div></div>').join('')}</div>`;
  const letterChip = (g) => (g && g.letter ? `<span class="letter ${esc(g.letter)}">${esc(g.letter)}</span>` : '');
  const attChip = (a) => (a.status === 'banned' ? '<span class="chip red">محروم</span>' : a.status === 'warning' ? '<span class="chip amber">إنذار</span>' : '<span class="chip teal">سليم</span>');
  function ring(value, max = 100, color = 'var(--teal-bright)') {
    const pct = max ? Math.max(0, Math.min(1, (value || 0) / max)) : 0;
    const c = 2 * Math.PI * 24;
    return `<div class="grade-ring"><svg width="56" height="56" viewBox="0 0 56 56"><circle cx="28" cy="28" r="24" fill="none" stroke="var(--line-2)" stroke-width="5"/><circle cx="28" cy="28" r="24" fill="none" stroke="${color}" stroke-width="5" stroke-linecap="round" stroke-dasharray="${c}" stroke-dashoffset="${c * (1 - pct)}"/></svg><b>${value == null ? '—' : Math.round(value)}</b></div>`;
  }
  function downloadText(name, text, mime = 'text/csv;charset=utf-8') {
    const blob = new Blob([text], { type: mime });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob); a.download = name; document.body.appendChild(a); a.click();
    setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 500);
  }

  // ---------------- التوجيه ----------------
  const routes = {};
  const route = (path, handler) => { routes[path] = handler; };
  function navigate(path) { if (location.hash !== `#${path}`) location.hash = path; else render(); }
  function currentPath() { return (location.hash || '#/').slice(1) || '/'; }

  function match(path) {
    for (const [pattern, handler] of Object.entries(routes)) {
      const keys = [];
      const re = new RegExp('^' + pattern.replace(/:(\w+)/g, (_, k) => { keys.push(k); return '([^/]+)'; }) + '$');
      const m = re.exec(path);
      if (m) return { handler, params: Object.fromEntries(keys.map((k, i) => [k, decodeURIComponent(m[i + 1])])) };
    }
    return null;
  }

  // ---------------- القوائم حسب الدور ----------------
  function navFor(role) {
    const N = (path, label, ic, badge) => ({ path, label, ic, badge });
    if (role === 'student') return [
      { group: null, items: [N('/', 'الرئيسية', 'home'), N('/my-courses', 'موادي الدراسية', 'book'), N('/announcements', 'التبليغات', 'bell', 'ann')] },
      { group: 'التواصل', items: [N('/chat', 'شات الدفعة', 'chat'), N('/secretary', 'مراسلة السكرتارية', 'inbox', 'dm'), N('/bot', 'المساعد الذكي', 'bot')] },
      { group: 'عام', items: [N('/faculty', 'الكادر التدريسي', 'grad'), N('/profile', 'حسابي', 'user')] },
    ];
    if (role === 'faculty') return [
      { group: null, items: [N('/', 'الرئيسية', 'home'), N('/teaching', 'موادي التدريسية', 'book'), N('/announcements', 'التبليغات', 'bell', 'ann')] },
      { group: 'التواصل', items: [N('/chat', 'شات الدفعات', 'chat'), N('/bot', 'المساعد الذكي', 'bot')] },
      { group: 'عام', items: [N('/faculty', 'الكادر التدريسي', 'grad'), N('/profile', 'ملفي الشخصي', 'user')] },
    ];
    if (role === 'secretary') return [
      { group: null, items: [N('/', 'الرئيسية', 'home'), N('/inbox', 'رسائل الطلبة', 'inbox', 'dm'), N('/announcements', 'التبليغات والتعاميم', 'bell')] },
      { group: 'المتابعة', items: [N('/admin/users', 'دليل المستخدمين', 'users'), N('/admin/attendance', 'متابعة الحضور', 'clipboard'), N('/faculty', 'الكادر التدريسي', 'grad')] },
      { group: 'عام', items: [N('/bot', 'المساعد الذكي', 'bot'), N('/profile', 'حسابي', 'user')] },
    ];
    return [
      { group: null, items: [N('/', 'لوحة التحكم', 'home')] },
      { group: 'الشؤون الأكاديمية', items: [N('/admin/users', 'الحسابات والمستخدمون', 'users'), N('/admin/departments', 'الأقسام العلمية', 'building'), N('/admin/courses', 'المواد الدراسية', 'book'), N('/teaching', 'الدرجات والحضور والملازم', 'clipboard'), N('/admin/attendance', 'متابعة الغياب', 'chart')] },
      { group: 'التواصل', items: [N('/announcements', 'التبليغات والتعاميم', 'bell'), N('/inbox', 'السكرتارية', 'inbox', 'dm'), N('/chat', 'شات الدفعات (إشراف)', 'chat')] },
      { group: 'النظام', items: [N('/admin/bot', 'المساعد الذكي', 'bot'), N('/admin/settings', 'إعدادات النظام', 'sliders'), N('/admin/network', 'الشبكة والأجهزة', 'wifi'), N('/admin/audit', 'سجل العمليات', 'history'), N('/admin/backup', 'النسخ الاحتياطي', 'database'), N('/profile', 'حسابي', 'user')] },
    ];
  }

  function shell() {
    const u = state.user, info = state.info;
    const groups = navFor(u.role);
    const html = `
    <div class="shell" id="shell">
      <div class="sb-overlay" data-close-nav></div>
      <aside class="sidebar" aria-label="القائمة الرئيسية">
        <div class="sb-brand">
          <img src="${esc(asset(info.college_logo))}" alt="شعار الكلية">
          <div><div class="t1">${esc(info.college_name)}</div><div class="t2">${esc(info.university_name)}</div></div>
        </div>
        <nav class="sb-nav">
          ${groups.map((g) => `${g.group ? `<div class="sb-group">${esc(g.group)}</div>` : ''}${g.items.map((it) => `
            <a class="sb-link" href="#${it.path}" data-path="${it.path}">${icon(it.ic)}<span>${esc(it.label)}</span>${it.badge ? `<span class="badge hidden" data-badge="${it.badge}"></span>` : ''}</a>`).join('')}`).join('')}
        </nav>
        <div class="sb-user">
          <div class="avatar">${esc(initials(u.full_name))}</div>
          <div style="min-width:0"><div class="n">${esc(u.full_name)}</div><div class="r">${esc(ROLE[u.role])}${u.department_name ? ` · ${esc(u.department_name)}` : ''}</div></div>
          <button class="btn-icon btn" data-logout title="تسجيل الخروج" aria-label="تسجيل الخروج">${icon('logout')}</button>
        </div>
      </aside>
      <div class="main">
        <header class="topbar">
          <button class="icon-btn menu-btn" data-open-nav aria-label="القائمة">${icon('menu')}</button>
          <div style="min-width:0"><div class="crumb" id="crumb"></div><h1 id="page-title"></h1></div>
          <div class="spacer"></div>
          <span class="live" id="live" title="حالة الاتصال الفوري"><i></i><span>غير متصل</span></span>
          ${u.role !== 'admin' && u.role !== 'secretary' ? `<button class="icon-btn" data-go="/announcements" aria-label="التبليغات">${icon('bell')}<span class="badge dot hidden" data-badge="ann"></span></button>` : ''}
        </header>
        <main class="content" id="view"></main>
      </div>
    </div>`;
    $('#app').innerHTML = html;
    $('[data-logout]').onclick = () => logout();
    $('[data-open-nav]').onclick = () => $('#shell').classList.add('nav-open');
    $('[data-close-nav]').onclick = () => $('#shell').classList.remove('nav-open');
    $$('[data-go]').forEach((b) => (b.onclick = () => navigate(b.dataset.go)));
    updateBadges();
    setLive(state.online);
  }

  function setTitle(title, crumb = '') {
    const t = $('#page-title'); if (t) t.textContent = title;
    const c = $('#crumb'); if (c) c.textContent = crumb;
    document.title = `${title} | ${state.info?.college_name || ''}`;
  }

  async function render() {
    const path = currentPath();
    state.route = path;
    if (!state.user) return;
    if (!$('#shell')) shell();
    $('#shell').classList.remove('nav-open');
    $$('.sb-link').forEach((a) => {
      const p = a.dataset.path;
      a.classList.toggle('active', p === '/' ? path === '/' : path === p || path.startsWith(p + '/'));
    });
    const view = $('#view');
    const m = match(path);
    if (!m) { view.innerHTML = empty('الصفحة غير موجودة', '', 'alert'); setTitle('غير موجود'); return; }
    view.innerHTML = skeleton(3);
    window.scrollTo(0, 0);
    try { await m.handler(view, m.params); } catch (e) {
      if (e.status === 403) view.innerHTML = empty('لا تملك صلاحية الوصول', e.message, 'lock');
      else view.innerHTML = `<div class="card">${empty('تعذّر تحميل الصفحة', e.message, 'alert')}</div>`;
    }
    const banners = [];
    if (state.impersonating) banners.push(`<div class="banner info">${icon('eye')}<span>أنت تتصفح النظام بحساب <b>${esc(state.user.full_name)}</b> بصلاحية الإدارة.</span><button class="btn btn-sm btn-primary" data-stop-imp>العودة لحساب الإدارة</button></div>`);
    if (state.defaultPassword && state.user.role === 'admin') banners.push(`<div class="banner warn">${icon('alert')}<span>أنت تستخدم كلمة مرور الإدارة الافتراضية. يُنصح بتغييرها فوراً لحماية النظام.</span><button class="btn btn-sm btn-gold" data-go-pw>تغيير كلمة المرور</button></div>`);
    if (banners.length) {
      view.insertAdjacentHTML('afterbegin', banners.join(''));
      const s = $('[data-stop-imp]', view); if (s) s.onclick = stopImpersonation;
      const g = $('[data-go-pw]', view); if (g) g.onclick = () => navigate('/profile');
    }
  }

  // ---------------- الجلسة ----------------
  async function start() {
    try { state.info = await api('/public/info', { silent: true }); } catch (e) {
      $('#app').innerHTML = `<div class="boot"><img src="img/college-logo.png" width="84" height="84" alt=""><p style="color:#fff">تعذّر الاتصال بالسيرفر. تأكد من تشغيل الأمر <b class="ltr">node server.js</b></p></div>`;
      return;
    }
    state.departments = state.info.departments;
    window.addEventListener('hashchange', render);
    try {
      const me = await api('/auth/me', { silent: true });
      await afterLogin(me.token, me.user, me.default_password, me.impersonating);
    } catch (_) { App.views.login(); }
  }

  async function afterLogin(token, user, defaultPassword, impersonating) {
    state.token = token; state.user = user; state.defaultPassword = !!defaultPassword; state.impersonating = !!impersonating;
    try { state.departments = await get('/departments'); } catch (_) {}
    try { const s = await get('/public/info'); state.info = { ...state.info, ...s }; } catch (_) {}
    connectSocket();
    shell();
    refreshUnread();
    if (user.must_change_password) { navigate('/profile'); toast('يجب تغيير كلمة المرور قبل المتابعة', 'gold'); }
    else render();
  }

  async function logout(expired) {
    try { if (!expired) await api('/auth/logout', { method: 'POST', silent: true }); } catch (_) {}
    if (state.socket) { state.socket.disconnect(); state.socket = null; }
    const adminToken = state.adminToken;
    state.token = null; state.user = null; state.adminToken = null;
    if (expired) toast('انتهت الجلسة، يرجى تسجيل الدخول مجدداً', 'error');
    if (adminToken && !expired) { state.token = adminToken; const me = await api('/auth/me'); return afterLogin(adminToken, me.user, me.default_password); }
    location.hash = '/';
    App.views.login();
  }

  async function impersonate(id) {
    const r = await post(`/admin/impersonate/${id}`);
    const adminToken = state.token;
    if (state.socket) state.socket.disconnect();
    state.token = r.token;
    const me = await api('/auth/me');
    state.adminToken = adminToken;
    location.hash = '/';
    await afterLogin(r.token, me.user, false, true);
    state.adminToken = adminToken;
  }
  async function stopImpersonation() {
    const adminToken = state.adminToken;
    try { await api('/auth/logout', { method: 'POST', silent: true }); } catch (_) {}
    if (state.socket) state.socket.disconnect();
    state.adminToken = null;
    if (!adminToken) return logout();
    state.token = adminToken;
    const me = await api('/auth/me');
    location.hash = '/admin/users';
    await afterLogin(adminToken, me.user, me.default_password, false);
  }

  // ---------------- التزامن الفوري ----------------
  const listeners = {};
  const on = (ev, fn) => { (listeners[ev] ||= new Set()).add(fn); return () => listeners[ev].delete(fn); };
  const fire = (ev, data) => (listeners[ev] || []).forEach((fn) => { try { fn(data); } catch (e) { console.error(e); } });

  function loadScript(src) {
    return new Promise((res, rej) => { const s = document.createElement('script'); s.src = src; s.onload = res; s.onerror = rej; document.head.appendChild(s); });
  }
  async function connectSocket() {
    try {
      if (!window.io) await loadScript(`${API}/socket.io/socket.io.js`);
      let sock;
      if (!API) sock = window.io({ auth: { token: state.token }, transports: ['websocket', 'polling'] });
      else {
        const u = new URL(API, location.href);
        sock = window.io(u.origin, { path: u.pathname.replace(/\/$/, '') + '/socket.io', auth: { token: state.token }, transports: ['websocket', 'polling'] });
      }
      state.socket = sock;
      sock.on('connect', () => setLive(true));
      sock.on('disconnect', () => setLive(false));
      sock.on('connect_error', () => setLive(false));
      sock.on('chat:message', (m) => {
        fire('chat:message', m);
        const viewing = state.route.startsWith('/chat') || state.route.startsWith('/secretary') || state.route.startsWith('/inbox');
        if (m.sender_id !== state.user.id && m.room.startsWith('dm:')) { refreshUnread(); if (!viewing) toast(m.content.slice(0, 90), 'gold', `رسالة من ${m.sender_name}`); }
      });
      sock.on('chat:deleted', (d) => fire('chat:deleted', d));
      sock.on('chat:cleared', (d) => fire('chat:cleared', d));
      sock.on('chat:typing', (d) => fire('chat:typing', d));
      sock.on('presence', (d) => fire('presence', d));
      sock.on('sync', (d) => {
        fire('sync', d);
        if (d.type === 'announcements') { refreshUnread(); if (d.title && state.user.role !== 'admin' && state.user.role !== 'secretary') toast(d.title, 'gold', 'تبليغ جديد'); }
        if (d.type === 'grades' && state.user.role === 'student') toast('تم تحديث درجاتك', 'ok');
        if (d.type === 'settings') get('/public/info').then((s) => { state.info = { ...state.info, ...s }; });
        if (d.type === 'restored') toast('تم تحديث بيانات النظام', 'gold');
      });
    } catch (e) { setLive(false); }
  }
  function setLive(on) {
    state.online = on;
    const el = $('#live'); if (!el) return;
    el.classList.toggle('on', on);
    $('span', el).textContent = on ? 'متصل لحظياً' : 'غير متصل';
  }
  async function refreshUnread() {
    if (!state.user) return;
    try {
      if (state.user.role !== 'admin' && state.user.role !== 'secretary') state.unread.ann = (await get('/announcements/unread-count')).n;
      if (state.user.role === 'student') state.unread.dm = (await get('/dashboard')).unread_dm || 0;
      if (state.user.role === 'admin' || state.user.role === 'secretary') state.unread.dm = (await get('/dm/threads')).reduce((a, t) => a + (t.unread || 0), 0);
    } catch (_) {}
    updateBadges();
  }
  function updateBadges() {
    $$('[data-badge]').forEach((b) => { const n = state.unread[b.dataset.badge] || 0; b.textContent = n > 99 ? '99+' : n; b.classList.toggle('hidden', !n); });
  }

  window.App = {
    API, state, api, get, post, put, del, fileUrl, asset, icon, esc, $, $$, toast, fail, modal, confirmBox, formData, opt,
    deptOptions, stageOptions, stageName, initials, fmtDate, fmtTime, fmtSize, progress, empty, skeleton, letterChip, attChip, ring, downloadText,
    route, navigate, render, setTitle, start, afterLogin, logout, impersonate, on, fire, refreshUnread, updateBadges,
    ROLE, STUDY, ANN_CAT, PRIORITY, MAT_CAT, views: {},
  };
})();
