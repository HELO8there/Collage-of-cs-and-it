/* =====================================================================
   واجهة الإدارة (رئيس القسم) والسكرتارية - تحكم شامل بالنظام
   ===================================================================== */
(function () {
  const { icon, esc, $, $$, get, post, put, del, toast, fail, modal, confirmBox, formData, opt, route, setTitle, state, navigate } = App;
  const isAdmin = () => state.user.role === 'admin';

  // ============================ لوحة التحكم ============================
  App.views.adminHome = async (view) => {
    const sec = state.user.role === 'secretary';
    setTitle(sec ? 'الرئيسية' : 'لوحة التحكم', `${state.info.college_name} · ${state.info.university_name}`);
    const d = await get('/dashboard');
    const s = d.stats;
    const attTotal = d.attendance.present + d.attendance.absent + d.attendance.excused || 1;
    const pct = (n) => Math.round((n / attTotal) * 1000) / 10;
    view.innerHTML = `
      <div class="hero-card">
        <div><div class="small" style="color:var(--gold)">${esc(App.ROLE[state.user.role])}</div><h2>${esc(state.user.full_name)}</h2>
          <p>العام الدراسي <span class="num">${esc(state.info.academic_year)}</span> · ${s.sessions} جلسة نشطة على الشبكة المحلية</p></div>
        <div class="row">${sec ? `<a class="btn btn-gold" href="#/inbox">${icon('inbox', 16)} رسائل الطلبة ${s.unread_dm ? `<span class="badge">${s.unread_dm}</span>` : ''}</a>` : `<a class="btn btn-gold" href="#/admin/users">${icon('plus', 16)} إنشاء حسابات</a><a class="btn btn-ghost-light" href="#/announcements">${icon('bell', 16)} تبليغ جديد</a>`}</div>
      </div>
      <div class="grid cols-4" style="margin-bottom:20px">
        <div class="stat"><div class="ic">${icon('users')}</div><div><div class="v num">${s.students}</div><div class="l">طالب فعّال</div></div></div>
        <div class="stat"><div class="ic gold">${icon('grad')}</div><div><div class="v num">${s.faculty}</div><div class="l">تدريسي</div></div></div>
        <div class="stat"><div class="ic">${icon('book')}</div><div><div class="v num">${s.courses}</div><div class="l">مادة دراسية</div></div></div>
        <div class="stat"><div class="ic ${s.unread_dm ? 'amber' : ''}">${icon('inbox')}</div><div><div class="v num">${s.unread_dm}</div><div class="l">رسالة غير مقروءة</div></div></div>
      </div>
      <div class="grid cols-main">
        <div class="stack">
          <div class="card"><div class="card-head"><h3>الأقسام العلمية</h3>${isAdmin() ? '<a class="btn btn-ghost btn-sm" href="#/admin/departments" style="margin-right:auto">إدارة</a>' : ''}</div>
            <div class="table-wrap"><table class="t"><thead><tr><th>القسم</th><th>الطلبة</th><th>التدريسيون</th><th>المواد</th></tr></thead><tbody>
            ${d.by_department.map((x) => `<tr><td><b>${esc(x.name)}</b> <span class="chip ltr">${esc(x.code || '')}</span></td><td class="num">${x.students}</td><td class="num">${x.faculty}</td><td class="num">${x.courses}</td></tr>`).join('')}</tbody></table></div></div>
          <div class="card"><div class="card-head"><h3>الطلبة المعرضون للإنذار أو الحرمان</h3><a class="btn btn-ghost btn-sm" href="#/admin/attendance" style="margin-right:auto">التفاصيل</a></div>
            ${d.at_risk.length ? `<div class="table-wrap"><table class="t"><thead><tr><th>الطالب</th><th>المادة</th><th>الغياب</th><th>الحالة</th></tr></thead><tbody>
            ${d.at_risk.map((r) => `<tr><td>${esc(r.student)}</td><td>${esc(r.course)}</td><td class="num">${r.pct}%</td><td>${App.attChip(r)}</td></tr>`).join('')}</tbody></table></div>` : App.empty('لا يوجد طلبة معرضون للحرمان', '', 'check')}</div>
        </div>
        <div class="stack">
          <div class="card card-pad"><h3 style="margin-bottom:14px">إحصائيات الحضور الكلية</h3>
            <div class="xs muted row between"><span>حاضر</span><span class="num">${pct(d.attendance.present)}%</span></div>${App.progress(pct(d.attendance.present))}
            <div class="xs muted row between" style="margin-top:10px"><span>غائب</span><span class="num">${pct(d.attendance.absent)}%</span></div>${App.progress(pct(d.attendance.absent), 'danger')}
            <div class="xs muted row between" style="margin-top:10px"><span>مجاز</span><span class="num">${pct(d.attendance.excused)}%</span></div>${App.progress(pct(d.attendance.excused), 'warn')}
            <div class="xs muted" style="margin-top:12px">${s.lectures} محاضرة مسجلة · ${s.materials} ملف مرفوع · ${s.announcements} تبليغ</div></div>
          ${d.recent_audit ? `<div class="card"><div class="card-head"><h3>آخر العمليات</h3><a class="btn btn-ghost btn-sm" href="#/admin/audit" style="margin-right:auto">السجل</a></div>
            <div class="list-plain">${d.recent_audit.map((a) => `<div style="padding:10px 18px;border-bottom:1px solid var(--line)"><b class="small">${esc(a.action)}</b> <span class="xs muted">${esc(a.user_name || '')}</span><div class="xs muted">${esc((a.details || '').slice(0, 80))} · <span class="num">${esc(a.created_at)}</span></div></div>`).join('')}</div></div>` : ''}
          <div class="card"><div class="card-head"><h3>آخر التبليغات</h3></div><div>${App.views.annList(d.announcements, { short: true })}</div></div>
        </div>
      </div>`;
  };

  // ============================ المستخدمون ============================
  const ROLE_SHORT = { admin: 'إدارة', secretary: 'سكرتارية', faculty: 'تدريسي', student: 'طالب' };
  function userForm(u = {}) {
    const role = u.role || 'student';
    const body = `
      <div class="grid-2">
        <label class="field"><span>الاسم الكامل</span><input class="input" name="full_name" value="${esc(u.full_name || '')}" required></label>
        <label class="field"><span>الدور</span><select class="input" name="role" id="uf-role">${Object.entries(App.ROLE).map(([k, v]) => opt(k, v, role)).join('')}</select></label>
        <label class="field"><span>اسم المستخدم (إنجليزي)</span><input class="input ltr" name="username" value="${esc(u.username || '')}" required pattern="[A-Za-z0-9_.\\-]{3,40}"></label>
        <label class="field"><span>${u.id ? 'كلمة مرور جديدة (اتركها فارغة للإبقاء)' : 'كلمة المرور (فارغة = توليد تلقائي)'}</span><input class="input ltr" name="password" autocomplete="new-password"></label>
        <label class="field"><span>القسم</span><select class="input" name="department_id">${App.deptOptions(u.department_id, 'بدون قسم')}</select></label>
        <label class="field" data-st><span>المرحلة</span><select class="input" name="stage">${App.stageOptions(u.stage, '-')}</select></label>
        <label class="field" data-st><span>نوع الدراسة</span><select class="input" name="study_type">${opt('morning', 'صباحي', u.study_type)}${opt('evening', 'مسائي', u.study_type)}</select></label>
        <label class="field" data-st><span>الدفعة (سنة القبول)</span><input class="input num" name="batch" value="${esc(u.batch || '')}" placeholder="2026"></label>
        <label class="field" data-fa><span>اللقب العلمي</span><input class="input" name="academic_title" value="${esc(u.academic_title || '')}" placeholder="أ.م.د / م.د / م.م"></label>
        <label class="field"><span>البريد الإلكتروني</span><input class="input ltr" name="email" value="${esc(u.email || '')}"></label>
        <label class="field"><span>الهاتف</span><input class="input ltr" name="phone" value="${esc(u.phone || '')}"></label>
        <label class="field" data-fa><span>الساعات المكتبية</span><input class="input" name="office_hours" value="${esc(u.office_hours || '')}"></label>
      </div>
      <label class="field" data-fa><span>نبذة</span><textarea class="input" name="bio" rows="2">${esc(u.bio || '')}</textarea></label>
      <div class="row"><label class="check"><input type="checkbox" name="active" ${u.active === 0 ? '' : 'checked'}> الحساب فعّال</label>
      ${u.id ? '' : '<label class="check"><input type="checkbox" name="must_change_password"> إلزام بتغيير كلمة المرور عند أول دخول</label>'}</div>`;
    return modal({
      title: u.id ? `تعديل حساب: ${u.full_name}` : 'إنشاء حساب جديد', body, wide: true,
      onOpen: (b) => {
        const sync = () => { const r = $('#uf-role', b).value; $$('[data-st]', b).forEach((e) => (e.style.display = r === 'student' ? '' : 'none')); $$('[data-fa]', b).forEach((e) => (e.style.display = r === 'faculty' || r === 'admin' ? '' : 'none')); };
        $('#uf-role', b).onchange = sync; sync();
      },
      actions: [{ label: `${icon('check', 15)} ${u.id ? 'حفظ' : 'إنشاء'}`, cls: 'btn-primary', onClick: async (b) => {
        const d = formData(b);
        if (!d.password) delete d.password;
        if (u.id) { await put(`/admin/users/${u.id}`, d); toast('تم حفظ الحساب'); return true; }
        const r = await post('/admin/users', d);
        credentialsModal([{ full_name: d.full_name, username: r.username, password: r.password }]);
        return true;
      } }, { label: 'إلغاء' }],
    });
  }

  function credentialsModal(list, title = 'بيانات الدخول') {
    const csv = '\uFEFF' + [['الاسم', 'اسم المستخدم', 'كلمة المرور'], ...list.map((c) => [c.full_name, c.username, c.password])].map((r) => r.map((v) => `"${String(v).replace(/"/g, '""')}"`).join(',')).join('\r\n');
    return modal({
      title, wide: true,
      body: `<div class="banner warn">${icon('alert')}<span>احفظ أو اطبع بيانات الدخول الآن. لا يمكن عرض كلمات المرور مرة أخرى لأنها مشفّرة في قاعدة البيانات.</span></div>
        <div class="table-wrap" id="cred-print"><table class="t"><thead><tr><th>#</th><th>الاسم</th><th>اسم المستخدم</th><th>كلمة المرور</th></tr></thead><tbody>
        ${list.map((c, i) => `<tr><td class="num">${i + 1}</td><td>${esc(c.full_name)}</td><td class="ltr num" style="text-align:right">${esc(c.username)}</td><td class="ltr num" style="text-align:right"><b>${esc(c.password)}</b></td></tr>`).join('')}</tbody></table></div>`,
      actions: [
        { label: `${icon('download', 15)} تنزيل CSV`, cls: 'btn-primary', onClick: () => { App.downloadText(`credentials-${Date.now()}.csv`, csv); return false; } },
        { label: `${icon('printer', 15)} طباعة`, onClick: (b) => { printHTML(`<h2>${esc(state.info.college_name)} - بيانات الدخول</h2>${$('#cred-print', b).innerHTML}`); return false; } },
        { label: 'تم' },
      ],
    });
  }
  function printHTML(html) {
    const f = document.createElement('iframe');
    f.style.cssText = 'position:fixed;width:0;height:0;border:0';
    document.body.appendChild(f);
    f.contentDocument.write(`<html dir="rtl"><head><meta charset="utf-8"><style>body{font-family:Tahoma,Arial;padding:20px}table{width:100%;border-collapse:collapse}td,th{border:1px solid #999;padding:6px 8px;text-align:right}</style></head><body>${html}</body></html>`);
    f.contentDocument.close();
    setTimeout(() => { f.contentWindow.print(); setTimeout(() => f.remove(), 1000); }, 200);
  }

  function bulkForm() {
    return modal({
      title: 'إنشاء حسابات جماعية', wide: true,
      body: `<p class="small muted" style="margin-top:0">الصق قائمة الأسماء (اسم في كل سطر). يمكن إضافة اسم المستخدم وكلمة المرور مفصولة بفاصلة: <span class="ltr">الاسم, username, password</span>. الحقول الفارغة تُولّد تلقائياً.</p>
        <div class="grid-3">
          <label class="field"><span>الدور</span><select class="input" name="role" id="bk-role">${opt('student', 'طالب')}${opt('faculty', 'تدريسي')}${opt('secretary', 'سكرتارية')}</select></label>
          <label class="field"><span>القسم</span><select class="input" name="department_id">${App.deptOptions('', '-')}</select></label>
          <label class="field" data-st><span>المرحلة</span><select class="input" name="stage">${App.stageOptions('', '-')}</select></label>
          <label class="field" data-st><span>نوع الدراسة</span><select class="input" name="study_type">${opt('morning', 'صباحي')}${opt('evening', 'مسائي')}</select></label>
          <label class="field" data-st><span>الدفعة</span><input class="input num" name="batch" placeholder="2026"></label>
          <label class="field"><span>بادئة اسم المستخدم (اختياري)</span><input class="input ltr" name="prefix" placeholder="cs1"></label>
        </div>
        <label class="field"><span>الأسماء</span><textarea class="input" name="names" rows="9" placeholder="أحمد محمد علي\nسارة خالد حسن, sara.k\n..."></textarea></label>`,
      onOpen: (b) => { const sync = () => $$('[data-st]', b).forEach((e) => (e.style.display = $('#bk-role', b).value === 'student' ? '' : 'none')); $('#bk-role', b).onchange = sync; sync(); },
      actions: [{ label: `${icon('users', 15)} إنشاء الحسابات`, cls: 'btn-primary', onClick: async (b) => {
        const d = formData(b);
        d.rows = d.names.split(/\r?\n/).map((l) => l.split(/[,،\t]/).map((x) => x.trim())).filter((p) => p[0]).map(([full_name, username, password]) => ({ full_name, username, password }));
        if (!d.rows.length) throw new Error('أدخل اسماً واحداً على الأقل');
        const r = await post('/admin/users/bulk', d);
        if (r.skipped.length) toast(`تم تخطي ${r.skipped.length} (اسم مستخدم مكرر)`, 'error');
        credentialsModal(r.created, `تم إنشاء ${r.created.length} حساب`);
        return true;
      } }, { label: 'إلغاء' }],
    });
  }

  route('/admin/users', async (view) => {
    setTitle(isAdmin() ? 'الحسابات والمستخدمون' : 'دليل المستخدمين', isAdmin() ? 'إنشاء وتعديل وحذف جميع الحسابات - لا يوجد تسجيل ذاتي' : 'عرض بيانات الطلبة والتدريسيين');
    const f = state.userFilter || (state.userFilter = { role: '', department_id: '', stage: '', study_type: '', active: '', q: '' });
    const sel = new Set();
    let list = [];
    const load = async () => {
      const qs = new URLSearchParams(Object.entries(f).filter(([, v]) => v !== '')).toString();
      list = await get(`/admin/users${qs ? `?${qs}` : ''}`);
      sel.clear(); drawTable();
    };
    const drawTable = () => {
      $('#ucount').textContent = `${list.length} حساب`;
      $('#bulkbar').hidden = !sel.size;
      $('#selcount').textContent = sel.size;
      $('#utable').innerHTML = `<table class="t"><thead><tr>${isAdmin() ? '<th style="width:34px"><input type="checkbox" id="selall" aria-label="تحديد الكل"></th>' : ''}<th>الاسم</th><th>اسم المستخدم</th><th>الدور</th><th>القسم</th><th>المرحلة</th><th>الحالة</th><th>آخر دخول</th>${isAdmin() ? '<th></th>' : ''}</tr></thead><tbody>
        ${list.slice(0, 500).map((u) => `<tr>${isAdmin() ? `<td><input type="checkbox" data-sel="${u.id}" ${sel.has(u.id) ? 'checked' : ''} aria-label="تحديد"></td>` : ''}
          <td><div class="row" style="flex-wrap:nowrap"><div class="avatar sm ${u.role === 'student' ? 'teal' : ''}">${esc(App.initials(u.full_name))}</div><div><b>${esc(u.full_name)}</b>${u.academic_title ? `<div class="xs muted">${esc(u.academic_title)}</div>` : ''}</div></div></td>
          <td class="ltr num" style="text-align:right">${esc(u.username)}</td><td><span class="chip ${u.role === 'admin' ? 'gold' : u.role === 'faculty' ? 'teal' : ''}">${ROLE_SHORT[u.role]}</span></td>
          <td>${esc(u.department_name || '-')}</td><td>${u.stage ? `${esc(App.stageName(u.stage))} <span class="xs muted">${esc(App.STUDY[u.study_type] || '')}</span>` : '-'}</td>
          <td>${u.active ? '<span class="chip teal">فعّال</span>' : '<span class="chip red">معطّل</span>'}${u.must_change_password ? ' <span class="chip amber">يغيّر كلمة المرور</span>' : ''}</td>
          <td class="xs muted num">${esc(u.last_login || '-')}</td>
          ${isAdmin() ? `<td><div class="row" style="flex-wrap:nowrap;gap:4px">
            <button class="btn btn-ghost btn-sm" data-uedit="${u.id}" aria-label="تعديل">${icon('edit', 14)}</button>
            <button class="btn btn-ghost btn-sm" data-ureset="${u.id}" title="إعادة تعيين كلمة المرور" aria-label="إعادة تعيين كلمة المرور">${icon('key', 14)}</button>
            ${u.id !== state.user.id && u.active ? `<button class="btn btn-ghost btn-sm" data-uimp="${u.id}" title="الدخول بهذا الحساب" aria-label="الدخول بهذا الحساب">${icon('eye', 14)}</button>` : ''}
            ${u.id !== state.user.id ? `<button class="btn btn-danger btn-sm" data-udel="${u.id}" aria-label="حذف">${icon('trash', 14)}</button>` : ''}</div></td>` : ''}</tr>`).join('') || `<tr><td colspan="9">${App.empty('لا توجد حسابات مطابقة', '', 'users')}</td></tr>`}</tbody></table>
        ${list.length > 500 ? `<p class="xs muted" style="padding:10px 18px">يُعرض أول 500 حساب. استخدم الفلاتر لتضييق النتائج.</p>` : ''}`;
      const t = $('#utable');
      $('#selall', t)?.addEventListener('change', (e) => { list.slice(0, 500).forEach((u) => (e.target.checked && u.id !== state.user.id ? sel.add(u.id) : sel.delete(u.id))); drawTable(); });
      $$('[data-sel]', t).forEach((c) => (c.onchange = () => { c.checked ? sel.add(Number(c.dataset.sel)) : sel.delete(Number(c.dataset.sel)); $('#bulkbar').hidden = !sel.size; $('#selcount').textContent = sel.size; }));
      $$('[data-uedit]', t).forEach((b) => (b.onclick = () => userForm(list.find((u) => u.id === Number(b.dataset.uedit))).then((ok) => ok && load())));
      $$('[data-udel]', t).forEach((b) => (b.onclick = async () => { const u = list.find((x) => x.id === Number(b.dataset.udel)); if (await confirmBox('حذف الحساب', `سيُحذف حساب "${u.full_name}" وجميع بياناته (درجات، حضور، رسائل). لا يمكن التراجع.`, 'حذف نهائي')) { try { await del(`/admin/users/${u.id}`); toast('تم حذف الحساب'); load(); } catch (e) { fail(e); } } }));
      $$('[data-uimp]', t).forEach((b) => (b.onclick = async () => { try { await App.impersonate(Number(b.dataset.uimp)); } catch (e) { fail(e); } }));
      $$('[data-ureset]', t).forEach((b) => (b.onclick = async () => {
        const u = list.find((x) => x.id === Number(b.dataset.ureset));
        const r = await modal({ title: `إعادة تعيين كلمة مرور: ${u.full_name}`, body: `<label class="field"><span>كلمة المرور الجديدة (فارغة = توليد تلقائي)</span><input class="input ltr" name="password"></label><label class="check"><input type="checkbox" name="force_change"> إلزام المستخدم بتغييرها عند الدخول</label>`,
          actions: [{ label: 'تعيين', cls: 'btn-primary', onClick: async (bd) => post(`/admin/users/${u.id}/reset-password`, formData(bd)) }, { label: 'إلغاء' }] });
        if (r && r.password) credentialsModal([{ full_name: u.full_name, username: r.username, password: r.password }], 'كلمة المرور الجديدة');
      }));
    };
    view.innerHTML = `
      <div class="card">
        <div class="card-head">
          <div class="filters">
            <div class="input-icon">${icon('search')}<input class="input" id="uq" placeholder="بحث بالاسم أو اسم المستخدم" value="${esc(f.q)}"></div>
            <select class="input" data-f="role">${opt('', 'كل الأدوار', f.role)}${Object.entries(ROLE_SHORT).map(([k, v]) => opt(k, v, f.role)).join('')}</select>
            <select class="input" data-f="department_id">${App.deptOptions(f.department_id)}</select>
            <select class="input" data-f="stage">${App.stageOptions(f.stage)}</select>
            <select class="input" data-f="study_type">${opt('', 'صباحي ومسائي', f.study_type)}${opt('morning', 'صباحي', f.study_type)}${opt('evening', 'مسائي', f.study_type)}</select>
            <select class="input" data-f="active">${opt('', 'كل الحالات', f.active)}${opt('1', 'فعّال', f.active)}${opt('0', 'معطّل', f.active)}</select>
          </div>
          <div class="actions"><span class="muted small" id="ucount"></span>
            ${isAdmin() ? `<button class="btn btn-ghost" id="u-bulk">${icon('users', 16)} إنشاء جماعي</button><button class="btn btn-gold" id="u-new">${icon('plus', 16)} حساب جديد</button>` : ''}</div>
        </div>
        <div class="bulkbar" id="bulkbar" hidden><span>محدد: <b id="selcount" class="num">0</b></span>
          <button class="btn btn-ghost btn-sm" data-ba="activate">تفعيل</button><button class="btn btn-ghost btn-sm" data-ba="deactivate">تعطيل</button>
          <button class="btn btn-ghost btn-sm" data-ba="promote">${icon('arrowUp', 14)} ترحيل للمرحلة التالية</button><button class="btn btn-ghost btn-sm" data-ba="demote">إرجاع مرحلة</button>
          <select class="input" id="ba-dept" style="width:auto">${App.deptOptions('', 'نقل إلى قسم...')}</select>
          <button class="btn btn-danger btn-sm" data-ba="delete">${icon('trash', 14)} حذف</button></div>
        <div class="table-wrap" id="utable"></div>
      </div>`;
    let tm;
    $('#uq').oninput = (e) => { clearTimeout(tm); tm = setTimeout(() => { f.q = e.target.value.trim(); load(); }, 250); };
    $$('[data-f]').forEach((s) => (s.onchange = () => { f[s.dataset.f] = s.value; load(); }));
    $('#u-new')?.addEventListener('click', () => userForm().then((ok) => ok && load()));
    $('#u-bulk')?.addEventListener('click', () => bulkForm().then((ok) => ok && load()));
    const doBulk = async (action, extra = {}) => {
      const lbl = { activate: 'تفعيل', deactivate: 'تعطيل', promote: 'ترحيل', demote: 'إرجاع', delete: 'حذف', move: 'نقل' }[action];
      if (!(await confirmBox(`${lbl} الحسابات المحددة`, `سيتم ${lbl} ${sel.size} حساب. متابعة؟`, lbl, action === 'delete'))) return;
      const r = await post('/admin/users/bulk-action', { ids: [...sel], action, ...extra });
      toast(`تم تطبيق الإجراء على ${r.changed} حساب`); load();
    };
    $$('[data-ba]').forEach((b) => (b.onclick = () => doBulk(b.dataset.ba)));
    $('#ba-dept').onchange = (e) => { if (e.target.value) doBulk('move', { department_id: e.target.value }); e.target.value = ''; };
    await load();
  });

  // ============================ الأقسام ============================
  route('/admin/departments', async (view) => {
    setTitle('الأقسام العلمية', 'إضافة وتعديل الأقسام - تظهر في صفحة الدخول وكل النظام');
    const list = await get('/departments');
    const form = (d = {}) => modal({
      title: d.id ? `تعديل قسم ${d.name}` : 'إضافة قسم',
      body: `<div class="grid-2"><label class="field"><span>اسم القسم</span><input class="input" name="name" value="${esc(d.name || '')}" required></label>
        <label class="field"><span>الاسم بالإنجليزية</span><input class="input ltr" name="name_en" value="${esc(d.name_en || '')}"></label>
        <label class="field"><span>الرمز</span><input class="input ltr" name="code" value="${esc(d.code || '')}" placeholder="CS"></label>
        <label class="field"><span>سنة التأسيس</span><input class="input num" name="established" value="${esc(d.established || '')}"></label>
        <label class="field"><span>رئيس القسم</span><input class="input" name="head_name" value="${esc(d.head_name || '')}"></label>
        <label class="field"><span>الترتيب</span><input class="input num" type="number" name="sort" value="${d.sort ?? list.length + 1}"></label></div>
        <label class="field"><span>نبذة</span><textarea class="input" name="description" rows="3">${esc(d.description || '')}</textarea></label>
        <label class="check"><input type="checkbox" name="active" ${d.active === 0 ? '' : 'checked'}> القسم فعّال</label>`,
      actions: [{ label: 'حفظ', cls: 'btn-primary', onClick: async (b) => { const x = formData(b); if (d.id) await put(`/admin/departments/${d.id}`, x); else await post('/admin/departments', x); return true; } }, { label: 'إلغاء' }],
    }).then(async (ok) => { if (ok) { state.departments = await get('/departments'); state.info = { ...state.info, ...(await get('/public/info')) }; App.render(); } });
    view.innerHTML = `<div class="row between" style="margin-bottom:16px"><span class="muted small">${list.length} قسم</span><button class="btn btn-gold" id="d-new">${icon('plus', 16)} إضافة قسم</button></div>
      <div class="grid cols-2">${list.map((d) => `<div class="card card-pad">
        <div class="row between" style="flex-wrap:nowrap;align-items:flex-start"><div><h3>قسم ${esc(d.name)}</h3><div class="xs muted ltr" style="text-align:right">${esc(d.name_en || '')}</div></div>
          <div class="row" style="flex-wrap:nowrap">${d.active ? '<span class="chip teal">فعّال</span>' : '<span class="chip red">معطّل</span>'}<span class="chip gold ltr">${esc(d.code || '')}</span></div></div>
        <p class="small" style="color:var(--ink-2)">${esc(d.description || '')}</p>
        <div class="xs muted">${d.established ? `تأسس عام <span class="num">${esc(d.established)}</span>` : ''}${d.head_name ? ` · رئيس القسم: ${esc(d.head_name)}` : ''}</div>
        <div class="row" style="margin-top:12px"><button class="btn btn-ghost btn-sm" data-dedit="${d.id}">${icon('edit', 14)} تعديل</button><button class="btn btn-danger btn-sm" data-ddel="${d.id}">${icon('trash', 14)} حذف</button></div></div>`).join('')}</div>`;
    $('#d-new').onclick = () => form();
    $$('[data-dedit]').forEach((b) => (b.onclick = () => form(list.find((d) => d.id === Number(b.dataset.dedit)))));
    $$('[data-ddel]').forEach((b) => (b.onclick = async () => { if (await confirmBox('حذف القسم', 'هل تريد حذف هذا القسم؟', 'حذف')) { try { await del(`/admin/departments/${b.dataset.ddel}`); state.departments = await get('/departments'); App.render(); } catch (e) { fail(e); } } }));
  });

  // ============================ المواد ============================
  route('/admin/courses', async (view) => {
    setTitle('المواد الدراسية', 'إضافة المواد وإسنادها للتدريسيين، الوحدات ECTS، الأوزان، قفل ونشر الدرجات');
    const f = state.courseFilter || (state.courseFilter = { dep: '', stage: '', q: '' });
    let [list, faculty] = await Promise.all([get('/teaching/courses'), get('/admin/users?role=faculty')]);
    const reload = async () => { list = await get('/teaching/courses'); draw(); };
    const form = (c = {}) => modal({
      title: c.id ? `تعديل مادة: ${c.name}` : 'إضافة مادة', wide: true,
      body: `<div class="grid-2"><label class="field"><span>اسم المادة</span><input class="input" name="name" value="${esc(c.name || '')}" required></label>
        <label class="field"><span>الاسم بالإنجليزية</span><input class="input ltr" name="name_en" value="${esc(c.name_en || '')}"></label>
        <label class="field"><span>رمز المادة</span><input class="input ltr" name="code" value="${esc(c.code || '')}"></label>
        <label class="field"><span>التدريسي المسؤول</span><select class="input" name="faculty_id">${opt('', 'غير محدد', c.faculty_id)}${faculty.map((x) => opt(x.id, `${x.academic_title || ''} ${x.full_name}`, c.faculty_id)).join('')}</select></label>
        <label class="field"><span>القسم</span><select class="input" name="department_id" required>${App.deptOptions(c.department_id, null)}</select></label>
        <label class="field"><span>المرحلة</span><select class="input" name="stage">${App.stageOptions(c.stage, null)}</select></label>
        <label class="field"><span>الفصل الدراسي</span><select class="input" name="semester">${opt(1, 'الأول', c.semester)}${opt(2, 'الثاني', c.semester)}</select></label>
        <label class="field"><span>نوع الدراسة</span><select class="input" name="study_type">${opt('both', 'صباحي ومسائي', c.study_type)}${opt('morning', 'صباحي فقط', c.study_type)}${opt('evening', 'مسائي فقط', c.study_type)}</select></label>
        <label class="field"><span>الوحدات ECTS</span><input class="input num" type="number" step="0.5" min="0" name="ects" value="${c.ects ?? 5}"></label>
        <label class="field"><span>مجموع الساعات (لاحتساب الغياب)</span><input class="input num" type="number" min="1" name="total_hours" value="${c.total_hours ?? 30}"></label>
        <label class="field"><span>وزن التقييم المستمر % (الباقي للامتحان)</span><input class="input num" type="number" min="0" max="100" name="formative_weight" value="${c.formative_weight ?? state.settingsCache?.default_formative_weight ?? 50}"></label>
        <div class="field"><span>الخيارات</span><label class="check"><input type="checkbox" name="grades_published" ${c.grades_published === 0 ? '' : 'checked'}> الدرجات منشورة للطلبة</label><label class="check"><input type="checkbox" name="active" ${c.active === 0 ? '' : 'checked'}> المادة فعّالة</label></div></div>
        <label class="field"><span>الوصف / المفردات</span><textarea class="input" name="description" rows="2">${esc(c.description || '')}</textarea></label>
        ${c.id ? '' : '<p class="xs muted">تُنشأ تلقائياً مكوّنات تقييم افتراضية (كويزات، واجبات، عملي، امتحان فصلي، نهائي، إعادة) ويمكن تعديلها لاحقاً من صفحة المادة.</p>'}`,
      actions: [{ label: 'حفظ', cls: 'btn-primary', onClick: async (b) => { const x = formData(b); if (c.id) await put(`/admin/courses/${c.id}`, x); else await post('/admin/courses', x); toast('تم الحفظ'); return true; } }, { label: 'إلغاء' }],
    }).then((ok) => ok && reload());

    const enroll = async (c) => {
      const drawE = async (b) => {
        const rows = await get(`/admin/courses/${c.id}/enrollments`);
        $('#enl', b).innerHTML = rows.length ? `<table class="t"><tbody>${rows.map((e) => `<tr><td>${esc(e.full_name)}</td><td class="ltr num">${esc(e.username)}</td><td>${esc(e.department_name || '')} · ${esc(App.stageName(e.stage))}</td><td><span class="chip amber">${e.kind === 'carry' ? 'محمّل' : e.kind}</span></td><td><button class="btn btn-danger btn-sm" data-edel="${e.id}" aria-label="إزالة">${icon('x', 14)}</button></td></tr>`).join('')}</tbody></table>` : App.empty('لا يوجد طلبة مسجلون إضافياً', 'طلبة القسم والمرحلة يُسجلون تلقائياً', 'users');
        $$('[data-edel]', b).forEach((x) => (x.onclick = async () => { await del(`/admin/enrollments/${x.dataset.edel}`); drawE(b); }));
      };
      modal({
        title: `التسجيل الإضافي: ${c.name}`, wide: true,
        body: `<p class="small muted" style="margin-top:0">لإضافة طلبة محمّلين أو من مراحل أخرى لهذه المادة.</p>
          <div class="row" style="flex-wrap:nowrap"><input class="input ltr" id="en-user" placeholder="اسم المستخدم للطالب، مثال: cs2005"><button class="btn btn-primary" id="en-add">${icon('plus', 15)} إضافة</button></div><div id="enl" style="margin-top:14px"></div>`,
        onOpen: (b) => {
          drawE(b);
          $('#en-add', b).onclick = async () => { try { await post(`/admin/courses/${c.id}/enrollments`, { username: $('#en-user', b).value.trim(), kind: 'carry' }); $('#en-user', b).value = ''; drawE(b); } catch (e) { fail(e); } };
        },
        actions: [{ label: 'إغلاق' }],
      });
    };

    const draw = () => {
      const shown = list.filter((c) => (!f.dep || String(c.department_id) === f.dep) && (!f.stage || String(c.stage) === f.stage) && (!f.q || c.name.includes(f.q) || (c.faculty_name || '').includes(f.q)));
      $('#ctable').innerHTML = `<table class="t"><thead><tr><th>المادة</th><th>القسم / المرحلة</th><th>الفصل</th><th>التدريسي</th><th>ECTS</th><th>الساعات</th><th>الأوزان</th><th>الطلبة</th><th>الدرجات</th><th></th></tr></thead><tbody>
        ${shown.map((c) => `<tr class="${c.active ? '' : 'muted'}"><td><b>${esc(c.name)}</b>${c.code ? `<div class="xs muted ltr" style="text-align:right">${esc(c.code)}</div>` : ''}</td>
          <td>${esc(c.department_name || '')}<div class="xs muted">${esc(App.stageName(c.stage))} · ${esc(App.STUDY[c.study_type] || '')}</div></td><td class="num">${c.semester}</td>
          <td>${esc(c.faculty_name || '-')}</td><td class="num">${c.ects}</td><td class="num">${c.total_hours}</td><td class="num">${c.formative_weight}/${c.exam_weight}</td><td class="num">${c.students}</td>
          <td><button class="btn btn-sm ${c.grades_locked ? 'btn-danger' : 'btn-ghost'}" data-lock="${c.id}" title="${c.grades_locked ? 'فتح الدرجات' : 'قفل الدرجات'}">${icon(c.grades_locked ? 'lock' : 'unlock', 14)} ${c.grades_locked ? 'مقفلة' : 'مفتوحة'}</button>
            <button class="btn btn-sm btn-ghost" data-pub="${c.id}" title="نشر/إخفاء الدرجات">${icon('eye', 14)} ${c.grades_published ? 'منشورة' : 'مخفية'}</button></td>
          <td><div class="row" style="flex-wrap:nowrap;gap:4px"><a class="btn btn-ghost btn-sm" href="#/teaching/${c.id}" title="فتح مساحة المادة" aria-label="فتح">${icon('clipboard', 14)}</a>
            <button class="btn btn-ghost btn-sm" data-cen="${c.id}" title="تسجيل إضافي" aria-label="تسجيل إضافي">${icon('users', 14)}</button>
            <button class="btn btn-ghost btn-sm" data-cedit="${c.id}" aria-label="تعديل">${icon('edit', 14)}</button><button class="btn btn-danger btn-sm" data-cdel="${c.id}" aria-label="حذف">${icon('trash', 14)}</button></div></td></tr>`).join('') || `<tr><td colspan="10">${App.empty('لا توجد مواد', '', 'book')}</td></tr>`}</tbody></table>`;
      const t = $('#ctable');
      const byId = (x) => list.find((c) => c.id === Number(x));
      $$('[data-cedit]', t).forEach((b) => (b.onclick = () => form(byId(b.dataset.cedit))));
      $$('[data-cen]', t).forEach((b) => (b.onclick = () => enroll(byId(b.dataset.cen))));
      $$('[data-cdel]', t).forEach((b) => (b.onclick = async () => { const c = byId(b.dataset.cdel); if (await confirmBox('حذف المادة', `ستُحذف المادة "${c.name}" مع جميع ملازمها ودرجاتها وسجلات حضورها. لا يمكن التراجع.`, 'حذف نهائي')) { await del(`/admin/courses/${c.id}`); toast('تم حذف المادة'); reload(); } }));
      $$('[data-lock]', t).forEach((b) => (b.onclick = async () => { const c = byId(b.dataset.lock); await post(`/admin/courses/${c.id}/lock`, { locked: !c.grades_locked }); toast(c.grades_locked ? 'تم فتح الدرجات للتعديل' : 'تم قفل الدرجات'); reload(); }));
      $$('[data-pub]', t).forEach((b) => (b.onclick = async () => { const c = byId(b.dataset.pub); await put(`/admin/courses/${c.id}`, { grades_published: !c.grades_published }); toast(c.grades_published ? 'تم إخفاء الدرجات عن الطلبة' : 'تم نشر الدرجات للطلبة'); reload(); }));
    };
    view.innerHTML = `<div class="card"><div class="card-head"><div class="filters">
        <div class="input-icon">${icon('search')}<input class="input" id="cq" placeholder="بحث" value="${esc(f.q)}"></div>
        <select class="input" id="cdep">${App.deptOptions(f.dep)}</select><select class="input" id="cst">${App.stageOptions(f.stage)}</select></div>
        <div class="actions"><button class="btn btn-ghost btn-sm" id="lock-all">${icon('lock', 14)} قفل الكل</button><button class="btn btn-ghost btn-sm" id="unlock-all">${icon('unlock', 14)} فتح الكل</button>
        <button class="btn btn-gold" id="c-new">${icon('plus', 16)} مادة جديدة</button></div></div>
      <div class="table-wrap" id="ctable"></div></div>`;
    $('#cq').oninput = (e) => { f.q = e.target.value.trim(); draw(); };
    $('#cdep').onchange = (e) => { f.dep = e.target.value; draw(); };
    $('#cst').onchange = (e) => { f.stage = e.target.value; draw(); };
    $('#c-new').onclick = () => form({ department_id: f.dep || undefined, stage: f.stage || undefined });
    $('#lock-all').onclick = async () => { if (await confirmBox('قفل جميع الدرجات', 'لن يتمكن التدريسيون من تعديل أي درجة حتى الفتح. متابعة؟', 'قفل', false)) { await post('/admin/courses/lock-all', { locked: true }); reload(); } };
    $('#unlock-all').onclick = async () => { await post('/admin/courses/lock-all', { locked: false }); toast('تم فتح جميع الدرجات'); reload(); };
    draw();
  });

  // ============================ متابعة الحضور ============================
  route('/admin/attendance', async (view) => {
    setTitle('متابعة الغياب والحضور', `الإنذار عند ${state.info.absence_warning_pct}% والحرمان عند ${state.info.absence_ban_pct}% من ساعات المادة`);
    const f = { department_id: '', stage: '' };
    const load = async () => {
      const qs = new URLSearchParams(Object.entries(f).filter(([, v]) => v)).toString();
      const d = await get(`/admin/attendance${qs ? `?${qs}` : ''}`);
      $('#att-body').innerHTML = `
        <div class="card" style="margin-bottom:20px"><div class="card-head"><h3>المواد</h3></div><div class="table-wrap"><table class="t"><thead><tr><th>المادة</th><th>القسم / المرحلة</th><th>التدريسي</th><th>المحاضرات</th><th style="width:18%">الساعات المنجزة</th><th>متوسط الغياب</th><th>إنذار</th><th>حرمان</th>${isAdmin() ? '<th></th>' : ''}</tr></thead><tbody>
        ${d.courses.map((c) => `<tr><td><b>${esc(c.name)}</b></td><td>${esc(c.department_name || '')}<div class="xs muted">${esc(App.stageName(c.stage))}</div></td><td>${esc(c.faculty_name || '-')}</td><td class="num">${c.lectures}</td>
          <td><div class="xs muted num">${c.hours_done}/${c.total_hours}</div>${App.progress((c.hours_done / Math.max(c.total_hours, 1)) * 100)}</td><td class="num">${c.avg_absence}%</td>
          <td>${c.warnings ? `<span class="chip amber num">${c.warnings}</span>` : '<span class="muted">0</span>'}</td><td>${c.banned ? `<span class="chip red num">${c.banned}</span>` : '<span class="muted">0</span>'}</td>
          ${isAdmin() ? `<td><a class="btn btn-ghost btn-sm" href="#/teaching/${c.id}">${icon('edit', 14)} تعديل</a></td>` : ''}</tr>`).join('') || `<tr><td colspan="9">${App.empty('لا توجد مواد', '', 'book')}</td></tr>`}</tbody></table></div></div>
        <div class="card"><div class="card-head"><h3>الطلبة المعرضون للإنذار أو الحرمان</h3><button class="btn btn-ghost btn-sm" id="risk-csv" style="margin-right:auto">${icon('download', 14)} تصدير</button></div>
          ${d.at_risk.length ? `<div class="table-wrap"><table class="t"><thead><tr><th>الطالب</th><th>اسم المستخدم</th><th>المادة</th><th>مرات الغياب</th><th>النسبة</th><th>الحالة</th></tr></thead><tbody>
          ${d.at_risk.map((r) => `<tr><td>${esc(r.student)}</td><td class="ltr num" style="text-align:right">${esc(r.username)}</td><td>${esc(r.course)}</td><td class="num">${r.absent}</td><td class="num">${r.pct}%</td><td>${App.attChip(r)}</td></tr>`).join('')}</tbody></table></div>` : App.empty('لا يوجد طلبة معرضون للحرمان', '', 'check')}</div>`;
      $('#risk-csv').onclick = () => App.downloadText('at-risk.csv', '\uFEFF' + [['الطالب', 'اسم المستخدم', 'المادة', 'مرات الغياب', 'النسبة', 'الحالة'], ...d.at_risk.map((r) => [r.student, r.username, r.course, r.absent, r.pct, r.status === 'banned' ? 'محروم' : 'إنذار'])].map((r) => r.map((v) => `"${v}"`).join(',')).join('\r\n'));
    };
    view.innerHTML = `<div class="filters" style="margin-bottom:16px"><select class="input" id="af-d">${App.deptOptions('')}</select><select class="input" id="af-s">${App.stageOptions('')}</select></div><div id="att-body">${App.skeleton(2)}</div>`;
    $('#af-d').onchange = (e) => { f.department_id = e.target.value; load(); };
    $('#af-s').onchange = (e) => { f.stage = e.target.value; load(); };
    await load();
  });

  // ============================ المساعد الذكي ============================
  route('/admin/bot', async (view) => {
    setTitle('إعدادات المساعد الذكي', 'الأسئلة الشائعة ومحرك الذكاء الاصطناعي');
    const [faq, s] = await Promise.all([get('/admin/faq'), get('/admin/settings')]);
    const faqForm = (q = {}) => modal({
      title: q.id ? 'تعديل سؤال' : 'إضافة سؤال',
      body: `<label class="field"><span>السؤال</span><input class="input" name="question" value="${esc(q.question || '')}" required></label>
        <label class="field"><span>الجواب</span><textarea class="input" name="answer" rows="4" required>${esc(q.answer || '')}</textarea></label>
        <label class="field"><span>كلمات مفتاحية (مفصولة بفاصلة)</span><input class="input" name="keywords" value="${esc(q.keywords || '')}" placeholder="دوام, اوقات, ساعات"></label>`,
      actions: [{ label: 'حفظ', cls: 'btn-primary', onClick: async (b) => { const d = formData(b); if (q.id) await put(`/admin/faq/${q.id}`, d); else await post('/admin/faq', d); return true; } }, { label: 'إلغاء' }],
    }).then((ok) => ok && App.render());
    view.innerHTML = `<div class="grid cols-main">
      <div class="card"><div class="card-head"><h3>الأسئلة الشائعة (${faq.length})</h3><button class="btn btn-gold" id="fq-new" style="margin-right:auto">${icon('plus', 16)} سؤال جديد</button></div>
        <div class="list-plain">${faq.map((q) => `<div style="padding:14px 18px;border-bottom:1px solid var(--line)"><div class="row between" style="flex-wrap:nowrap;align-items:flex-start"><b>${esc(q.question)}</b>
          <div class="row" style="flex-wrap:nowrap"><button class="btn btn-ghost btn-sm" data-fedit="${q.id}" aria-label="تعديل">${icon('edit', 14)}</button><button class="btn btn-danger btn-sm" data-fdel="${q.id}" aria-label="حذف">${icon('trash', 14)}</button></div></div>
          <p class="small" style="color:var(--ink-2);margin:6px 0 0">${esc(q.answer)}</p>${q.keywords ? `<div class="xs muted" style="margin-top:4px">${esc(q.keywords)}</div>` : ''}</div>`).join('') || App.empty('لا توجد أسئلة', '', 'help')}</div></div>
      <form class="card" id="ai-form" style="align-self:start"><div class="card-head"><h3>${icon('bot', 17)} محرك المساعد</h3></div><div class="card-body">
        <label class="check"><input type="checkbox" name="bot_enabled" ${s.bot_enabled === '1' ? 'checked' : ''}> تفعيل المساعد الذكي</label>
        <label class="field"><span>اسم المساعد</span><input class="input" name="bot_name" value="${esc(s.bot_name)}"></label>
        <label class="field"><span>وضع التشغيل</span><select class="input" name="ai_mode">${opt('local', 'محلي (قواعد + بيانات النظام) - بدون إنترنت', s.ai_mode)}${opt('llm', 'نموذج لغوي (Ollama / OpenAI-compatible)', s.ai_mode)}</select></label>
        <label class="field"><span>عنوان الخادم</span><input class="input ltr" name="ai_base_url" value="${esc(s.ai_base_url)}"></label>
        <label class="field"><span>اسم النموذج</span><input class="input ltr" name="ai_model" value="${esc(s.ai_model)}"></label>
        <label class="field"><span>مفتاح API (اختياري)</span><input class="input ltr" type="password" name="ai_api_key" value="${esc(s.ai_api_key)}" autocomplete="off"></label>
        <p class="xs muted">الوضع المحلي يجيب عن الغيابات والدرجات والمواد والتبليغات والأسئلة الشائعة دون إنترنت. عند اختيار نموذج لغوي وتعذّر الاتصال به يعود المساعد تلقائياً للوضع المحلي. مثال تشغيل محلي: <span class="ltr">ollama run qwen2.5:3b</span></p>
        <button class="btn btn-primary btn-block" type="submit">${icon('check', 15)} حفظ</button></div></form></div>`;
    $('#fq-new').onclick = () => faqForm();
    $$('[data-fedit]').forEach((b) => (b.onclick = () => faqForm(faq.find((q) => q.id === Number(b.dataset.fedit)))));
    $$('[data-fdel]').forEach((b) => (b.onclick = async () => { if (await confirmBox('حذف السؤال', 'هل تريد حذف هذا السؤال؟', 'حذف')) { await del(`/admin/faq/${b.dataset.fdel}`); App.render(); } }));
    $('#ai-form').onsubmit = async (e) => { e.preventDefault(); const d = formData(e.target); d.bot_enabled = d.bot_enabled ? '1' : '0'; try { await put('/admin/settings', d); toast('تم حفظ إعدادات المساعد'); } catch (err) { fail(err); } };
  });

  // ============================ الإعدادات ============================
  route('/admin/settings', async (view) => {
    setTitle('إعدادات النظام', 'تحكم كامل بجميع خصائص النظام');
    const s = await get('/admin/settings');
    state.settingsCache = s;
    let scale = JSON.parse(s.grade_scale || '[]');
    const t = (k, label, extra = '') => `<label class="field"><span>${label}</span><input class="input ${extra}" name="${k}" value="${esc(s[k] ?? '')}"></label>`;
    const n = (k, label, min = 0, max = 100) => `<label class="field"><span>${label}</span><input class="input num" type="number" min="${min}" max="${max}" step="0.5" name="${k}" value="${esc(s[k] ?? '')}"></label>`;
    const sw = (k, label) => `<label class="check"><input type="checkbox" name="${k}" data-bool ${s[k] === '1' ? 'checked' : ''}> ${label}</label>`;
    const scaleRows = () => scale.map((g, i) => `<tr><td><input class="input ltr" data-sc="${i}" data-k="letter" value="${esc(g.letter)}" style="width:70px"></td><td><input class="input num" type="number" data-sc="${i}" data-k="min" value="${g.min}" style="width:90px"></td><td><input class="input" data-sc="${i}" data-k="ar" value="${esc(g.ar)}"></td><td><input class="input ltr" data-sc="${i}" data-k="en" value="${esc(g.en || '')}"></td><td><button type="button" class="btn btn-danger btn-sm" data-scdel="${i}" aria-label="حذف">${icon('x', 14)}</button></td></tr>`).join('');
    view.innerHTML = `<form id="sf" class="stack">
      <div class="card"><div class="card-head"><h3>${icon('building', 17)} هوية الكلية</h3></div><div class="card-body"><div class="grid-2">
        ${t('university_name', 'اسم الجامعة')}${t('college_name', 'اسم الكلية')}${t('college_name_en', 'الاسم بالإنجليزية', 'ltr')}${t('system_name', 'اسم النظام')}
        ${t('college_email', 'البريد الرسمي', 'ltr')}${t('college_phone', 'الهاتف', 'ltr')}${t('college_website', 'الموقع الإلكتروني', 'ltr')}${t('working_hours', 'أوقات الدوام')}
        ${t('academic_year', 'العام الدراسي', 'ltr')}<label class="field"><span>الفصل الحالي</span><select class="input" name="current_semester">${opt('1', 'الأول', s.current_semester)}${opt('2', 'الثاني', s.current_semester)}</select></label></div>
        <label class="field"><span>ملاحظة صفحة الدخول</span><textarea class="input" name="login_notice" rows="2">${esc(s.login_notice)}</textarea></label>
        <div class="grid-2" style="margin-top:8px">${['college', 'university'].map((w) => `<div class="logo-box"><img src="${esc(App.asset(state.info[`${w}_logo`]))}" alt=""><div><b>${w === 'college' ? 'شعار الكلية' : 'شعار الجامعة'}</b><div class="row" style="margin-top:8px">
          <label class="btn btn-ghost btn-sm">${icon('upload', 14)} تغيير<input type="file" accept="image/*" data-logo="${w}" hidden></label><button type="button" class="btn btn-ghost btn-sm" data-logo-reset="${w}">استعادة الأصلي</button></div></div></div>`).join('')}</div>
      </div></div>
      <div class="card"><div class="card-head"><h3>${icon('clipboard', 17)} الحضور والدرجات (بولونيا)</h3></div><div class="card-body"><div class="grid-3">
        ${n('absence_warning_pct', 'نسبة الإنذار %')}${n('absence_ban_pct', 'نسبة الحرمان %')}${n('pass_mark', 'درجة النجاح')}${n('default_formative_weight', 'الوزن الافتراضي للتقييم المستمر %')}${n('stages_count', 'عدد المراحل الدراسية', 1, 6)}</div>
        <div class="row">${sw('students_see_grades', 'السماح للطلبة برؤية الدرجات')}</div>
        <div class="section-title">سلم التقديرات</div>
        <div class="table-wrap"><table class="t"><thead><tr><th>الرمز</th><th>من درجة</th><th>التقدير بالعربي</th><th>بالإنجليزي</th><th></th></tr></thead><tbody id="sc-body">${scaleRows()}</tbody></table></div>
        <button type="button" class="btn btn-ghost btn-sm" id="sc-add" style="margin-top:8px">${icon('plus', 14)} إضافة تقدير</button>
      </div></div>
      <div class="card"><div class="card-head"><h3>${icon('chat', 17)} التواصل والملفات</h3></div><div class="card-body">
        <div class="row" style="margin-bottom:12px">${sw('batch_chat_enabled', 'تفعيل شات الدفعات')}${sw('faculty_in_batch_chat', 'مشاركة التدريسيين في شات دفعات موادهم')}${sw('secretary_chat_enabled', 'تفعيل مراسلة السكرتارية')}${sw('faculty_can_delete_materials', 'السماح للتدريسي بحذف ملفاته')}</div>
        <div class="grid-2">${n('max_upload_mb', 'الحد الأقصى لحجم الملف (ميغابايت)', 1, 2048)}${n('session_hours', 'مدة الجلسة (ساعات)', 1, 720)}</div>
        ${t('allowed_extensions', 'امتدادات الملفات المسموحة', 'ltr')}
      </div></div>
      <div class="card"><div class="card-head"><h3>${icon('power', 17)} النظام</h3></div><div class="card-body">
        ${sw('maintenance_mode', 'وضع الصيانة (منع دخول غير الإدارة)')}
        <div class="row" style="margin-top:12px"><a class="btn btn-ghost" href="#/profile">${icon('key', 15)} تغيير كلمة مرور الإدارة</a><a class="btn btn-ghost" href="#/admin/backup">${icon('database', 15)} النسخ الاحتياطي</a></div>
      </div></div>
      <div class="sticky-save"><button class="btn btn-primary btn-lg" type="submit">${icon('check', 16)} حفظ جميع الإعدادات</button></div>
    </form>`;
    const form = $('#sf');
    const bindScale = () => {
      $$('[data-sc]', form).forEach((i) => (i.oninput = () => { const g = scale[i.dataset.sc]; g[i.dataset.k] = i.dataset.k === 'min' ? Number(i.value) : i.value; }));
      $$('[data-scdel]', form).forEach((b) => (b.onclick = () => { scale.splice(Number(b.dataset.scdel), 1); $('#sc-body').innerHTML = scaleRows(); bindScale(); }));
    };
    bindScale();
    $('#sc-add').onclick = () => { scale.push({ letter: '', min: 0, ar: '', en: '' }); $('#sc-body').innerHTML = scaleRows(); bindScale(); };
    $$('[data-logo]').forEach((inp) => (inp.onchange = async () => {
      const fd = new FormData(); fd.append('file', inp.files[0]);
      try { await App.uploadWithProgress(`/admin/branding/${inp.dataset.logo}`, fd); state.info = { ...state.info, ...(await get('/public/info')) }; toast('تم تغيير الشعار'); location.reload(); } catch (e) { fail(e); }
    }));
    $$('[data-logo-reset]').forEach((b) => (b.onclick = async () => { await post(`/admin/branding/${b.dataset.logoReset}/reset`); location.reload(); }));
    form.onsubmit = async (e) => {
      e.preventDefault();
      const d = {};
      $$('[name]', form).forEach((el) => { if (el.type === 'file') return; d[el.name] = el.type === 'checkbox' ? (el.checked ? '1' : '0') : el.value; });
      if (Number(d.absence_warning_pct) >= Number(d.absence_ban_pct)) return fail(new Error('نسبة الإنذار يجب أن تكون أقل من نسبة الحرمان'));
      d.grade_scale = JSON.stringify(scale.filter((g) => g.letter).sort((a, b) => b.min - a.min));
      try { await put('/admin/settings', d); state.info = { ...state.info, ...(await get('/public/info')) }; toast('تم حفظ الإعدادات وتطبيقها على جميع الأجهزة'); } catch (err) { fail(err); }
    };
  });

  // ============================ الشبكة ============================
  route('/admin/network', async (view) => {
    setTitle('الشبكة والأجهزة', 'ربط أجهزة القسم عبر الشبكة المحلية (LAN)');
    const [n, sessions] = await Promise.all([get('/admin/network'), isAdmin() ? get('/admin/sessions') : []]);
    view.innerHTML = `
      <div class="grid cols-3" style="margin-bottom:20px">
        <div class="stat"><div class="ic">${icon('wifi')}</div><div><div class="v num">${n.online}</div><div class="l">اتصال فوري نشط الآن</div></div></div>
        <div class="stat"><div class="ic gold">${icon('monitor')}</div><div><div class="v" style="font-size:16px">${esc(n.hostname)}</div><div class="l">اسم جهاز السيرفر · المنفذ <span class="num">${n.port}</span></div></div></div>
        <div class="stat"><div class="ic">${icon('database')}</div><div><div class="v" style="font-size:16px">SQLite</div><div class="l">${esc(n.db_engine)} · Node ${esc(n.node)}</div></div></div>
      </div>
      <div class="card" style="margin-bottom:20px"><div class="card-head"><h3>عناوين الدخول من الأجهزة الأخرى</h3></div><div class="card-body">
        ${n.ips.length ? `<div class="grid auto-fill">${n.ips.map((ip) => `<div class="qr-card"><img class="qr" src="${ip.qr}" alt="رمز QR للعنوان ${esc(ip.url)}" width="180" height="180"><b class="ltr num">${esc(ip.url)}</b><span class="xs muted">${esc(ip.name)}</span></div>`).join('')}</div>` : App.empty('لا توجد شبكة محلية', 'وصّل الجهاز بالراوتر', 'wifi')}
        <div class="banner info" style="margin-top:16px">${icon('help')}<span>امسح رمز QR بكاميرا الهاتف أو اكتب العنوان في متصفح أي جهاز متصل بنفس الشبكة. لثبات العنوان اجعل IP الجهاز ثابتاً من إعدادات الراوتر، واسمح بالمنفذ <b class="num">${n.port}</b> في جدار حماية Windows.</span></div>
      </div></div>
      ${isAdmin() ? `<div class="card"><div class="card-head"><h3>الجلسات النشطة (${sessions.length})</h3></div><div class="table-wrap"><table class="t"><thead><tr><th>المستخدم</th><th>الدور</th><th>عنوان الجهاز</th><th>المتصفح</th><th>منذ</th><th></th></tr></thead><tbody>
        ${sessions.map((x) => `<tr><td>${esc(x.full_name)} ${x.current ? '<span class="chip teal">جلستك</span>' : ''}${x.impersonated_by ? '<span class="chip amber">دخول إداري</span>' : ''}</td><td>${ROLE_SHORT[x.role]}</td><td class="ltr num" style="text-align:right">${esc(x.ip || '')}</td><td class="xs muted" style="max-width:260px">${esc((x.user_agent || '').slice(0, 70))}</td><td class="xs num">${esc(x.created_at)}</td>
          <td>${x.current ? '' : `<button class="btn btn-danger btn-sm" data-kill="${esc(x.id)}">${icon('logout', 14)} إنهاء</button>`}</td></tr>`).join('')}</tbody></table></div></div>` : ''}`;
    $$('[data-kill]').forEach((b) => (b.onclick = async () => { await del(`/admin/sessions/${b.dataset.kill}`); toast('تم إنهاء الجلسة'); App.render(); }));
  });

  // ============================ سجل العمليات ============================
  route('/admin/audit', async (view) => {
    setTitle('سجل العمليات', 'كل تعديل على الدرجات والحسابات والإعدادات مسجّل بالاسم والوقت والجهاز');
    let q = '';
    const load = async () => {
      const rows = await get(`/admin/audit${q ? `?q=${encodeURIComponent(q)}` : ''}`);
      $('#au').innerHTML = `<table class="t"><thead><tr><th>الوقت</th><th>المستخدم</th><th>العملية</th><th>التفاصيل</th><th>الجهاز</th></tr></thead><tbody>
        ${rows.map((a) => `<tr><td class="xs num" style="white-space:nowrap">${esc(a.created_at)}</td><td>${esc(a.user_name || '-')}</td><td><b class="small">${esc(a.action)}</b></td><td class="small">${esc(a.details || '')}</td><td class="ltr xs num" style="text-align:right">${esc(a.ip || '')}</td></tr>`).join('') || `<tr><td colspan="5">${App.empty('لا توجد عمليات', '', 'history')}</td></tr>`}</tbody></table>`;
    };
    view.innerHTML = `<div class="card"><div class="card-head"><div class="filters"><div class="input-icon">${icon('search')}<input class="input" id="aq" placeholder="بحث في السجل (مثال: تعديل درجة)"></div></div>
      <div class="actions"><button class="btn btn-ghost btn-sm" id="a-clean">${icon('trash', 14)} حذف الأقدم من 90 يوماً</button></div></div><div class="table-wrap" id="au"></div></div>`;
    let tm; $('#aq').oninput = (e) => { clearTimeout(tm); tm = setTimeout(() => { q = e.target.value.trim(); load(); }, 250); };
    $('#a-clean').onclick = async () => { if (await confirmBox('تنظيف السجل', 'حذف السجلات الأقدم من 90 يوماً؟', 'حذف')) { await del('/admin/audit?days=90'); load(); } };
    await load();
  });

  // ============================ النسخ الاحتياطي ============================
  route('/admin/backup', async (view) => {
    setTitle('النسخ الاحتياطي والبيانات', 'حماية بيانات القسم من الضياع');
    view.innerHTML = `<div class="grid cols-2">
      <div class="card card-pad"><div class="ic-big">${icon('download', 26)}</div><h3>تنزيل نسخة احتياطية</h3><p class="small muted">ملف واحد يحتوي جميع الحسابات والمواد والدرجات والحضور والرسائل. يُنصح بحفظ نسخة أسبوعياً على فلاش خارجي. (الملازم المرفوعة موجودة في مجلد <span class="ltr">uploads</span> وتُنسخ يدوياً.)</p>
        <a class="btn btn-primary" href="${esc(App.fileUrl('/admin/backup'))}">${icon('download', 15)} تنزيل الآن</a></div>
      <div class="card card-pad"><div class="ic-big gold">${icon('upload', 26)}</div><h3>استعادة نسخة</h3><p class="small muted">استبدال البيانات الحالية بنسخة سابقة. تُحفظ نسخة أمان تلقائية من البيانات الحالية قبل الاستعادة.</p>
        <label class="btn btn-gold">${icon('upload', 15)} اختيار ملف .db<input type="file" accept=".db,.sqlite" id="rs" hidden></label></div>
      <div class="card card-pad"><div class="ic-big">${icon('layers', 26)}</div><h3>بيانات تجريبية</h3><p class="small muted">تحميل تدريسيين وطلبة ومواد ودرجات وحضور تجريبية لعرض النظام وتجربته (كلمة المرور 123456).</p>
        <button class="btn btn-ghost" id="demo">${icon('refresh', 15)} تحميل البيانات التجريبية</button></div>
      <div class="card card-pad" style="border-color:var(--danger-line,#f3c2c2)"><div class="ic-big red">${icon('alert', 26)}</div><h3>تصفير النظام</h3><p class="small muted">حذف جميع الطلبة والتدريسيين والمواد والدرجات والرسائل والملفات مع الإبقاء على حسابات الإدارة والإعدادات والأقسام. استخدمه لبدء عام دراسي جديد بعد أخذ نسخة احتياطية.</p>
        <button class="btn btn-danger" id="reset">${icon('trash', 15)} تصفير النظام</button></div></div>`;
    $('#rs').onchange = async (e) => {
      const file = e.target.files[0]; if (!file) return;
      if (!(await confirmBox('استعادة نسخة احتياطية', `سيتم استبدال جميع البيانات الحالية بمحتوى "${file.name}". متابعة؟`, 'استعادة'))) return;
      const fd = new FormData(); fd.append('file', file);
      try { const r = await App.uploadWithProgress('/admin/restore', fd); toast(`تمت الاستعادة. نسخة الأمان: ${r.safety_copy}`); setTimeout(() => location.reload(), 1200); } catch (err) { fail(err); }
    };
    $('#demo').onclick = async () => { if (!(await confirmBox('بيانات تجريبية', 'ستُضاف بيانات تجريبية إلى النظام. متابعة؟', 'تحميل', false))) return; try { await post('/admin/demo-data'); toast('تم تحميل البيانات التجريبية'); state.departments = await get('/departments'); } catch (e) { fail(e); } };
    $('#reset').onclick = async () => {
      const ok = await modal({ title: 'تصفير النظام', body: `<div class="banner danger">${icon('alert')}<span>عملية لا يمكن التراجع عنها. خذ نسخة احتياطية أولاً.</span></div><label class="field"><span>اكتب كلمة <b>تصفير</b> للتأكيد</span><input class="input" name="confirm"></label>`,
        actions: [{ label: 'تصفير نهائي', cls: 'btn-danger', onClick: async (b) => { await post('/admin/reset-system', formData(b)); return true; } }, { label: 'إلغاء' }] });
      if (ok) toast('تم تصفير النظام');
    };
  });
})();
