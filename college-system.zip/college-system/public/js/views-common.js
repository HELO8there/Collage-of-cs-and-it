/* =====================================================================
   صفحات مشتركة: الدخول، الرئيسية، التبليغات، الشات، المساعد، الكادر، الحساب
   ===================================================================== */
(function () {
  const { icon, esc, $, $$, get, post, put, del, toast, fail, modal, confirmBox, formData, opt, route, setTitle, navigate, state } = App;

  // ============================ الدخول ============================
  App.views.login = function () {
    const i = state.info;
    $('#app').innerHTML = `
    <div class="login">
      <section class="login-hero" style="--hero-img:url('img/college-building.jpg')">
        <div class="brand-row">
          <img class="logo uni" src="${esc(App.asset(i.university_logo))}" alt="شعار جامعة كركوك">
          <img class="logo" src="${esc(App.asset(i.college_logo))}" alt="شعار الكلية">
          <div><div class="t1">${esc(i.university_name)}</div><div class="t2">${esc(i.college_name)}</div></div>
        </div>
        <div>
          <h1>${esc(i.system_name)} <em>للأقسام العلمية</em></h1>
          <p>منصة موحدة لإدارة المواد والملازم، الحضور والغياب، درجات التقييم المستمر وفق مسار بولونيا (ECTS)، والتواصل الفوري بين الطلبة والتدريسيين وإدارة القسم.</p>
          <div class="hero-depts">${i.departments.map((d) => `<div><b>قسم ${esc(d.name)}</b><span class="ltr" style="opacity:.7;font-size:12px">${esc(d.name_en || '')}</span></div>`).join('')}</div>
        </div>
        <div class="hero-foot">
          <span>${icon('mail', 14)} <span class="ltr">${esc(i.college_email)}</span></span>
          <span>${icon('phone', 14)} <span class="ltr">${esc(i.college_phone)}</span></span>
          <span>${icon('clock', 14)} ${esc(i.working_hours)}</span>
        </div>
      </section>
      <section class="login-side">
        <form class="login-card" id="login-form" autocomplete="on">
          <div class="crest"><img src="${esc(App.asset(i.college_logo))}" alt=""></div>
          <h2>تسجيل الدخول</h2>
          <p class="sub">العام الدراسي <span class="ltr">${esc(i.academic_year)}</span></p>
          ${i.maintenance_mode ? `<div class="banner warn">${icon('alert')}<span>النظام في وضع الصيانة. الدخول متاح للإدارة فقط.</span></div>` : ''}
          <label class="field"><span>اسم المستخدم</span>
            <div class="input-icon">${icon('user')}<input class="input ltr" name="username" required autocomplete="username" placeholder="مثال: cs1001" style="text-align:right"></div></label>
          <label class="field"><span>كلمة المرور</span>
            <div class="input-icon">${icon('key')}<input class="input" type="password" name="password" required autocomplete="current-password" placeholder="••••••••"></div></label>
          <button class="btn btn-primary btn-block btn-lg" type="submit">${icon('login')} دخول</button>
          <div class="login-note">${icon('shield', 16)}<span>${esc(i.login_notice)}</span></div>
          <div class="demo-accounts" id="demo-acc">
            <div>حسابات تجريبية للعرض (كلمة المرور <b class="ltr">123456</b>):</div>
            <button type="button" data-u="admin" data-p="m1m2m3m4m">الإدارة: admin</button>
            <button type="button" data-u="f.ahmed" data-p="123456">تدريسي: f.ahmed</button>
            <button type="button" data-u="cs1001" data-p="123456">طالب: cs1001</button>
            <button type="button" data-u="secretary" data-p="123456">السكرتارية</button>
          </div>
        </form>
      </section>
    </div>`;
    const form = $('#login-form');
    $$('#demo-acc [data-u]').forEach((b) => (b.onclick = () => { form.username.value = b.dataset.u; form.password.value = b.dataset.p; form.requestSubmit(); }));
    form.onsubmit = async (e) => {
      e.preventDefault();
      const btn = $('button[type=submit]', form);
      btn.disabled = true;
      try {
        const r = await post('/auth/login', formData(form));
        await App.afterLogin(r.token, r.user, r.default_password);
      } catch (err) { fail(err); btn.disabled = false; }
    };
  };

  // ============================ الرئيسية ============================
  route('/', async (view) => {
    const role = state.user.role;
    if (role === 'student') return App.views.studentHome(view);
    if (role === 'faculty') return App.views.facultyHome(view);
    return App.views.adminHome(view);
  });

  App.views.annList = function (list, opts = {}) {
    if (!list.length) return App.empty('لا توجد تبليغات', 'ستظهر هنا التبليغات والتعاميم الرسمية', 'bell');
    const icMap = { exam: 'calendar', rules: 'shield', meeting: 'users', event: 'star', circular: 'file', notice: 'bell' };
    return list.map((a) => `
      <article class="ann ${esc(a.priority)} ${opts.showUnread && !a.is_read ? 'unread' : ''}">
        <div class="ic">${icon(icMap[a.category] || 'bell', 20)}</div>
        <div style="flex:1;min-width:0">
          <h4>${a.pinned ? `<span title="مثبّت" style="color:var(--gold-ink)">${icon('pin', 15)}</span>` : ''}${esc(a.title)}
            ${a.priority !== 'normal' ? `<span class="chip ${a.priority === 'urgent' ? 'red' : 'gold'}">${esc(App.PRIORITY[a.priority])}</span>` : ''}
            <span class="chip">${esc(App.ANN_CAT[a.category] || 'تبليغ')}</span></h4>
          <p>${opts.short ? esc(a.content.slice(0, 170)) + (a.content.length > 170 ? '…' : '') : esc(a.content)}</p>
          <div class="foot">
            <span>${icon('calendar', 13)} <span class="num">${esc(App.fmtDate(a.created_at))}</span></span>
            ${a.author_name ? `<span>${esc(a.author_name)}</span>` : ''}
            ${opts.staff ? `<span>${esc(targetLabel(a))}</span><span>${icon('eye', 13)} ${a.reads || 0} قراءة</span>` : ''}
            ${opts.staff ? `<span style="margin-right:auto" class="row"><button class="btn btn-ghost btn-sm" data-edit-ann="${a.id}">${icon('edit', 14)} تعديل</button><button class="btn btn-danger btn-sm" data-del-ann="${a.id}">${icon('trash', 14)}</button></span>` : ''}
          </div>
        </div>
      </article>`).join('');
  };
  function targetLabel(a) {
    const who = { all: 'الجميع', student: 'الطلبة', faculty: 'التدريسيون' }[a.target_role] || a.target_role;
    return [who, a.department_name ? `قسم ${a.department_name}` : '', a.target_stage ? App.stageName(a.target_stage) : '', a.target_study_type ? App.STUDY[a.target_study_type] : ''].filter(Boolean).join(' · ');
  }

  // ============================ التبليغات ============================
  route('/announcements', async (view) => {
    const staff = ['admin', 'secretary'].includes(state.user.role);
    setTitle(staff ? 'التبليغات والتعاميم' : 'التبليغات', staff ? 'إرسال التبليغات للقسم أو لدفعة محددة' : 'آخر القوانين والتعاميم الرسمية');
    let filter = '';
    const draw = async () => {
      const list = await get('/announcements');
      const shown = filter ? list.filter((a) => a.category === filter) : list;
      view.innerHTML = `
        <div class="card">
          <div class="card-head">
            <div class="filters">
              <select class="input" id="ann-filter">${opt('', 'كل الأنواع', filter)}${Object.entries(App.ANN_CAT).map(([k, v]) => opt(k, v, filter)).join('')}</select>
            </div>
            <div class="actions">
              ${!staff ? `<button class="btn btn-ghost btn-sm" id="read-all">${icon('check', 15)} تعليم الكل كمقروء</button>` : ''}
              ${staff ? `<button class="btn btn-gold" id="new-ann">${icon('plus', 16)} تبليغ جديد</button>` : ''}
            </div>
          </div>
          <div>${App.views.annList(shown, { staff, showUnread: !staff })}</div>
        </div>`;
      $('#ann-filter').onchange = (e) => { filter = e.target.value; draw(); };
      const ra = $('#read-all'); if (ra) ra.onclick = async () => { await post('/announcements/read-all'); App.refreshUnread(); draw(); };
      const na = $('#new-ann'); if (na) na.onclick = () => annForm().then((ok) => ok && draw());
      $$('[data-edit-ann]').forEach((b) => (b.onclick = () => annForm(list.find((a) => a.id === Number(b.dataset.editAnn))).then((ok) => ok && draw())));
      $$('[data-del-ann]').forEach((b) => (b.onclick = async () => { if (await confirmBox('حذف التبليغ', 'هل تريد حذف هذا التبليغ نهائياً؟', 'حذف')) { await del(`/announcements/${b.dataset.delAnn}`); toast('تم الحذف'); draw(); } }));
      if (!staff) { setTimeout(async () => { await post('/announcements/read-all'); App.refreshUnread(); }, 2500); }
    };
    await draw();
  });

  function annForm(a = {}) {
    const body = `
      <label class="field"><span>العنوان</span><input class="input" name="title" value="${esc(a.title || '')}" required></label>
      <label class="field"><span>نص التبليغ</span><textarea class="input" name="content" rows="6" required>${esc(a.content || '')}</textarea></label>
      <div class="grid-2">
        <label class="field"><span>النوع</span><select class="input" name="category">${Object.entries(App.ANN_CAT).map(([k, v]) => opt(k, v, a.category || 'notice')).join('')}</select></label>
        <label class="field"><span>الأهمية</span><select class="input" name="priority">${Object.entries(App.PRIORITY).map(([k, v]) => opt(k, v, a.priority || 'normal')).join('')}</select></label>
      </div>
      <div class="section-title">الجهة المستهدفة</div>
      <div class="grid-2">
        <label class="field"><span>موجه إلى</span><select class="input" name="target_role">${opt('all', 'الجميع', a.target_role)}${opt('student', 'الطلبة', a.target_role)}${opt('faculty', 'التدريسيين', a.target_role)}</select></label>
        <label class="field"><span>القسم</span><select class="input" name="target_department_id">${App.deptOptions(a.target_department_id, 'جميع الأقسام')}</select></label>
        <label class="field"><span>المرحلة (الدفعة)</span><select class="input" name="target_stage">${App.stageOptions(a.target_stage, 'جميع المراحل')}</select></label>
        <label class="field"><span>نوع الدراسة</span><select class="input" name="target_study_type">${opt('', 'الكل', a.target_study_type)}${opt('morning', 'صباحي', a.target_study_type)}${opt('evening', 'مسائي', a.target_study_type)}</select></label>
      </div>
      <label class="check"><input type="checkbox" name="pinned" ${a.pinned ? 'checked' : ''}> تثبيت في أعلى القائمة</label>`;
    return modal({
      title: a.id ? 'تعديل التبليغ' : 'تبليغ جديد', body,
      actions: [{ label: `${icon('send', 15)} ${a.id ? 'حفظ' : 'نشر الآن'}`, cls: 'btn-primary', onClick: async (b) => {
        const d = formData(b);
        if (!d.title || !d.content) throw new Error('العنوان والنص مطلوبان');
        if (a.id) await put(`/announcements/${a.id}`, d); else await post('/announcements', d);
        toast(a.id ? 'تم حفظ التعديل' : 'تم نشر التبليغ وإرساله لحظياً');
        return true;
      } }, { label: 'إلغاء' }],
    });
  }
  App.views.annForm = annForm;

  // ============================ الشات ============================
  function chatUI(view, { rooms, initial, single, title, canModerate, emptyText }) {
    let current = initial || (rooms[0] && rooms[0].room);
    let typingTimer = null;
    view.innerHTML = `
      <div class="card chat ${single ? 'single' : ''}" id="chat">
        ${single ? '' : `<div class="chat-list" id="chat-list"></div>`}
        <div class="chat-main">
          <div class="chat-head">
            ${single ? '' : `<button class="btn btn-ghost btn-icon mobile-only" id="chat-back" aria-label="المحادثات">${icon('back')}</button>`}
            <div class="avatar teal">${icon(single ? 'inbox' : 'users', 18)}</div>
            <div style="min-width:0"><h3 id="chat-title">${esc(title || '')}</h3><div class="xs muted" id="chat-sub"></div></div>
            ${canModerate ? `<button class="btn btn-danger btn-sm" id="chat-clear" style="margin-right:auto">${icon('trash', 14)} مسح المحادثة</button>` : ''}
          </div>
          <div class="chat-msgs" id="msgs"></div>
          <div class="typing" id="typing"></div>
          <form class="chat-input" id="chat-form">
            <textarea class="input" id="chat-text" rows="1" placeholder="اكتب رسالتك..." aria-label="نص الرسالة"></textarea>
            <button class="btn btn-teal" type="submit" aria-label="إرسال">${icon('send', 16)} إرسال</button>
          </form>
        </div>
      </div>`;
    const msgsEl = $('#msgs'), text = $('#chat-text');
    const drawList = () => {
      const l = $('#chat-list'); if (!l) return;
      l.innerHTML = rooms.length ? rooms.map((r) => `
        <div class="chat-item ${r.room === current ? 'active' : ''}" data-room="${esc(r.room)}">
          <div class="avatar ${r.unread ? '' : 'teal'}">${esc(App.initials(r.label))}</div>
          <div style="min-width:0;flex:1"><div class="n">${esc(r.label)}</div><div class="p">${r.last ? esc(`${r.last.full_name ? r.last.full_name.split(' ')[0] + ': ' : ''}${r.last.content}`) : esc(r.sub || 'لا توجد رسائل')}</div></div>
          ${r.unread ? `<span class="badge">${r.unread}</span>` : ''}
        </div>`).join('') : App.empty('لا توجد محادثات', emptyText || '', 'chat');
      $$('.chat-item', l).forEach((it) => (it.onclick = () => { current = it.dataset.room; const r = rooms.find((x) => x.room === current); if (r) r.unread = 0; drawList(); load(); $('#chat').classList.remove('show-list'); }));
    };
    const msgHTML = (m) => {
      const me = m.sender_id === state.user.id;
      const staff = ['admin', 'secretary', 'faculty'].includes(m.sender_role);
      const canDel = me || state.user.role === 'admin';
      const roleTag = m.sender_role === 'faculty' ? 'تدريسي' : m.sender_role === 'admin' ? 'الإدارة' : m.sender_role === 'secretary' ? 'السكرتارية' : '';
      return `<div class="msg ${me ? 'me' : ''} ${staff ? 'staff' : ''}" data-id="${m.id}">
        ${!me ? `<div class="who">${esc(m.sender_name || '')}${roleTag ? `<span class="chip gold" style="padding:0 6px;font-size:10.5px">${roleTag}</span>` : ''}</div>` : ''}
        <div class="txt">${esc(m.content)}</div><div class="tm num">${esc(App.fmtTime(m.created_at))}</div>
        ${canDel ? `<button class="del" data-del="${m.id}" title="حذف" aria-label="حذف الرسالة">${icon('trash', 13)}</button>` : ''}</div>`;
    };
    let lastDay = '';
    const append = (m, scroll = true) => {
      const day = App.fmtDate(m.created_at);
      if (day !== lastDay) { msgsEl.insertAdjacentHTML('beforeend', `<div class="day-sep num">${esc(day)}</div>`); lastDay = day; }
      msgsEl.insertAdjacentHTML('beforeend', msgHTML(m));
      if (scroll) msgsEl.scrollTop = msgsEl.scrollHeight;
    };
    async function load() {
      if (!current) { msgsEl.innerHTML = App.empty('اختر محادثة', '', 'chat'); return; }
      msgsEl.innerHTML = '<div class="skeleton" style="height:40px;width:40%"></div>';
      const r = await get(`/chat/messages?room=${encodeURIComponent(current)}`);
      const meta = rooms.find((x) => x.room === current);
      $('#chat-title').textContent = title || r.label;
      $('#chat-sub').textContent = meta && meta.members ? `${meta.members} طالب في الدفعة` : (meta?.sub || '');
      msgsEl.innerHTML = ''; lastDay = '';
      if (!r.messages.length) msgsEl.innerHTML = `<div class="empty" data-empty>${icon('chat', 44)}<b>ابدأ المحادثة</b>لا توجد رسائل بعد</div>`;
      r.messages.forEach((m) => append(m, false));
      msgsEl.scrollTop = msgsEl.scrollHeight;
      App.refreshUnread();
    }
    msgsEl.addEventListener('click', async (e) => {
      const b = e.target.closest('[data-del]'); if (!b) return;
      if (await confirmBox('حذف الرسالة', 'هل تريد حذف هذه الرسالة؟', 'حذف')) { try { await del(`/chat/messages/${b.dataset.del}`); } catch (err) { fail(err); } }
    });
    $('#chat-form').onsubmit = (e) => {
      e.preventDefault();
      const content = text.value.trim();
      if (!content || !current) return;
      if (!state.socket || !state.socket.connected) return fail(new Error('الاتصال الفوري غير متاح حالياً، أعد المحاولة بعد لحظات'));
      state.socket.emit('chat:send', { room: current, content }, (ack) => { if (ack && ack.error) fail(new Error(ack.error)); });
      text.value = ''; text.style.height = '';
    };
    text.addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); $('#chat-form').requestSubmit(); } });
    text.addEventListener('input', () => {
      text.style.height = 'auto'; text.style.height = Math.min(140, text.scrollHeight) + 'px';
      if (state.socket && current) state.socket.emit('chat:typing', { room: current });
    });
    const back = $('#chat-back'); if (back) back.onclick = () => $('#chat').classList.add('show-list');
    const clr = $('#chat-clear'); if (clr) clr.onclick = async () => { if (await confirmBox('مسح المحادثة', 'سيتم إخفاء جميع رسائل هذه المحادثة. هل أنت متأكد؟', 'مسح')) { await post('/chat/clear', { room: current }); load(); } };

    const offs = [
      App.on('chat:message', (m) => {
        if (!document.body.contains(msgsEl)) return;
        if (m.room === current) { $('[data-empty]', msgsEl)?.remove(); append(m); $('#typing').textContent = ''; }
        const r = rooms.find((x) => x.room === m.room);
        if (r) { r.last = { content: m.content, full_name: m.sender_name }; if (m.room !== current && m.sender_id !== state.user.id) r.unread = (r.unread || 0) + 1; rooms.sort((a, b) => (b.room === m.room) - (a.room === m.room)); drawList(); }
        else if (opts_onNewRoom) opts_onNewRoom(m);
      }),
      App.on('chat:deleted', (d) => { if (d.room === current) $(`.msg[data-id="${d.id}"]`, msgsEl)?.remove(); }),
      App.on('chat:cleared', (d) => { if (d.room === current) load(); }),
      App.on('chat:typing', (d) => {
        if (d.room !== current || d.id === state.user.id) return;
        $('#typing').textContent = `${d.name} يكتب الآن...`;
        clearTimeout(typingTimer); typingTimer = setTimeout(() => { const t = $('#typing'); if (t) t.textContent = ''; }, 2500);
      }),
    ];
    let opts_onNewRoom = null;
    const cleanup = () => { offs.forEach((f) => f()); window.removeEventListener('hashchange', cleanup); };
    window.addEventListener('hashchange', cleanup);
    drawList();
    load();
    return { setOnNewRoom: (fn) => (opts_onNewRoom = fn), rooms, drawList, reload: load, select: (room) => { current = room; drawList(); load(); } };
  }

  route('/chat', async (view) => {
    const role = state.user.role;
    setTitle(role === 'student' ? 'شات الدفعة' : role === 'admin' ? 'شات الدفعات (إشراف)' : 'شات الدفعات', role === 'student' ? `${state.user.department_name} · ${App.stageName(state.user.stage)} · ${App.STUDY[state.user.study_type]}` : 'محادثات جماعية فورية لكل دفعة ومرحلة');
    const rooms = await get('/chat/rooms');
    if (!rooms.length) { view.innerHTML = `<div class="card">${App.empty('شات الدفعات غير متاح', role === 'faculty' ? 'لا توجد مواد مسندة إليك حالياً أو أن الإدارة أوقفت مشاركة التدريسيين.' : 'تم إيقاف شات الدفعة من قبل الإدارة.', 'chat')}</div>`; return; }
    chatUI(view, { rooms, single: role === 'student', title: role === 'student' ? rooms[0].label : null, canModerate: role === 'admin' });
  });

  // الطالب ← السكرتارية
  route('/secretary', async (view) => {
    setTitle('مراسلة السكرتارية', 'محادثة مباشرة وخاصة مع سكرتارية القسم للاستفسارات والمعاملات');
    chatUI(view, { rooms: [{ room: `dm:${state.user.id}`, label: 'سكرتارية القسم', sub: 'ردود السكرتارية خلال أوقات الدوام' }], single: true, title: 'سكرتارية القسم' });
  });

  // السكرتارية/الإدارة: صندوق الرسائل
  route('/inbox', async (view) => {
    setTitle('رسائل الطلبة', 'الرد الفوري على استفسارات ومعاملات الطلبة');
    const threads = await get('/dm/threads');
    const rooms = threads.map((t) => ({ room: `dm:${t.student_id}`, label: t.full_name || 'طالب', sub: `${t.department_name || ''} · ${App.stageName(t.stage)}`, last: t.last ? { content: t.last.content } : null, unread: t.unread }));
    if (!rooms.length) { view.innerHTML = `<div class="card">${App.empty('لا توجد رسائل', 'ستظهر هنا رسائل الطلبة فور وصولها', 'inbox')}</div>`; App.on('chat:message', () => state.route === '/inbox' && App.render()); return; }
    const ui = chatUI(view, { rooms, emptyText: '' });
    ui.setOnNewRoom((m) => { ui.rooms.unshift({ room: m.room, label: m.sender_name, last: { content: m.content }, unread: 1 }); ui.drawList(); });
  });

  // ============================ المساعد الذكي ============================
  route('/bot', async (view) => {
    setTitle(state.info.bot_name || 'المساعد الذكي', 'اسأل عن غياباتك، درجاتك، موادك، التبليغات ونظام بولونيا');
    const history = [];
    const sugg = state.user.role === 'student'
      ? ['كم غياباتي؟', 'شنو درجاتي؟', 'ما هي موادي؟', 'آخر التبليغات', 'ما معنى FX؟', 'ما هو مسار بولونيا؟']
      : state.user.role === 'faculty' ? ['من هم الطلبة المعرضون للحرمان؟', 'آخر التبليغات', 'سلم التقديرات']
        : ['ملخص النظام', 'الطلبة المعرضون للحرمان', 'آخر التبليغات', 'سلم التقديرات'];
    view.innerHTML = `
      <div class="card chat single" style="height:calc(100vh - 64px - 72px)">
        <div class="chat-main">
          <div class="chat-head"><div class="avatar">${icon('bot', 18)}</div><div><h3>${esc(state.info.bot_name || 'المساعد الذكي')}</h3><div class="xs muted" id="bot-mode">يعمل محلياً على سيرفر الكلية</div></div></div>
          <div class="chat-msgs" id="bmsgs"></div>
          <div class="suggest">${sugg.map((s) => `<button type="button" data-s="${esc(s)}">${esc(s)}</button>`).join('')}</div>
          <form class="chat-input" id="bform"><textarea class="input" id="btext" rows="1" placeholder="اكتب سؤالك..." aria-label="السؤال"></textarea><button class="btn btn-gold" type="submit">${icon('send', 16)} اسأل</button></form>
        </div>
      </div>`;
    const box = $('#bmsgs');
    const add = (who, text, me) => {
      box.insertAdjacentHTML('beforeend', `<div class="msg ${me ? 'me' : 'bot-msg'}">${me ? '' : `<div class="who">${icon('bot', 13)} ${esc(who)}</div>`}<div class="txt">${esc(text)}</div></div>`);
      box.scrollTop = box.scrollHeight;
    };
    const ask = async (q) => {
      if (!q.trim()) return;
      add('', q, true);
      history.push({ role: 'user', content: q });
      box.insertAdjacentHTML('beforeend', '<div class="msg bot-msg" id="thinking"><div class="txt muted">يكتب...</div></div>');
      box.scrollTop = box.scrollHeight;
      try {
        const r = await post('/bot', { message: q, history: history.slice(-6) });
        $('#thinking')?.remove();
        add(state.info.bot_name || 'المساعد', r.reply);
        history.push({ role: 'assistant', content: r.reply });
        $('#bot-mode').textContent = r.mode === 'llm' ? 'متصل بنموذج ذكاء اصطناعي محلي' : 'يعمل محلياً على سيرفر الكلية';
      } catch (e) { $('#thinking')?.remove(); fail(e); }
    };
    const r0 = await post('/bot', { message: 'مرحبا' });
    add(state.info.bot_name || 'المساعد', r0.reply);
    $$('.suggest [data-s]').forEach((b) => (b.onclick = () => ask(b.dataset.s)));
    const t = $('#btext');
    $('#bform').onsubmit = (e) => { e.preventDefault(); const q = t.value; t.value = ''; ask(q); };
    t.addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); $('#bform').requestSubmit(); } });
  });

  // ============================ الكادر التدريسي ============================
  route('/faculty', async (view) => {
    setTitle('الكادر التدريسي', 'التدريسيون والمواد والدفعات التي يدرّسونها');
    const list = await get('/faculty-directory');
    let dep = '';
    const draw = () => {
      const shown = dep ? list.filter((f) => f.department_name === dep) : list;
      view.innerHTML = `
        <div class="row between" style="margin-bottom:16px">
          <div class="seg" id="dseg"><button class="${!dep ? 'on' : ''}" data-d="">الكل</button>${state.departments.map((d) => `<button class="${dep === d.name ? 'on' : ''}" data-d="${esc(d.name)}">${esc(d.name)}</button>`).join('')}</div>
          <span class="muted small">${shown.length} تدريسي</span>
        </div>
        <div class="grid auto-fill">${shown.map((f) => `
          <div class="card card-pad">
            <div class="row" style="align-items:flex-start;flex-wrap:nowrap">
              <div class="avatar lg">${esc(App.initials(f.full_name))}</div>
              <div style="min-width:0">
                <div class="small" style="color:var(--gold-ink);font-weight:600">${esc(f.academic_title || '')}</div>
                <h4 style="font-size:16px">${esc(f.full_name)}</h4>
                <div class="small muted">قسم ${esc(f.department_name || '-')}</div>
              </div>
            </div>
            ${f.bio ? `<p class="small" style="color:var(--ink-2);margin:12px 0 0">${esc(f.bio)}</p>` : ''}
            <div style="margin-top:12px;display:flex;flex-wrap:wrap;gap:6px">${f.courses.map((c) => `<span class="chip teal">${esc(c.name)} · م${c.stage}</span>`).join('') || '<span class="muted small">لا توجد مواد مسندة</span>'}</div>
            <div class="small muted" style="margin-top:12px;display:grid;gap:4px">
              ${f.email ? `<span>${icon('mail', 13)} <span class="ltr">${esc(f.email)}</span></span>` : ''}
              ${f.office_hours ? `<span>${icon('clock', 13)} الساعات المكتبية: ${esc(f.office_hours)}</span>` : ''}
            </div>
          </div>`).join('') || App.empty('لا يوجد تدريسيون', '', 'grad')}</div>`;
      $$('#dseg [data-d]').forEach((b) => (b.onclick = () => { dep = b.dataset.d; draw(); }));
    };
    draw();
  });

  // ============================ حسابي ============================
  route('/profile', async (view) => {
    const u = (await get('/auth/me')).user;
    setTitle(u.role === 'faculty' ? 'ملفي الشخصي' : 'حسابي', 'بياناتك وكلمة المرور');
    const isStaff = u.role !== 'student';
    view.innerHTML = `
      ${u.must_change_password ? `<div class="banner warn">${icon('alert')}<span>يجب تغيير كلمة المرور المؤقتة قبل استخدام النظام.</span></div>` : ''}
      <div class="grid cols-main">
        <div class="stack">
          <div class="card">
            <div class="card-head"><h3>البيانات الأساسية</h3><span class="muted xs" style="margin-right:auto">تُعدَّل من قبل إدارة القسم</span></div>
            <div class="card-body">
              <div class="row" style="margin-bottom:16px;flex-wrap:nowrap"><div class="avatar lg">${esc(App.initials(u.full_name))}</div>
                <div><div class="small" style="color:var(--gold-ink);font-weight:600">${esc(u.academic_title || App.ROLE[u.role])}</div><h3 style="font-size:18px">${esc(u.full_name)}</h3><div class="muted small ltr" style="text-align:right">@${esc(u.username)}</div></div></div>
              <dl class="kv">
                <dt>الدور</dt><dd>${esc(App.ROLE[u.role])}</dd>
                ${u.department_name ? `<dt>القسم</dt><dd>${esc(u.department_name)}</dd>` : ''}
                ${u.stage ? `<dt>المرحلة</dt><dd>${esc(App.stageName(u.stage))}</dd><dt>الدراسة</dt><dd>${esc(App.STUDY[u.study_type] || '')}</dd>` : ''}
                ${u.batch ? `<dt>الدفعة</dt><dd class="num" style="text-align:right">${esc(u.batch)}</dd>` : ''}
                <dt>آخر دخول</dt><dd class="num" style="text-align:right">${esc(u.last_login || '-')}</dd>
              </dl>
            </div>
          </div>
          <form class="card" id="pf">
            <div class="card-head"><h3>معلومات التواصل${isStaff ? ' والملف التعريفي' : ''}</h3></div>
            <div class="card-body">
              <div class="grid-2">
                <label class="field"><span>البريد الإلكتروني</span><input class="input ltr" name="email" value="${esc(u.email || '')}"></label>
                <label class="field"><span>رقم الهاتف</span><input class="input ltr" name="phone" value="${esc(u.phone || '')}"></label>
              </div>
              ${isStaff ? `<label class="field"><span>نبذة تعريفية (تظهر للطلبة)</span><textarea class="input" name="bio">${esc(u.bio || '')}</textarea></label>
                <label class="field"><span>الساعات المكتبية</span><input class="input" name="office_hours" value="${esc(u.office_hours || '')}"></label>` : ''}
              <button class="btn btn-primary" type="submit">${icon('check', 16)} حفظ</button>
            </div>
          </form>
        </div>
        <form class="card" id="pw" style="align-self:start">
          <div class="card-head"><h3>${icon('key', 17)} تغيير كلمة المرور</h3></div>
          <div class="card-body">
            ${state.impersonating ? '' : '<label class="field"><span>كلمة المرور الحالية</span><input class="input" type="password" name="current" autocomplete="current-password" required></label>'}
            <label class="field"><span>كلمة المرور الجديدة</span><input class="input" type="password" name="next" minlength="6" autocomplete="new-password" required></label>
            <label class="field"><span>تأكيد كلمة المرور</span><input class="input" type="password" name="confirm" minlength="6" autocomplete="new-password" required></label>
            <button class="btn btn-gold btn-block" type="submit">تحديث كلمة المرور</button>
            <p class="xs muted" style="margin:10px 0 0">6 أحرف على الأقل. سيتم تسجيل خروجك من الأجهزة الأخرى.</p>
          </div>
        </form>
      </div>`;
    $('#pf').onsubmit = async (e) => { e.preventDefault(); try { await put('/profile', formData(e.target)); toast('تم حفظ البيانات'); } catch (err) { fail(err); } };
    $('#pw').onsubmit = async (e) => {
      e.preventDefault();
      const d = formData(e.target);
      if (d.next !== d.confirm) return fail(new Error('كلمتا المرور غير متطابقتين'));
      try {
        await post('/auth/change-password', d);
        toast('تم تغيير كلمة المرور بنجاح');
        state.defaultPassword = false; state.user.must_change_password = 0;
        e.target.reset();
        App.render();
      } catch (err) { fail(err); }
    };
  });
})();
