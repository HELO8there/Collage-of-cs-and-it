/* =====================================================================
   واجهة التدريسي (والإدارة): المواد، الملازم، الحضور اليدوي، درجات بولونيا
   ===================================================================== */
(function () {
  const { icon, esc, $, $$, get, post, put, del, toast, fail, modal, confirmBox, formData, opt, route, setTitle, state } = App;

  // ---------------- الرئيسية للتدريسي ----------------
  App.views.facultyHome = async (view) => {
    const u = state.user;
    setTitle('الرئيسية', `${u.academic_title || ''} · قسم ${u.department_name || ''}`);
    const d = await get('/dashboard');
    const students = d.courses.reduce((a, c) => a + c.students, 0);
    view.innerHTML = `
      <div class="hero-card">
        <div><div class="small" style="color:var(--gold)">${esc(u.academic_title || 'التدريسي')}</div><h2>${esc(u.full_name)}</h2>
          <p>لديك ${d.courses.length} مادة مسندة · ${students} طالب · العام الدراسي <span class="num">${esc(state.info.academic_year)}</span></p></div>
        <div class="row"><a class="btn btn-gold" href="#/teaching">${icon('clipboard', 16)} تسجيل الحضور والدرجات</a></div>
      </div>
      <div class="grid cols-main">
        <div class="card"><div class="card-head"><h3>موادي التدريسية</h3></div>
          <div class="card-body"><div class="grid cols-2">${d.courses.map((c) => `
            <a class="course-card card" href="#/teaching/${c.id}">
              <div class="row between" style="flex-wrap:nowrap;align-items:flex-start"><div><h4>${esc(c.name)}</h4><div class="xs muted">${esc(c.department_name)} · ${esc(App.stageName(c.stage))}</div></div>${c.grades_locked ? `<span class="chip red">${icon('lock', 12)} مقفلة</span>` : ''}</div>
              <div class="row" style="gap:6px;margin-top:12px"><span class="chip">${icon('users', 12)} ${c.students} طالب</span><span class="chip teal">${icon('calendar', 12)} ${c.lectures} محاضرة</span><span class="chip gold">${icon('file', 12)} ${c.materials} ملف</span></div>
            </a>`).join('') || App.empty('لا توجد مواد مسندة', 'تُسند المواد من قبل إدارة القسم', 'book')}</div></div></div>
        <div class="card" style="align-self:start"><div class="card-head"><h3>آخر التبليغات</h3><a class="btn btn-ghost btn-sm" href="#/announcements" style="margin-right:auto">الكل</a></div>
          <div>${App.views.annList(d.announcements, { short: true, showUnread: true })}</div></div>
      </div>`;
  };

  // ---------------- قائمة المواد ----------------
  route('/teaching', async (view) => {
    const admin = state.user.role === 'admin';
    setTitle(admin ? 'الدرجات والحضور والملازم' : 'موادي التدريسية', admin ? 'الإدارة: وصول كامل لجميع المواد' : 'اختر مادة لإدارة الملازم والحضور والدرجات');
    const list = await get('/teaching/courses');
    let q = '', dep = '';
    const draw = () => {
      const shown = list.filter((c) => (!q || c.name.includes(q) || (c.faculty_name || '').includes(q)) && (!dep || String(c.department_id) === dep));
      $('#tlist').innerHTML = `<table class="t"><thead><tr><th>المادة</th>${admin ? '<th>القسم</th>' : ''}<th>المرحلة</th><th>الدراسة</th>${admin ? '<th>التدريسي</th>' : ''}<th>الطلبة</th><th>ECTS</th><th>الدرجات</th><th></th></tr></thead><tbody>
        ${shown.map((c) => `<tr><td><b>${esc(c.name)}</b>${c.code ? `<div class="xs muted ltr" style="text-align:right">${esc(c.code)}</div>` : ''}</td>${admin ? `<td>${esc(c.department_name || '')}</td>` : ''}
          <td>${esc(App.stageName(c.stage))}</td><td>${esc(App.STUDY[c.study_type] || '')}</td>${admin ? `<td>${esc(c.faculty_name || '-')}</td>` : ''}<td class="num">${c.students}</td><td class="num">${c.ects}</td>
          <td>${c.grades_locked ? `<span class="chip red">${icon('lock', 12)} مقفلة</span>` : '<span class="chip teal">مفتوحة</span>'}</td>
          <td><a class="btn btn-primary btn-sm" href="#/teaching/${c.id}">فتح ${icon('back', 14)}</a></td></tr>`).join('') || `<tr><td colspan="9">${App.empty('لا توجد مواد', '', 'book')}</td></tr>`}</tbody></table>`;
    };
    view.innerHTML = `<div class="card"><div class="card-head"><div class="filters">
        <div class="input-icon">${icon('search')}<input class="input" id="tq" placeholder="بحث باسم المادة${admin ? ' أو التدريسي' : ''}"></div>
        ${admin ? `<select class="input" id="tdep">${App.deptOptions('')}</select>` : ''}</div></div>
      <div class="table-wrap" id="tlist"></div></div>`;
    $('#tq').oninput = (e) => { q = e.target.value.trim(); draw(); };
    const td = $('#tdep'); if (td) td.onchange = (e) => { dep = e.target.value; draw(); };
    draw();
  });

  // ---------------- مساحة عمل المادة ----------------
  route('/teaching/:id', async (view, { id }) => {
    let W = await get(`/courses/${id}/workspace`);
    let tab = state.teachTab || 'materials';
    const admin = state.user.role === 'admin';
    const locked = () => W.course.grades_locked && !admin;
    const reload = async () => { W = await get(`/courses/${id}/workspace`); head(); draw(); };

    const head = () => {
      const c = W.course;
      setTitle(c.name, `${c.department_name || ''} · ${App.stageName(c.stage)} · ${App.STUDY[c.study_type] || ''}${admin ? ` · ${c.faculty_name || 'بدون تدريسي'}` : ''}`);
      $('#whead').innerHTML = `
        <div class="grid cols-4">
          <div class="stat"><div class="ic">${icon('users')}</div><div><div class="v num">${W.students.length}</div><div class="l">طالب</div></div></div>
          <div class="stat"><div class="ic gold">${icon('calendar')}</div><div><div class="v num">${W.lectures.reduce((a, l) => a + l.hours, 0)}<small>/${c.total_hours}</small></div><div class="l">ساعة منجزة (${W.lectures.length} محاضرة)</div></div></div>
          <div class="stat"><div class="ic">${icon('layers')}</div><div><div class="v num">${c.formative_weight}/${c.exam_weight}</div><div class="l">تقييم مستمر / امتحان · ${c.ects} ECTS</div></div></div>
          <div class="stat"><div class="ic ${c.grades_locked ? 'red' : ''}">${icon(c.grades_locked ? 'lock' : 'unlock')}</div><div><div class="v" style="font-size:16px">${c.grades_locked ? 'الدرجات مقفلة' : 'الدرجات مفتوحة'}</div><div class="l">${c.grades_published ? 'منشورة للطلبة' : 'غير منشورة للطلبة'}</div></div></div>
        </div>`;
    };

    // ======== الملازم ========
    const materialsPanel = () => `
      <div class="card-head"><h3>الملازم والمصادر</h3><button class="btn btn-gold" id="m-new" style="margin-right:auto">${icon('upload', 16)} رفع ملف</button></div>
      ${W.materials.length ? `<div class="table-wrap"><table class="t"><thead><tr><th>العنوان</th><th>النوع</th><th>الملف</th><th>التحميلات</th><th>الظهور</th><th></th></tr></thead><tbody>
      ${W.materials.map((m) => `<tr><td><b>${esc(m.title)}</b><div class="xs muted num">${esc(App.fmtDate(m.created_at))} · ${esc(m.uploader || '')}</div></td>
        <td><span class="chip">${esc(App.MAT_CAT[m.category] || m.category)}</span></td>
        <td class="small">${m.original_name ? `<a href="${esc(App.fileUrl(`/materials/${m.id}/download`))}">${esc(m.original_name)}</a> <span class="muted num">${App.fmtSize(m.size)}</span>` : m.link_url ? `<a href="${esc(m.link_url)}" target="_blank" rel="noopener">${icon('link', 13)} رابط</a>` : ''}</td>
        <td class="num">${m.downloads || 0}</td>
        <td><label class="switch"><input type="checkbox" data-vis="${m.id}" ${m.visible ? 'checked' : ''}><span></span></label></td>
        <td class="row" style="flex-wrap:nowrap"><button class="btn btn-ghost btn-sm" data-medit="${m.id}" aria-label="تعديل">${icon('edit', 14)}</button><button class="btn btn-danger btn-sm" data-mdel="${m.id}" aria-label="حذف">${icon('trash', 14)}</button></td></tr>`).join('')}
      </tbody></table></div>` : App.empty('لا توجد ملفات بعد', 'ارفع ملازم المحاضرات ليتمكن الطلبة من تحميلها فوراً', 'upload')}`;

    function materialForm(m = {}) {
      const body = `
        <label class="field"><span>عنوان الملف</span><input class="input" name="title" value="${esc(m.title || '')}" required placeholder="مثال: المحاضرة الثالثة - المصفوفات"></label>
        <div class="grid-2"><label class="field"><span>النوع</span><select class="input" name="category">${Object.entries(App.MAT_CAT).map(([k, v]) => opt(k, v, m.category || 'lecture')).join('')}</select></label>
        <label class="field"><span>رابط خارجي (اختياري)</span><input class="input ltr" name="link_url" value="${esc(m.link_url || '')}" placeholder="https://"></label></div>
        <label class="field"><span>وصف مختصر</span><textarea class="input" name="description" rows="2">${esc(m.description || '')}</textarea></label>
        ${m.id ? '' : `<label class="drop" id="drop"><input type="file" name="file" hidden>${icon('upload', 28)}<b>اسحب الملف هنا أو اضغط للاختيار</b><span class="xs muted" id="fname">PDF, Word, PowerPoint, ZIP, صور، فيديو...</span></label>`}
        ${m.id ? '' : '<div class="progress" id="upbar" hidden><span style="width:0"></span></div>'}`;
      return modal({
        title: m.id ? 'تعديل الملف' : 'رفع ملف جديد', body,
        onOpen: (b) => {
          const drop = $('#drop', b); if (!drop) return;
          const inp = $('input[type=file]', drop);
          const show = () => { $('#fname', b).textContent = inp.files[0] ? `${inp.files[0].name} (${App.fmtSize(inp.files[0].size)})` : ''; if (inp.files[0] && !b.querySelector('[name=title]').value) b.querySelector('[name=title]').value = inp.files[0].name.replace(/\.[^.]+$/, ''); };
          inp.onchange = show;
          drop.ondragover = (e) => { e.preventDefault(); drop.classList.add('over'); };
          drop.ondragleave = () => drop.classList.remove('over');
          drop.ondrop = (e) => { e.preventDefault(); drop.classList.remove('over'); inp.files = e.dataTransfer.files; show(); };
        },
        actions: [{ label: `${icon('check', 15)} ${m.id ? 'حفظ' : 'رفع'}`, cls: 'btn-primary', onClick: async (b) => {
          const d = formData(b);
          if (m.id) { await put(`/materials/${m.id}`, d); toast('تم الحفظ'); return true; }
          const fd = new FormData();
          Object.entries(d).forEach(([k, v]) => fd.append(k, v));
          const f = $('input[type=file]', b).files[0];
          if (f) fd.append('file', f);
          await uploadWithProgress(`/courses/${id}/materials`, fd, $('#upbar', b));
          toast('تم رفع الملف وإشعار الطلبة');
          return true;
        } }, { label: 'إلغاء' }],
      });
    }

    // ======== الحضور ========
    const attendancePanel = () => `
      <div class="card-head"><h3>سجل المحاضرات والحضور</h3>
        <div class="actions"><a class="btn btn-ghost btn-sm" href="${esc(App.fileUrl(`/courses/${id}/export/attendance`))}">${icon('download', 14)} تصدير Excel</a>
        <button class="btn btn-gold" id="l-new">${icon('plus', 16)} تسجيل محاضرة جديدة</button></div></div>
      ${W.lectures.length ? `<div class="table-wrap"><table class="t"><thead><tr><th>التاريخ</th><th>الموضوع</th><th>النوع</th><th>الساعات</th><th>حاضر</th><th>غائب</th><th>مجاز</th><th></th></tr></thead><tbody>
      ${W.lectures.map((l) => `<tr><td class="num">${esc(l.lecture_date)}</td><td>${esc(l.topic || '-')}</td><td>${l.kind === 'lab' ? 'عملي' : 'نظري'}</td><td class="num">${l.hours}</td>
        <td><span class="chip teal num">${l.present}</span></td><td><span class="chip red num">${l.absent}</span></td><td><span class="chip amber num">${l.excused}</span></td>
        <td class="row" style="flex-wrap:nowrap"><button class="btn btn-ghost btn-sm" data-ledit="${l.id}">${icon('edit', 14)} تعديل</button><button class="btn btn-danger btn-sm" data-ldel="${l.id}" aria-label="حذف">${icon('trash', 14)}</button></td></tr>`).join('')}
      </tbody></table></div>` : App.empty('لم تُسجل أي محاضرة', 'سجّل المحاضرة الأولى وحدد الطلبة الغائبين يدوياً', 'calendar')}
      <div class="section-title" style="padding:0 18px">ملخص الغياب لكل طالب</div>
      <div class="table-wrap"><table class="t"><thead><tr><th>الطالب</th><th>ساعات الغياب</th><th>إجازات</th><th style="width:35%">النسبة</th><th>الحالة</th></tr></thead><tbody>
      ${W.students.map((s) => `<tr><td>${esc(s.full_name)}${s.kind === 'carry' ? ' <span class="chip amber">محمّل</span>' : ''}</td><td class="num">${s.attendance.absent_hours}</td><td class="num">${s.attendance.excused_hours}</td>
        <td><div class="row" style="flex-wrap:nowrap"><div style="flex:1">${App.progress(Math.min(100, s.attendance.absence_pct / Math.max(s.attendance.ban_pct, 1) * 100), s.attendance.status === 'banned' ? 'danger' : s.attendance.status === 'warning' ? 'warn' : '')}</div><span class="num xs">${s.attendance.absence_pct}%</span></div></td>
        <td>${App.attChip(s.attendance)}</td></tr>`).join('')}</tbody></table></div>`;

    async function lectureForm(lectureId) {
      let lec = { lecture_date: new Date().toISOString().slice(0, 10), hours: 2, kind: 'theory', topic: '' };
      let students = W.students.map((s) => ({ id: s.id, full_name: s.full_name, username: s.username, status: 'present', note: '' }));
      if (lectureId) {
        const r = await get(`/lectures/${lectureId}`);
        lec = r.lecture;
        students = r.students.map((s) => ({ ...s, status: s.status || 'present' }));
      }
      const row = (s) => `<div class="att-row" data-sid="${s.id}"><div style="min-width:0;flex:1"><b>${esc(s.full_name)}</b><div class="xs muted ltr" style="text-align:right">${esc(s.username)}</div></div>
        <div class="att-toggle">${[['present', 'حاضر'], ['absent', 'غائب'], ['excused', 'مجاز']].map(([k, v]) => `<button type="button" class="${k} ${s.status === k ? 'on' : ''}" data-st="${k}">${v}</button>`).join('')}</div></div>`;
      const body = `
        <div class="grid-3"><label class="field"><span>التاريخ</span><input class="input" type="date" name="lecture_date" value="${esc(lec.lecture_date)}" required></label>
          <label class="field"><span>عدد الساعات</span><input class="input" type="number" min="1" max="8" name="hours" value="${lec.hours}"></label>
          <label class="field"><span>النوع</span><select class="input" name="kind">${opt('theory', 'نظري', lec.kind)}${opt('lab', 'عملي', lec.kind)}</select></label></div>
        <label class="field"><span>موضوع المحاضرة</span><input class="input" name="topic" value="${esc(lec.topic || '')}"></label>
        <div class="row between" style="margin:6px 0 10px"><b>الطلبة (<span class="num">${students.length}</span>)</b>
          <div class="row"><span class="xs muted" id="att-sum"></span><button type="button" class="btn btn-ghost btn-sm" data-all="present">الكل حاضر</button><button type="button" class="btn btn-ghost btn-sm" data-all="absent">الكل غائب</button></div></div>
        <div class="input-icon" style="margin-bottom:8px">${icon('search')}<input class="input" id="att-q" placeholder="بحث عن طالب"></div>
        <div class="att-list">${students.map(row).join('') || App.empty('لا يوجد طلبة في هذه المادة', '', 'users')}</div>`;
      return modal({
        title: lectureId ? 'تعديل الحضور' : 'تسجيل حضور محاضرة', body, wide: true,
        onOpen: (b) => {
          const sum = () => { const c = { present: 0, absent: 0, excused: 0 }; students.forEach((s) => c[s.status]++); $('#att-sum', b).textContent = `حاضر ${c.present} · غائب ${c.absent} · مجاز ${c.excused}`; };
          b.addEventListener('click', (e) => {
            const t = e.target.closest('[data-st]');
            if (t) { const r = t.closest('[data-sid]'); const s = students.find((x) => x.id === Number(r.dataset.sid)); s.status = t.dataset.st; $$('[data-st]', r).forEach((x) => x.classList.toggle('on', x === t)); sum(); }
            const all = e.target.closest('[data-all]');
            if (all) { students.forEach((s) => (s.status = all.dataset.all)); $$('[data-sid]', b).forEach((r) => $$('[data-st]', r).forEach((x) => x.classList.toggle('on', x.dataset.st === all.dataset.all))); sum(); }
          });
          $('#att-q', b).oninput = (e) => { const q = e.target.value.trim(); $$('[data-sid]', b).forEach((r) => (r.style.display = !q || r.textContent.includes(q) ? '' : 'none')); };
          sum();
        },
        actions: [{ label: `${icon('check', 15)} حفظ الحضور`, cls: 'btn-primary', onClick: async (b) => {
          const d = { ...formData(b), attendance: students.map((s) => ({ student_id: s.id, status: s.status })) };
          if (lectureId) await put(`/lectures/${lectureId}`, d); else await post(`/courses/${id}/lectures`, d);
          toast('تم حفظ الحضور');
          return true;
        } }, { label: 'إلغاء' }],
      });
    }

    // ======== الدرجات ========
    const dirty = new Map();
    const kindLbl = { formative: 'مستمر', final: 'نهائي', resit: 'إعادة' };
    const gradesPanel = () => {
      const items = W.items;
      return `
      <div class="card-head"><h3>رصد الدرجات (بولونيا)</h3>
        <div class="actions">
          <a class="btn btn-ghost btn-sm" href="${esc(App.fileUrl(`/courses/${id}/export/grades`))}">${icon('download', 14)} تصدير Excel</a>
          ${locked() ? '' : `<button class="btn btn-ghost btn-sm" id="i-new">${icon('plus', 14)} مكوّن تقييم</button>`}
          ${locked() ? '' : `<button class="btn btn-primary" id="g-save" disabled>${icon('check', 15)} حفظ الدرجات</button>`}
        </div></div>
      ${locked() ? `<div class="banner danger" style="margin:0 18px 12px">${icon('lock')}<span>الدرجات مقفلة من قبل الإدارة. لا يمكن التعديل إلا بعد فتحها.</span></div>` : ''}
      <div class="xs muted" style="padding:0 18px 10px">التقييم المستمر من ${W.course.formative_weight} والامتحان النهائي من ${W.course.exam_weight}. التقريب: 54.5 تصبح 55. امتحان الإعادة يُحتسب فقط للراسبين ويؤخذ الأعلى.</div>
      <div class="table-wrap grade-grid"><table class="t"><thead><tr><th class="sticky">الطالب</th>
        ${items.map((i) => `<th><div class="row" style="flex-wrap:nowrap;gap:4px"><span>${esc(i.title)}</span>${locked() ? '' : `<button class="btn-icon btn btn-sm" data-iedit="${i.id}" aria-label="تعديل المكون">${icon('edit', 12)}</button>`}</div><div class="xs"><span class="chip ${i.kind === 'formative' ? 'teal' : 'gold'}" style="padding:0 6px">${kindLbl[i.kind]}</span> <span class="num">/${i.max_score}</span></div></th>`).join('')}
        <th>المستمر</th><th>الامتحان</th><th>المجموع</th><th>التقدير</th></tr></thead><tbody>
        ${W.students.map((s) => `<tr data-row="${s.id}"><td class="sticky"><b>${esc(s.full_name)}</b><div class="xs muted ltr" style="text-align:right">${esc(s.username)}</div></td>
          ${items.map((i) => `<td><input class="input score num" type="number" step="0.5" min="0" max="${i.max_score}" data-s="${s.id}" data-i="${i.id}" value="${s.scores[i.id] ?? ''}" ${locked() ? 'disabled' : ''} aria-label="${esc(i.title)} - ${esc(s.full_name)}"></td>`).join('')}
          <td class="num">${s.grade.formative}</td><td class="num">${s.grade.exam}${s.grade.used_resit ? ' <span class="chip amber" style="padding:0 5px">إعادة</span>' : ''}</td>
          <td class="num"><b>${s.grade.total ?? '-'}</b></td><td>${App.letterChip(s.grade) || '<span class="xs muted">-</span>'}</td></tr>`).join('') || `<tr><td colspan="${items.length + 5}">${App.empty('لا يوجد طلبة', '', 'users')}</td></tr>`}
      </tbody></table></div>
      <div class="xs muted" style="padding:12px 18px">سلم التقديرات: ${W.scale.map((g) => `<span class="letter ${esc(g.letter)}" style="margin-inline:2px">${esc(g.letter)}</span> ${g.min}+`).join(' · ')}</div>`;
    };
    function itemForm(it = {}) {
      return modal({
        title: it.id ? 'تعديل مكوّن التقييم' : 'إضافة مكوّن تقييم',
        body: `<label class="field"><span>الاسم</span><input class="input" name="title" value="${esc(it.title || '')}" placeholder="مثال: كويز 2، تقرير، مشروع" required></label>
          <div class="grid-2"><label class="field"><span>النوع</span><select class="input" name="kind">${opt('formative', 'تقييم مستمر', it.kind)}${opt('final', 'امتحان نهائي', it.kind)}${opt('resit', 'امتحان إعادة', it.kind)}</select></label>
          <label class="field"><span>الدرجة القصوى</span><input class="input" type="number" min="1" step="0.5" name="max_score" value="${it.max_score || 10}"></label></div>
          <p class="xs muted">تُحوّل درجات المكوّنات نسبياً إلى وزن التقييم المستمر/الامتحان المحدد للمادة.</p>`,
        actions: [
          { label: 'حفظ', cls: 'btn-primary', onClick: async (b) => { const d = formData(b); if (it.id) await put(`/items/${it.id}`, d); else await post(`/courses/${id}/items`, d); return true; } },
          ...(it.id ? [{ label: 'حذف المكوّن', cls: 'btn-danger', onClick: async () => { if (!(await confirmBox('حذف المكوّن', 'ستُحذف جميع الدرجات المرصودة لهذا المكوّن. متابعة؟', 'حذف'))) return false; await del(`/items/${it.id}`); return true; } }] : []),
          { label: 'إلغاء' },
        ],
      });
    }

    // ======== الطلبة ========
    const studentsPanel = () => `
      <div class="card-head"><h3>قائمة الطلبة</h3><span class="muted small" style="margin-right:auto">${W.students.length} طالب</span></div>
      <div class="table-wrap"><table class="t"><thead><tr><th>#</th><th>الاسم</th><th>اسم المستخدم</th><th>الدراسة</th><th>الحالة</th><th>الغياب</th><th>الدرجة</th></tr></thead><tbody>
      ${W.students.map((s, i) => `<tr><td class="num">${i + 1}</td><td>${esc(s.full_name)}</td><td class="ltr num" style="text-align:right">${esc(s.username)}</td><td>${esc(App.STUDY[s.study_type] || '')}</td>
        <td>${s.kind === 'carry' ? '<span class="chip amber">محمّل</span>' : '<span class="chip">أصلي</span>'}</td><td>${App.attChip(s.attendance)}</td><td class="num">${s.grade.total ?? '-'} ${App.letterChip(s.grade)}</td></tr>`).join('')}</tbody></table></div>`;

    const panels = { materials: materialsPanel, attendance: attendancePanel, grades: gradesPanel, students: studentsPanel };
    function draw() {
      state.teachTab = tab;
      $$('#wtabs .tab').forEach((t) => t.classList.toggle('on', t.dataset.t === tab));
      const p = $('#wpanel');
      p.innerHTML = panels[tab]();
      dirty.clear();
      // ملازم
      $('#m-new', p)?.addEventListener('click', () => materialForm().then((ok) => ok && reload()));
      $$('[data-medit]', p).forEach((b) => (b.onclick = () => materialForm(W.materials.find((m) => m.id === Number(b.dataset.medit))).then((ok) => ok && reload())));
      $$('[data-mdel]', p).forEach((b) => (b.onclick = async () => { if (await confirmBox('حذف الملف', 'سيُحذف الملف نهائياً من السيرفر. متابعة؟', 'حذف')) { try { await del(`/materials/${b.dataset.mdel}`); toast('تم الحذف'); reload(); } catch (e) { fail(e); } } }));
      $$('[data-vis]', p).forEach((b) => (b.onchange = async () => { try { await put(`/materials/${b.dataset.vis}`, { visible: b.checked }); toast(b.checked ? 'الملف ظاهر للطلبة' : 'تم إخفاء الملف'); } catch (e) { fail(e); } }));
      // حضور
      $('#l-new', p)?.addEventListener('click', () => lectureForm().then((ok) => ok && reload()));
      $$('[data-ledit]', p).forEach((b) => (b.onclick = () => lectureForm(Number(b.dataset.ledit)).then((ok) => ok && reload())));
      $$('[data-ldel]', p).forEach((b) => (b.onclick = async () => { if (await confirmBox('حذف المحاضرة', 'سيُحذف سجل الحضور لهذه المحاضرة. متابعة؟', 'حذف')) { await del(`/lectures/${b.dataset.ldel}`); reload(); } }));
      // درجات
      $('#i-new', p)?.addEventListener('click', () => itemForm().then((ok) => ok && reload()));
      $$('[data-iedit]', p).forEach((b) => (b.onclick = () => itemForm(W.items.find((i) => i.id === Number(b.dataset.iedit))).then((ok) => ok && reload())));
      const save = $('#g-save', p);
      $$('input.score', p).forEach((inp) => {
        inp.addEventListener('input', () => {
          const max = Number(inp.max), v = inp.value;
          inp.classList.toggle('err', v !== '' && (Number(v) < 0 || Number(v) > max));
          inp.classList.add('dirty');
          dirty.set(`${inp.dataset.s}:${inp.dataset.i}`, { student_id: Number(inp.dataset.s), item_id: Number(inp.dataset.i), score: v === '' ? null : Number(v) });
          if (save) { save.disabled = false; save.innerHTML = `${icon('check', 15)} حفظ (${dirty.size})`; }
        });
        inp.addEventListener('keydown', (e) => {
          if (e.key !== 'Enter') return;
          e.preventDefault();
          const all = $$('input.score', p); const cols = W.items.length;
          const idx = all.indexOf(inp); const next = all[idx + cols] || all[idx + 1]; if (next) next.focus();
        });
      });
      if (save) save.onclick = async () => {
        if ($('input.score.err', p)) return fail(new Error('توجد درجات خارج الحد المسموح (باللون الأحمر)'));
        save.disabled = true;
        try { const r = await put(`/courses/${id}/scores`, { scores: [...dirty.values()] }); toast(`تم حفظ ${r.changed} درجة`); reload(); } catch (e) { fail(e); save.disabled = false; }
      };
    }

    view.innerHTML = `
      <a class="btn btn-ghost btn-sm" href="#/teaching" style="margin-bottom:12px">${icon('back', 14)} المواد</a>
      <div id="whead" style="margin-bottom:20px"></div>
      <div class="card">
        <div class="tabs" id="wtabs">
          <button class="tab" data-t="materials">${icon('file', 15)} الملازم</button>
          <button class="tab" data-t="attendance">${icon('clipboard', 15)} الحضور والغياب</button>
          <button class="tab" data-t="grades">${icon('star', 15)} الدرجات</button>
          <button class="tab" data-t="students">${icon('users', 15)} الطلبة</button>
        </div>
        <div id="wpanel"></div>
      </div>`;
    $$('#wtabs .tab').forEach((t) => (t.onclick = async () => {
      if (dirty.size && !(await confirmBox('تغييرات غير محفوظة', 'لديك درجات لم تُحفظ. هل تريد تجاهلها؟', 'تجاهل'))) return;
      tab = t.dataset.t; draw();
    }));
    head(); draw();
    const off = App.on('sync', (s) => { if (state.route === `/teaching/${id}` && s.type === 'courses' && !dirty.size) reload(); });
    window.addEventListener('hashchange', off, { once: true });
  });

  // رفع مع شريط تقدم
  function uploadWithProgress(path, fd, bar) {
    return new Promise((resolve, reject) => {
      const x = new XMLHttpRequest();
      x.open('POST', `${App.API}/api${path}`);
      if (state.token) x.setRequestHeader('Authorization', `Bearer ${state.token}`);
      x.withCredentials = !App.API;
      if (bar) { bar.hidden = false; x.upload.onprogress = (e) => { if (e.lengthComputable) $('span', bar).style.width = `${(e.loaded / e.total) * 100}%`; }; }
      x.onload = () => { let d = {}; try { d = JSON.parse(x.responseText); } catch (_) {} if (x.status >= 200 && x.status < 300) resolve(d); else reject(new Error(d.error || `خطأ ${x.status}`)); };
      x.onerror = () => reject(new Error('فشل الاتصال بالسيرفر'));
      x.send(fd);
    });
  }
  App.uploadWithProgress = uploadWithProgress;
})();
