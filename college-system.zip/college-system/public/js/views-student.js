/* =====================================================================
   واجهة الطالب: الرئيسية، موادي، تفاصيل المادة (ملازم، درجات، غياب)
   ===================================================================== */
(function () {
  const { icon, esc, $, $$, get, route, setTitle, state } = App;

  const attBar = (a) => {
    const cls = a.status === 'banned' ? 'danger' : a.status === 'warning' ? 'warn' : '';
    const pct = Math.min(100, (a.absence_pct / Math.max(a.ban_pct, 1)) * 100);
    return `<div class="row between xs muted" style="margin-bottom:6px"><span>الغياب <b class="num">${a.absent_hours}</b> من <span class="num">${a.total_hours}</span> ساعة</span><span class="num">${a.absence_pct}% / ${a.ban_pct}%</span></div>${App.progress(pct, cls)}`;
  };
  const gradeBar = (g) => g && g.total != null
    ? `<div class="row between xs muted" style="margin:12px 0 6px"><span>${g.final ? 'الدرجة النهائية' : 'التقييم المستمر حتى الآن'}</span><span class="num"><b>${g.final ? g.total : g.formative}</b> / ${g.final ? 100 : g.formative_max}</span></div>${App.progress(g.final ? g.total : (g.formative / Math.max(g.formative_max, 1)) * 100, 'gold')}`
    : '<div class="xs muted" style="margin-top:12px">لم تُنشر الدرجات بعد</div>';

  const courseCard = (c) => `
    <a class="course-card card" href="#/my-courses/${c.id}">
      <div class="row between" style="flex-wrap:nowrap;align-items:flex-start">
        <div style="min-width:0"><h4>${esc(c.name)}</h4><div class="xs muted">${esc(c.faculty_name || 'لم يُحدد التدريسي')}</div></div>
        ${c.grade && c.grade.letter ? App.letterChip(c.grade) : App.attChip(c.attendance)}
      </div>
      <div class="row" style="gap:6px;margin:10px 0 12px"><span class="chip">${c.ects} ECTS</span>${c.materials_count != null ? `<span class="chip teal">${icon('file', 12)} ${c.materials_count} ملف</span>` : ''}${c.kind === 'carry' ? '<span class="chip amber">محمّلة</span>' : ''}</div>
      ${attBar(c.attendance)}
      ${gradeBar(c.grade)}
    </a>`;

  // ---------------- الرئيسية ----------------
  App.views.studentHome = async (view) => {
    const u = state.user;
    setTitle('الرئيسية', `${u.department_name || ''} · ${App.stageName(u.stage)} · ${App.STUDY[u.study_type] || ''}`);
    const d = await get('/dashboard');
    const warn = d.courses.filter((c) => c.attendance.status !== 'ok');
    const graded = d.courses.filter((c) => c.grade && c.grade.final);
    const avg = graded.length ? Math.round(graded.reduce((a, c) => a + c.grade.total, 0) / graded.length) : null;
    const totalAbs = d.courses.reduce((a, c) => a + c.attendance.absent_hours, 0);
    view.innerHTML = `
      <div class="hero-card">
        <div><div class="small" style="color:var(--gold)">أهلاً بك</div><h2>${esc(u.full_name)}</h2>
          <p>قسم ${esc(u.department_name || '')} · ${esc(App.stageName(u.stage))} · الدراسة ${esc(App.STUDY[u.study_type] || '')} · العام الدراسي <span class="num">${esc(state.info.academic_year)}</span></p></div>
        <div class="row"><a class="btn btn-gold" href="#/my-courses">${icon('book', 16)} موادي</a><a class="btn btn-ghost-light" href="#/bot">${icon('bot', 16)} اسأل المساعد</a></div>
      </div>
      ${warn.map((c) => `<div class="banner ${c.attendance.status === 'banned' ? 'danger' : 'warn'}">${icon('alert')}<span>${c.attendance.status === 'banned' ? 'تجاوزت نسبة الغياب المسموحة (حرمان)' : 'إنذار غياب'} في مادة <b>${esc(c.name)}</b>: <span class="num">${c.attendance.absence_pct}%</span></span></div>`).join('')}
      <div class="grid cols-4" style="margin-bottom:20px">
        <div class="stat"><div class="ic">${icon('book')}</div><div><div class="v num">${d.courses.length}</div><div class="l">مادة هذا العام</div></div></div>
        <div class="stat"><div class="ic gold">${icon('layers')}</div><div><div class="v num">${d.total_ects}</div><div class="l">وحدة ECTS</div></div></div>
        <div class="stat"><div class="ic ${totalAbs ? 'amber' : ''}">${icon('clock')}</div><div><div class="v num">${totalAbs}</div><div class="l">ساعة غياب</div></div></div>
        <div class="stat"><div class="ic">${icon('chart')}</div><div><div class="v num">${avg ?? '-'}</div><div class="l">المعدل (المواد المكتملة)</div></div></div>
      </div>
      <div class="grid cols-main">
        <div class="card"><div class="card-head"><h3>موادي ونسب الحضور</h3><a class="btn btn-ghost btn-sm" href="#/my-courses" style="margin-right:auto">عرض الكل</a></div>
          <div class="card-body"><div class="grid cols-2">${d.courses.map((c) => courseCard(c)).join('') || App.empty('لا توجد مواد', 'لم تُسجل أي مادة لمرحلتك بعد', 'book')}</div></div></div>
        <div class="card" style="align-self:start"><div class="card-head"><h3>آخر التبليغات</h3><a class="btn btn-ghost btn-sm" href="#/announcements" style="margin-right:auto">الكل</a></div>
          <div>${App.views.annList(d.announcements, { short: true, showUnread: true })}</div></div>
      </div>`;
  };

  // ---------------- موادي ----------------
  route('/my-courses', async (view) => {
    setTitle('موادي الدراسية', 'الملازم، الدرجات ونسب الغياب لكل مادة');
    const list = await get('/student/courses');
    const sems = [...new Set(list.map((c) => c.semester))].sort();
    view.innerHTML = sems.length ? sems.map((s) => `
      <div class="section-title">الفصل الدراسي ${s === 1 ? 'الأول' : s === 2 ? 'الثاني' : s}</div>
      <div class="grid auto-fill" style="margin-bottom:24px">${list.filter((c) => c.semester === s).map(courseCard).join('')}</div>`).join('')
      : `<div class="card">${App.empty('لا توجد مواد', 'لم تُسجل أي مادة لمرحلتك بعد. راجع إدارة القسم.', 'book')}</div>`;
  });

  // ---------------- تفاصيل المادة ----------------
  route('/my-courses/:id', async (view, { id }) => {
    const d = await get(`/student/courses/${id}`);
    const c = d.course, g = d.grade, a = d.attendance;
    setTitle(c.name, `${c.faculty_name || ''} · ${c.ects} ECTS · ${c.total_hours} ساعة`);
    let tab = 'materials';
    const kindLbl = { formative: 'تقييم مستمر', final: 'امتحان نهائي', resit: 'امتحان إعادة' };
    const stLbl = { present: '<span class="chip teal">حاضر</span>', absent: '<span class="chip red">غائب</span>', excused: '<span class="chip amber">مجاز</span>' };
    const ext = (n) => (String(n || '').split('.').pop() || '').slice(0, 4).toUpperCase();

    const panels = {
      materials: () => d.materials.length ? `<div class="list-plain">${d.materials.map((m) => `
        <div class="row" style="flex-wrap:nowrap;padding:14px 18px;border-bottom:1px solid var(--line)">
          <div class="file-ic">${m.link_url && !m.original_name ? icon('link', 18) : esc(ext(m.original_name)) || icon('file', 18)}</div>
          <div style="flex:1;min-width:0"><b>${esc(m.title)}</b><div class="xs muted">${esc(App.MAT_CAT[m.category] || '')} · <span class="num">${esc(App.fmtDate(m.created_at))}</span>${m.size ? ` · <span class="num">${App.fmtSize(m.size)}</span>` : ''}</div>
            ${m.description ? `<div class="small" style="color:var(--ink-2);margin-top:4px">${esc(m.description)}</div>` : ''}</div>
          ${m.original_name && /pdf|image/.test(m.mime || '') ? `<a class="btn btn-ghost btn-sm" target="_blank" rel="noopener" href="${esc(App.fileUrl(`/materials/${m.id}/download?inline=1`))}">${icon('eye', 14)} عرض</a>` : ''}
          <a class="btn btn-teal btn-sm" ${m.link_url && !m.original_name ? `href="${esc(m.link_url)}" target="_blank" rel="noopener"` : `href="${esc(App.fileUrl(`/materials/${m.id}/download`))}"`}>${icon(m.link_url && !m.original_name ? 'link' : 'download', 14)} ${m.link_url && !m.original_name ? 'فتح' : 'تحميل'}</a>
        </div>`).join('')}</div>` : App.empty('لا توجد ملازم بعد', 'ستظهر هنا الملفات فور رفعها من قبل التدريسي', 'file'),
      grades: () => !g ? App.empty('الدرجات غير منشورة', 'ستظهر درجاتك عند نشرها من قبل الإدارة', 'lock') : `
        <div class="card-body">
          <div class="grid cols-3" style="margin-bottom:18px">
            <div class="stat"><div class="ic">${icon('clipboard')}</div><div><div class="v num">${g.formative}<small>/${g.formative_max}</small></div><div class="l">التقييم المستمر</div></div></div>
            <div class="stat"><div class="ic gold">${icon('file')}</div><div><div class="v num">${g.exam}<small>/${g.exam_max}</small></div><div class="l">الامتحان${g.used_resit ? ' (إعادة)' : ''}</div></div></div>
            <div class="stat"><div class="ic">${icon('star')}</div><div><div class="v num">${g.total ?? '-'}<small>/100</small></div><div class="l">${g.letter ? `${g.letter} - ${esc(g.letter_ar)}` : 'لم يكتمل'}</div></div></div>
          </div>
          ${g.letter === 'FX' ? `<div class="banner warn">${icon('alert')}<span>تقدير FX: يحق لك أداء امتحان الإعادة لتحسين النتيجة وفق تعليمات مسار بولونيا.</span></div>` : ''}
          <table class="t"><thead><tr><th>المكوّن</th><th>النوع</th><th>الدرجة</th><th style="width:40%">النسبة</th></tr></thead><tbody>
          ${g.breakdown.map((b) => `<tr><td>${esc(b.title)}</td><td><span class="chip ${b.kind === 'formative' ? 'teal' : 'gold'}">${kindLbl[b.kind]}</span></td>
            <td class="num">${b.score ?? '-'} / ${b.max}</td><td>${b.score != null ? App.progress((b.score / b.max) * 100, b.kind === 'formative' ? '' : 'gold') : '<span class="xs muted">لم تُرصد</span>'}</td></tr>`).join('')}
          </tbody></table>
        </div>`,
      attendance: () => `
        <div class="card-body">
          <div class="grid cols-4" style="margin-bottom:18px">
            <div class="stat"><div class="ic">${icon('calendar')}</div><div><div class="v num">${a.lectures}</div><div class="l">محاضرة مسجلة</div></div></div>
            <div class="stat"><div class="ic red">${icon('x')}</div><div><div class="v num">${a.absent_count}</div><div class="l">غياب (${a.absent_hours} ساعة)</div></div></div>
            <div class="stat"><div class="ic amber">${icon('file')}</div><div><div class="v num">${a.excused_count}</div><div class="l">إجازة</div></div></div>
            <div class="stat"><div class="ic">${icon('chart')}</div><div><div class="v num">${a.absence_pct}%</div><div class="l">${a.status === 'banned' ? 'محروم' : a.status === 'warning' ? 'إنذار' : 'ضمن الحد'}</div></div></div>
          </div>
          ${attBar(a)}
          <p class="xs muted">الإنذار عند ${a.warn_pct}% والحرمان عند ${a.ban_pct}% من مجموع ساعات المادة (${a.total_hours} ساعة). الغياب بإجازة رسمية لا يُحتسب.</p>
          <table class="t" style="margin-top:12px"><thead><tr><th>التاريخ</th><th>الموضوع</th><th>الساعات</th><th>الحالة</th></tr></thead><tbody>
          ${a.log.map((l) => `<tr><td class="num">${esc(l.lecture_date)}</td><td>${esc(l.topic || '-')}</td><td class="num">${l.hours}</td><td>${stLbl[l.status] || '<span class="chip">غير مسجل</span>'}</td></tr>`).join('') || '<tr><td colspan="4" class="muted">لا توجد محاضرات مسجلة</td></tr>'}
          </tbody></table>
        </div>`,
    };
    const draw = () => {
      $('#cpanel').innerHTML = panels[tab]();
      $$('#ctabs .tab').forEach((t) => t.classList.toggle('on', t.dataset.t === tab));
    };
    view.innerHTML = `
      <a class="btn btn-ghost btn-sm" href="#/my-courses" style="margin-bottom:12px">${icon('back', 14)} موادي</a>
      <div class="grid cols-3" style="margin-bottom:20px">
        <div class="card card-pad row" style="flex-wrap:nowrap">${App.ring(g && g.total != null ? g.total : 0, 100, 'var(--gold)')}<div><div class="xs muted">الدرجة</div><b class="num" style="font-size:20px">${g && g.total != null ? g.total : '-'}</b> ${g ? App.letterChip(g) : ''}</div></div>
        <div class="card card-pad">${attBar(a)}<div style="margin-top:8px">${App.attChip(a)}</div></div>
        <div class="card card-pad"><div class="xs muted">التدريسي</div><b>${esc(c.faculty_name || '-')}</b><div class="xs muted" style="margin-top:6px">${c.ects} ECTS · الفصل ${c.semester === 2 ? 'الثاني' : 'الأول'} · ${esc(App.STUDY[c.study_type] || '')}</div></div>
      </div>
      <div class="card">
        <div class="tabs" id="ctabs">
          <button class="tab" data-t="materials">${icon('file', 15)} الملازم <span class="chip">${d.materials.length}</span></button>
          <button class="tab" data-t="grades">${icon('star', 15)} الدرجات</button>
          <button class="tab" data-t="attendance">${icon('clipboard', 15)} الحضور والغياب</button>
        </div>
        <div id="cpanel"></div>
      </div>`;
    $$('#ctabs .tab').forEach((t) => (t.onclick = () => { tab = t.dataset.t; draw(); }));
    draw();
    const off = App.on('sync', (s) => { if (state.route === `/my-courses/${id}` && ['grades', 'materials', 'attendance'].includes(s.type)) App.render(); });
    window.addEventListener('hashchange', off, { once: true });
  });
})();
