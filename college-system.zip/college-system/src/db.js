// =====================================================================
// قاعدة البيانات (SQLite - ملف واحد داخل data/college.db)
// تعمل مع better-sqlite3 أو مع node:sqlite المدمجة في Node 22.13+
// =====================================================================
const path = require('path');
const fs = require('fs');
const bcrypt = require('bcryptjs');

const DATA_DIR = path.join(__dirname, '..', 'data');
const DB_FILE = process.env.DB_FILE || path.join(DATA_DIR, 'college.db');
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

function openRaw(file) {
  try {
    const Better = require('better-sqlite3');
    const d = new Better(file);
    return { kind: 'better-sqlite3', d };
  } catch (e) {
    try {
      const { DatabaseSync } = require('node:sqlite');
      const d = new DatabaseSync(file);
      return { kind: 'node:sqlite', d };
    } catch (e2) {
      console.error('\n[خطأ] لا يمكن فتح قاعدة البيانات. ثبّت better-sqlite3 (npm install) أو استخدم Node 22.13 أو أحدث.\n');
      throw e;
    }
  }
}

let raw = null;
const stmtCache = new Map();

function open() {
  raw = openRaw(DB_FILE);
  stmtCache.clear();
  raw.d.exec('PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON; PRAGMA busy_timeout = 5000;');
}

function prep(sql) {
  let s = stmtCache.get(sql);
  if (!s) { s = raw.d.prepare(sql); stmtCache.set(sql, s); }
  return s;
}
const clean = (params) => params.map((p) => (p === undefined ? null : typeof p === 'boolean' ? (p ? 1 : 0) : p));

const db = {
  get kind() { return raw.kind; },
  all: (sql, ...p) => prep(sql).all(...clean(p)),
  get: (sql, ...p) => prep(sql).get(...clean(p)),
  run: (sql, ...p) => {
    const r = prep(sql).run(...clean(p));
    return { changes: Number(r.changes), lastId: Number(r.lastInsertRowid) };
  },
  exec: (sql) => raw.d.exec(sql),
  tx(fn) {
    raw.d.exec('BEGIN');
    try { const out = fn(); raw.d.exec('COMMIT'); return out; }
    catch (e) { try { raw.d.exec('ROLLBACK'); } catch (_) {} throw e; }
  },
  file: DB_FILE,
  backupTo(target) {
    if (fs.existsSync(target)) fs.unlinkSync(target);
    raw.d.exec(`VACUUM INTO '${target.replace(/'/g, "''")}'`);
  },
  restoreFrom(source) {
    raw.d.close();
    for (const ext of ['', '-wal', '-shm']) { try { fs.unlinkSync(DB_FILE + ext); } catch (_) {} }
    fs.copyFileSync(source, DB_FILE);
    open();
    migrate();
  },
};

// ---------------------------------------------------------------------
// المخطط (Schema)
// ---------------------------------------------------------------------
const SCHEMA = `
CREATE TABLE IF NOT EXISTS settings (
  key TEXT PRIMARY KEY,
  value TEXT
);

CREATE TABLE IF NOT EXISTS departments (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE,
  name_en TEXT,
  code TEXT,
  description TEXT,
  established TEXT,
  head_name TEXT,
  active INTEGER NOT NULL DEFAULT 1,
  sort INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT NOT NULL UNIQUE COLLATE NOCASE,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('admin','secretary','faculty','student')),
  full_name TEXT NOT NULL,
  department_id INTEGER REFERENCES departments(id) ON DELETE SET NULL,
  stage INTEGER,
  study_type TEXT DEFAULT 'morning',
  batch TEXT,
  section TEXT,
  academic_title TEXT,
  email TEXT,
  phone TEXT,
  bio TEXT,
  office_hours TEXT,
  active INTEGER NOT NULL DEFAULT 1,
  must_change_password INTEGER NOT NULL DEFAULT 0,
  last_login TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

CREATE TABLE IF NOT EXISTS sessions (
  token TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  impersonated_by INTEGER,
  ip TEXT,
  user_agent TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
  expires_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS courses (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  name_en TEXT,
  code TEXT,
  department_id INTEGER NOT NULL REFERENCES departments(id) ON DELETE CASCADE,
  stage INTEGER NOT NULL,
  semester INTEGER NOT NULL DEFAULT 1,
  study_type TEXT NOT NULL DEFAULT 'both',
  ects REAL NOT NULL DEFAULT 5,
  total_hours INTEGER NOT NULL DEFAULT 30,
  faculty_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
  formative_weight INTEGER NOT NULL DEFAULT 50,
  exam_weight INTEGER NOT NULL DEFAULT 50,
  grades_locked INTEGER NOT NULL DEFAULT 0,
  grades_published INTEGER NOT NULL DEFAULT 1,
  description TEXT,
  active INTEGER NOT NULL DEFAULT 1
);

-- تسجيل إضافي (مثل الطالب المحمّل بمادة من مرحلة سابقة)
CREATE TABLE IF NOT EXISTS enrollments (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  student_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  course_id INTEGER NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
  kind TEXT NOT NULL DEFAULT 'carry',
  UNIQUE (student_id, course_id)
);

CREATE TABLE IF NOT EXISTS lectures (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  course_id INTEGER NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
  lecture_date TEXT NOT NULL,
  topic TEXT,
  hours INTEGER NOT NULL DEFAULT 2,
  kind TEXT NOT NULL DEFAULT 'theory',
  created_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

CREATE TABLE IF NOT EXISTS attendance (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  lecture_id INTEGER NOT NULL REFERENCES lectures(id) ON DELETE CASCADE,
  student_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  status TEXT NOT NULL CHECK (status IN ('present','absent','excused')),
  note TEXT,
  UNIQUE (lecture_id, student_id)
);

-- مكونات التقييم لنظام بولونيا (تكويني / نهائي / دور ثاني)
CREATE TABLE IF NOT EXISTS assessment_items (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  course_id INTEGER NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  kind TEXT NOT NULL CHECK (kind IN ('formative','final','resit')),
  max_score REAL NOT NULL,
  sort INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS scores (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  item_id INTEGER NOT NULL REFERENCES assessment_items(id) ON DELETE CASCADE,
  student_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  score REAL,
  updated_by INTEGER,
  updated_at TEXT DEFAULT (datetime('now','localtime')),
  UNIQUE (item_id, student_id)
);

CREATE TABLE IF NOT EXISTS materials (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  course_id INTEGER NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  description TEXT,
  category TEXT NOT NULL DEFAULT 'lecture',
  stored_name TEXT,
  original_name TEXT,
  mime TEXT,
  size INTEGER,
  link_url TEXT,
  downloads INTEGER NOT NULL DEFAULT 0,
  visible INTEGER NOT NULL DEFAULT 1,
  uploaded_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

CREATE TABLE IF NOT EXISTS announcements (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  content TEXT NOT NULL,
  category TEXT NOT NULL DEFAULT 'notice',
  priority TEXT NOT NULL DEFAULT 'normal',
  target_role TEXT NOT NULL DEFAULT 'all',
  target_department_id INTEGER REFERENCES departments(id) ON DELETE CASCADE,
  target_stage INTEGER,
  target_study_type TEXT,
  pinned INTEGER NOT NULL DEFAULT 0,
  author_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

CREATE TABLE IF NOT EXISTS announcement_reads (
  announcement_id INTEGER NOT NULL REFERENCES announcements(id) ON DELETE CASCADE,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  PRIMARY KEY (announcement_id, user_id)
);

-- room: batch:<dept>:<stage>:<study_type>  أو  dm:<student_id> (محادثة الطالب مع السكرتارية)
CREATE TABLE IF NOT EXISTS messages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  room TEXT NOT NULL,
  sender_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  content TEXT NOT NULL,
  seen INTEGER NOT NULL DEFAULT 0,
  deleted INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE INDEX IF NOT EXISTS idx_messages_room ON messages(room, id);

CREATE TABLE IF NOT EXISTS faq (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  question TEXT NOT NULL,
  answer TEXT NOT NULL,
  keywords TEXT
);

CREATE TABLE IF NOT EXISTS audit_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER,
  user_name TEXT,
  action TEXT NOT NULL,
  details TEXT,
  ip TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);
`;

const DEFAULT_SETTINGS = {
  university_name: 'جامعة كركوك',
  college_name: 'كلية علوم الحاسوب وتكنولوجيا المعلومات',
  college_name_en: 'College of Computer Science & Information Technology',
  system_name: 'النظام الأكاديمي والإداري الموحد',
  academic_year: '2026-2027',
  current_semester: '1',
  college_email: 'csit_college_kirkuk@uokirkuk.edu.iq',
  college_phone: '07730241917',
  college_website: 'https://uokirkuk.edu.iq/tec/',
  working_hours: 'الأحد - الخميس 08:30 - 18:00 (الجمعة والسبت عطلة)',
  stages_count: '4',
  absence_warning_pct: '5',
  absence_ban_pct: '10',
  default_formative_weight: '50',
  pass_mark: '50',
  grade_scale: JSON.stringify([
    { min: 90, letter: 'A', ar: 'امتياز', en: 'Excellent' },
    { min: 80, letter: 'B', ar: 'جيد جداً', en: 'Very Good' },
    { min: 70, letter: 'C', ar: 'جيد', en: 'Good' },
    { min: 60, letter: 'D', ar: 'متوسط', en: 'Satisfactory' },
    { min: 50, letter: 'E', ar: 'مقبول', en: 'Sufficient' },
    { min: 45, letter: 'FX', ar: 'راسب - قيد المعالجة', en: 'Fail (conditional)' },
    { min: 0, letter: 'F', ar: 'راسب', en: 'Fail' },
  ]),
  batch_chat_enabled: '1',
  faculty_in_batch_chat: '1',
  secretary_chat_enabled: '1',
  faculty_can_delete_materials: '1',
  students_see_grades: '1',
  max_upload_mb: '50',
  allowed_extensions: 'pdf,doc,docx,ppt,pptx,xls,xlsx,txt,zip,rar,7z,png,jpg,jpeg,mp4,py,java,cpp,c,ipynb',
  login_notice: 'الحسابات تُنشأ حصراً من قبل إدارة القسم. لاستلام بيانات الدخول راجع سكرتارية القسم.',
  bot_name: 'مساعد الكلية الذكي',
  bot_enabled: '1',
  ai_mode: 'local',
  ai_base_url: 'http://localhost:11434/v1',
  ai_model: 'qwen2.5:3b',
  ai_api_key: '',
  maintenance_mode: '0',
  session_hours: '12',
};

const DEPARTMENTS = [
  { name: 'علوم الحاسوب', name_en: 'Computer Science', code: 'CS', established: '2017', sort: 1,
    description: 'دراسة الأسس النظرية والتطبيقية للحوسبة والبرمجة وتحليل الخوارزميات والأنظمة المعقدة.' },
  { name: 'تكنولوجيا المعلومات', name_en: 'Information Technology', code: 'IT', established: '2017', sort: 2,
    description: 'بناء وإدارة البنى التحتية لتكنولوجيا الشبكات، أمن البيانات، والأنظمة السحابية الحديثة.' },
  { name: 'البرمجيات', name_en: 'Software', code: 'SW', established: '2020', sort: 3,
    description: 'تصميم وتطوير الأنظمة البرمجية الضخمة، تطبيقات الويب، والدورات الكاملة لهندسة وتطوير البرامج.' },
  { name: 'الذكاء الاصطناعي', name_en: 'Artificial Intelligence', code: 'AI', established: '2025', sort: 4,
    description: 'تطوير نماذج التعلم الآلي، الرؤية الحاسوبية، النظم الخبيرة، ومعالجة اللغات الطبيعية.' },
];

const DEFAULT_FAQ = [
  { q: 'ما هو مسار بولونيا؟', k: 'بولونيا بولونيه مسار نظام',
    a: 'مسار بولونيا نظام دراسي أوروبي تعتمده الجامعات العراقية، يقوم على الوحدات الأوروبية القابلة للتحويل (ECTS)، والتقييم المستمر طوال الفصل بالإضافة إلى الامتحان النهائي، مع احتساب الجهد الكلي للطالب (حضور + دراسة ذاتية).' },
  { q: 'ما هي وحدة ECTS؟', k: 'ects وحدة وحدات نقاط رصيد',
    a: 'وحدة ECTS تعادل تقريباً 25 ساعة من جهد الطالب الكلي (محاضرات + مختبرات + دراسة ذاتية + واجبات). السنة الدراسية الكاملة تساوي 60 وحدة، والبكالوريوس ذو الأربع سنوات يساوي 240 وحدة.' },
  { q: 'ما معنى تقدير FX؟', k: 'fx قيد المعالجة نجاح مشروط مقبول بقرار',
    a: 'FX يعني أن درجة الطالب بين 45 و49، وهو ضمن مجموعة الرسوب لكنه نجاح مشروط: يُمنح الطالب الوحدات بعد تقديم عمل إضافي يحدده أستاذ المادة.' },
  { q: 'كيف يُحسب الغياب والحرمان؟', k: 'غياب حرمان انذار إنذار نسبة',
    a: 'تُحسب نسبة الغياب من مجموع ساعات المادة المقررة. عند تجاوز نسبة الإنذار يظهر تنبيه، وعند تجاوز نسبة الحرمان المحددة من إدارة القسم يُعتبر الطالب محروماً من المادة. الغياب المُجاز لا يُحتسب ضمن النسبة.' },
  { q: 'كيف أحصل على حسابي أو أغيّر كلمة المرور؟', k: 'حساب كلمة المرور باسورد دخول نسيت',
    a: 'الحسابات تُنشأ من إدارة القسم فقط. إذا نسيت كلمة المرور راسل السكرتارية من قسم "مراسلة السكرتارية" أو راجعهم شخصياً لإعادة تعيينها. يمكنك تغيير كلمة المرور من صفحة "حسابي".' },
  { q: 'ما هي أوقات الدوام؟', k: 'دوام اوقات أوقات ساعات عطلة',
    a: 'أوقات الدوام الرسمي في الكلية من الأحد إلى الخميس 08:30 - 18:00، والجمعة والسبت عطلة.' },
];

function setDefaultSettings() {
  for (const [k, v] of Object.entries(DEFAULT_SETTINGS)) {
    db.run('INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)', k, v);
  }
}

function migrate() {
  db.exec(SCHEMA);
  setDefaultSettings();
  // الأقسام الأربعة
  const deptCount = db.get('SELECT COUNT(*) AS c FROM departments').c;
  if (!deptCount) {
    for (const d of DEPARTMENTS) {
      db.run('INSERT INTO departments (name, name_en, code, description, established, sort) VALUES (?,?,?,?,?,?)',
        d.name, d.name_en, d.code, d.description, d.established, d.sort);
    }
  }
  // حساب رئيس القسم الافتراضي
  const admin = db.get("SELECT id FROM users WHERE role = 'admin' LIMIT 1");
  if (!admin) {
    db.run(`INSERT INTO users (username, password_hash, role, full_name, must_change_password)
            VALUES ('admin', ?, 'admin', 'رئيس القسم', 0)`, bcrypt.hashSync('m1m2m3m4m', 10));
  }
  if (!db.get('SELECT COUNT(*) AS c FROM faq').c) {
    for (const f of DEFAULT_FAQ) db.run('INSERT INTO faq (question, answer, keywords) VALUES (?,?,?)', f.q, f.a, f.k);
  }
  db.run('DELETE FROM sessions WHERE expires_at < ?', Date.now());
}

function init() {
  open();
  migrate();
  return db;
}

// إعدادات
function getSettings() {
  const out = {};
  for (const r of db.all('SELECT key, value FROM settings')) out[r.key] = r.value;
  return out;
}
function setSetting(key, value) {
  db.run('INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value', key, String(value ?? ''));
}

module.exports = { db, init, getSettings, setSetting, DEFAULT_SETTINGS, DB_FILE, DATA_DIR };
