// =====================================================================
// المساعد الذكي
// الوضع "local": يعمل بدون إنترنت، يقرأ بيانات المستخدم من النظام + الأسئلة الشائعة
// الوضع "llm": يتصل بنموذج لغوي متوافق مع OpenAI (مثل Ollama على نفس الشبكة)
// ويعود تلقائياً للوضع المحلي عند فشل الاتصال
// =====================================================================
const { db, getSettings } = require('./db');
const L = require('./logic');

const norm = (s) => String(s || '').toLowerCase()
  .replace(/[إأآا]/g, 'ا').replace(/ى/g, 'ي').replace(/ة/g, 'ه').replace(/[ًٌٍَُِّْـ]/g, '').trim();
const has = (text, words) => words.some((w) => text.includes(norm(w)));

function faqMatch(text) {
  const t = norm(text);
  let best = null, bestScore = 0;
  for (const f of db.all('SELECT * FROM faq')) {
    const words = norm(`${f.keywords || ''} ${f.question}`).split(/\s+/).filter((w) => w.length > 2);
    const score = words.filter((w) => t.includes(w)).length;
    if (score > bestScore) { bestScore = score; best = f; }
  }
  return bestScore > 0 ? best : null;
}

function studentContext(user) {
  const courses = L.studentCourses(user).map((c) => {
    const g = L.computeGrade(c, user.id);
    const a = L.computeAttendance(c, user.id);
    return { c, g, a };
  });
  return courses;
}

function latestAnnouncements(user, n = 3) {
  const v = L.visibleAnnouncementsSQL(user);
  return db.all(`SELECT a.* FROM announcements a WHERE ${v.where} ORDER BY a.pinned DESC, a.id DESC LIMIT ${n}`, ...v.params);
}

function localAnswer(user, message) {
  const t = norm(message);
  const s = getSettings();
  const lines = [];

  if (!t || has(t, ['مرحبا', 'هلو', 'السلام', 'هاي', 'اهلا'])) {
    return `أهلاً ${user.full_name}. أنا ${s.bot_name}. يمكنني مساعدتك في:\n` + helpFor(user);
  }
  if (has(t, ['مساعده', 'ماذا تستطيع', 'شنو تكدر', 'help', 'اوامر'])) return helpFor(user);

  if (user.role === 'student') {
    const ctx = studentContext(user);
    if (has(t, ['غياب', 'غيابات', 'حضور', 'حرمان', 'محروم', 'انذار'])) {
      if (!ctx.length) return 'لا توجد مواد مسجلة لك حالياً.';
      lines.push('ملخص غياباتك:');
      for (const { c, a } of ctx) {
        const st = a.status === 'banned' ? ' — تجاوزت نسبة الحرمان' : a.status === 'warning' ? ' — تنبيه: اقتربت من الحد' : '';
        lines.push(`• ${c.name}: ${a.absent_count} غياب (${a.absent_hours} ساعة، ${a.absence_pct}%)${st}`);
      }
      lines.push(`\nنسبة الإنذار ${s.absence_warning_pct}% ونسبة الحرمان ${s.absence_ban_pct}% من ساعات المادة.`);
      return lines.join('\n');
    }
    if (has(t, ['درجه', 'درجات', 'معدل', 'تقدير', 'نتيجه', 'نتائج', 'سعي', 'تقييم'])) {
      if (s.students_see_grades !== '1') return 'عرض الدرجات للطلبة متوقف حالياً من قبل إدارة القسم.';
      if (!ctx.length) return 'لا توجد مواد مسجلة لك حالياً.';
      lines.push('ملخص درجاتك (نظام بولونيا):');
      let wsum = 0, esum = 0;
      for (const { c, g } of ctx) {
        if (!c.grades_published) { lines.push(`• ${c.name}: لم تُنشر بعد`); continue; }
        const tot = g.total == null ? 'لا توجد درجات بعد' : `${g.total}/100${g.letter ? ` (${g.letter} - ${g.letter_ar})` : ' (السعي فقط)'}`;
        lines.push(`• ${c.name} [${c.ects} ECTS]: التقييم المستمر ${g.formative}/${g.formative_max} — ${tot}`);
        if (g.final && g.total != null) { wsum += g.total * c.ects; esum += c.ects; }
      }
      if (esum) lines.push(`\nالمعدل الموزون بالوحدات: ${(wsum / esum).toFixed(1)}`);
      return lines.join('\n');
    }
    if (has(t, ['مواد', 'ماده', 'ملزمه', 'ملازم', 'محاضره', 'محاضرات', 'مصادر', 'استاذ', 'تدريسي'])) {
      if (!ctx.length) return 'لا توجد مواد مسجلة لك حالياً.';
      lines.push('موادك الدراسية:');
      let totalEcts = 0;
      for (const { c } of ctx) {
        const m = db.get('SELECT COUNT(*) AS n FROM materials WHERE course_id = ? AND visible = 1', c.id).n;
        totalEcts += c.ects;
        lines.push(`• ${c.name} — ${c.faculty_title ? c.faculty_title + ' ' : ''}${c.faculty_name || 'لم يُحدد التدريسي'} — ${c.ects} ECTS — ${m} ملف`);
      }
      lines.push(`\nمجموع الوحدات: ${totalEcts} ECTS. يمكنك تحميل الملازم من صفحة "موادي".`);
      return lines.join('\n');
    }
  }

  if (user.role === 'faculty' || user.role === 'admin') {
    if (has(t, ['حرمان', 'محروم', 'انذار', 'غياب', 'معرض', 'خطر'])) {
      const courses = user.role === 'admin'
        ? db.all('SELECT * FROM courses WHERE active = 1')
        : db.all('SELECT * FROM courses WHERE faculty_id = ? AND active = 1', user.id);
      const risky = [];
      for (const c of courses) {
        for (const st of L.courseStudents(c.id)) {
          const a = L.computeAttendance(c, st.id);
          if (a.status !== 'ok') risky.push(`• ${st.full_name} — ${c.name}: ${a.absence_pct}% ${a.status === 'banned' ? '(حرمان)' : '(إنذار)'}`);
        }
      }
      return risky.length ? `الطلبة المعرضون للإنذار أو الحرمان (${risky.length}):\n${risky.slice(0, 30).join('\n')}` : 'لا يوجد طلبة تجاوزوا نسب الغياب حالياً.';
    }
  }

  if (user.role === 'admin' && has(t, ['احصائ', 'عدد', 'كم طالب', 'ملخص', 'تقرير'])) {
    const c = (sql) => db.get(sql).n;
    return `ملخص النظام:\n• الطلبة: ${c("SELECT COUNT(*) n FROM users WHERE role='student' AND active=1")}\n• التدريسيون: ${c("SELECT COUNT(*) n FROM users WHERE role='faculty' AND active=1")}\n• المواد: ${c('SELECT COUNT(*) n FROM courses WHERE active=1')}\n• الملفات المرفوعة: ${c('SELECT COUNT(*) n FROM materials')}\n• رسائل السكرتارية غير المقروءة: ${c("SELECT COUNT(*) n FROM messages m JOIN users u ON u.id=m.sender_id WHERE m.room LIKE 'dm:%' AND u.role='student' AND m.seen=0")}`;
  }

  if (has(t, ['تبليغ', 'تبليغات', 'اعلان', 'تعميم', 'تعاميم', 'جديد', 'اخبار'])) {
    const list = latestAnnouncements(user, 4);
    if (!list.length) return 'لا توجد تبليغات حالياً.';
    return 'آخر التبليغات:\n' + list.map((a) => `• ${a.title} (${a.created_at.slice(0, 10)})`).join('\n');
  }

  if (has(t, ['تقدير', 'سلم', 'fx', 'امتياز', 'جيد جدا', 'مقبول'])) {
    const scale = L.gradeScale();
    return 'سلم التقديرات المعتمد في مسار بولونيا:\n' + scale.map((g, i) => {
      const max = i === 0 ? 100 : scale[i - 1].min - 1;
      return `• ${g.letter} - ${g.ar}: ${g.min} - ${max}`;
    }).join('\n');
  }

  const f = faqMatch(message);
  if (f) return f.answer;

  if (has(t, ['تواصل', 'ايميل', 'بريد', 'هاتف', 'رقم', 'عنوان'])) {
    return `للتواصل مع ${s.college_name}:\n• البريد: ${s.college_email}\n• الهاتف: ${s.college_phone}\n• الدوام: ${s.working_hours}\n• أو راسل السكرتارية من داخل النظام.`;
  }

  return 'لم أفهم سؤالك بدقة. جرّب أن تسأل مثلاً:\n' + helpFor(user);
}

function helpFor(user) {
  if (user.role === 'student') return '• "كم غياباتي؟"\n• "شنو درجاتي؟"\n• "ما هي موادي؟"\n• "آخر التبليغات"\n• "ما معنى FX؟" أو "ما هو مسار بولونيا؟"';
  if (user.role === 'faculty') return '• "من هم الطلبة المعرضون للحرمان؟"\n• "آخر التبليغات"\n• "ما هو سلم التقديرات؟"';
  return '• "ملخص النظام"\n• "الطلبة المعرضون للحرمان"\n• "آخر التبليغات"\n• "سلم التقديرات"';
}

function contextForLLM(user) {
  const s = getSettings();
  const parts = [
    `أنت ${s.bot_name} في ${s.college_name} - ${s.university_name}. أجب بالعربية بإيجاز ودقة. لا تخترع معلومات غير موجودة في السياق.`,
    `المستخدم: ${user.full_name} (${user.role}).`,
  ];
  if (user.role === 'student') {
    for (const { c, g, a } of studentContext(user)) {
      parts.push(`مادة ${c.name}: ${c.ects} ECTS، التدريسي ${c.faculty_name || '-'}، التقييم المستمر ${g.formative}/${g.formative_max}، المجموع ${g.total ?? '-'} ${g.letter || ''}، الغياب ${a.absent_count} (${a.absence_pct}%).`);
    }
  }
  parts.push('الأسئلة الشائعة:\n' + db.all('SELECT question, answer FROM faq').map((f) => `س: ${f.question}\nج: ${f.answer}`).join('\n'));
  parts.push('آخر التبليغات:\n' + latestAnnouncements(user, 5).map((a) => `- ${a.title}: ${a.content.slice(0, 300)}`).join('\n'));
  return parts.join('\n');
}

async function answer(user, message, history = []) {
  const s = getSettings();
  if (s.bot_enabled !== '1') return { reply: 'المساعد الذكي متوقف حالياً من قبل إدارة القسم.', mode: 'off' };
  if (s.ai_mode === 'llm' && s.ai_base_url) {
    try {
      const ctrl = new AbortController();
      const timer = setTimeout(() => ctrl.abort(), 45000);
      const r = await fetch(`${s.ai_base_url.replace(/\/$/, '')}/chat/completions`, {
        method: 'POST',
        signal: ctrl.signal,
        headers: { 'Content-Type': 'application/json', ...(s.ai_api_key ? { Authorization: `Bearer ${s.ai_api_key}` } : {}) },
        body: JSON.stringify({
          model: s.ai_model,
          messages: [{ role: 'system', content: contextForLLM(user) }, ...history.slice(-6), { role: 'user', content: message }],
          temperature: 0.3,
        }),
      });
      clearTimeout(timer);
      if (r.ok) {
        const j = await r.json();
        const text = j.choices?.[0]?.message?.content;
        if (text) return { reply: text.trim(), mode: 'llm' };
      }
    } catch (_) { /* نعود للوضع المحلي */ }
  }
  return { reply: localAnswer(user, message), mode: 'local' };
}

module.exports = { answer };
