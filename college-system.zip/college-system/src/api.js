// =====================================================================
// واجهة البرمجة (REST API) - جميع المسارات محمية بالصلاحيات من جهة السيرفر
// =====================================================================
const express = require('express');
const path = require('path');
const fs = require('fs');
const os = require('os');
const multer = require('multer');
const QRCode = require('qrcode');
const { db, getSettings, setSetting, DEFAULT_SETTINGS, DATA_DIR } = require('./db');
const A = require('./auth');
const L = require('./logic');
const bot = require('./bot');

const UPLOAD_DIR = path.join(__dirname, '..', 'uploads');
const BRAND_DIR = path.join(UPLOAD_DIR, 'branding');
for (const d of [UPLOAD_DIR, BRAND_DIR]) if (!fs.existsSync(d)) fs.mkdirSync(d, { recursive: true });

const upload = multer({
  storage: multer.diskStorage({
    destination: UPLOAD_DIR,
    filename: (req, file, cb) => cb(null, `${Date.now()}-${Math.random().toString(36).slice(2, 8)}${path.extname(file.originalname).toLowerCase()}`),
  }),
  limits: { fileSize: 500 * 1024 * 1024 },
});
const fixName = (n) => { try { return Buffer.from(n, 'latin1').toString('utf8'); } catch { return n; } };

const wrap = (fn) => (req, res, next) => { try { const r = fn(req, res, next); if (r && r.catch) r.catch(next); } catch (e) { next(e); } };
const int = (v) => (v === '' || v === null || v === undefined ? null : Number.parseInt(v, 10));
const bad = (res, msg, code = 400) => res.status(code).json({ error: msg });

module.exports = function buildApi(io) {
  const r = express.Router();
  const emitSync = (type, extra = {}) => io && io.emit('sync', { type, ...extra });
  const emitToUser = (uid, ev, data) => io && io.to(`user:${uid}`).emit(ev, data);

  // ===================== عام =====================
  r.get('/public/info', wrap((req, res) => {
    const s = getSettings();
    res.json({
      university_name: s.university_name, college_name: s.college_name, college_name_en: s.college_name_en,
      system_name: s.system_name, academic_year: s.academic_year, login_notice: s.login_notice,
      college_email: s.college_email, college_phone: s.college_phone, working_hours: s.working_hours,
      college_website: s.college_website, maintenance_mode: s.maintenance_mode === '1',
      stages_count: Number(s.stages_count) || 4, bot_name: s.bot_name, bot_enabled: s.bot_enabled === '1', pass_mark: Number(s.pass_mark) || 50,
      absence_warning_pct: Number(s.absence_warning_pct), absence_ban_pct: Number(s.absence_ban_pct), secretary_chat_enabled: s.secretary_chat_enabled === '1',
      college_logo: s.college_logo || 'img/college-logo.png', university_logo: s.university_logo || 'img/university-logo.png',
      departments: db.all('SELECT id, name, name_en, code, description, established FROM departments WHERE active = 1 ORDER BY sort, id'),
    });
  }));
  r.get('/branding/:file', (req, res) => {
    const f = path.join(BRAND_DIR, path.basename(req.params.file));
    if (!fs.existsSync(f)) return res.status(404).end();
    res.sendFile(f);
  });

  // ===================== الدخول =====================
  r.post('/auth/login', wrap((req, res) => {
    const username = String(req.body.username || '').trim();
    const password = String(req.body.password || '');
    const key = `${username.toLowerCase()}|${A.clientIp(req)}`;
    if (A.loginBlocked(key)) return bad(res, 'محاولات كثيرة خاطئة. حاول بعد 5 دقائق.', 429);
    const u = db.get('SELECT * FROM users WHERE username = ?', username);
    if (!u || !A.verify(password, u.password_hash)) {
      A.loginFailed(key);
      return bad(res, 'خطأ في اسم المستخدم أو كلمة المرور', 401);
    }
    if (!u.active) return bad(res, 'هذا الحساب معطّل. راجع إدارة القسم.', 403);
    if (getSettings().maintenance_mode === '1' && u.role !== 'admin') return bad(res, 'النظام في وضع الصيانة حالياً', 403);
    A.loginOk(key);
    const token = A.createSession(u.id, req);
    db.run("UPDATE users SET last_login = datetime('now','localtime') WHERE id = ?", u.id);
    A.setCookie(res, token);
    req.user = u;
    A.audit(req, 'تسجيل دخول', `${u.username}`);
    res.json({ token, user: A.userByToken(token), default_password: u.username === 'admin' && password === 'm1m2m3m4m' });
  }));

  r.post('/auth/logout', wrap((req, res) => {
    const t = A.tokenFrom(req);
    if (t) db.run('DELETE FROM sessions WHERE token = ?', t);
    A.clearCookie(res);
    res.json({ ok: true });
  }));

  r.use(A.auth); // كل ما بعد هذا السطر يتطلب تسجيل دخول

  r.get('/auth/me', (req, res) => {
    const u = { ...req.user };
    const isDefault = u.role === 'admin' && A.verify('m1m2m3m4m', db.get('SELECT password_hash FROM users WHERE id=?', u.id).password_hash);
    res.json({ user: u, token: req.user.token, default_password: isDefault, impersonating: !!u.impersonated_by });
  });

  r.post('/auth/change-password', wrap((req, res) => {
    const { current, next: nw } = req.body;
    const row = db.get('SELECT password_hash FROM users WHERE id = ?', req.user.id);
    if (!req.user.impersonated_by && !A.verify(current, row.password_hash)) return bad(res, 'كلمة المرور الحالية غير صحيحة');
    if (!nw || String(nw).length < 6) return bad(res, 'كلمة المرور الجديدة يجب أن تكون 6 أحرف على الأقل');
    db.run('UPDATE users SET password_hash = ?, must_change_password = 0 WHERE id = ?', A.hash(nw), req.user.id);
    db.run('DELETE FROM sessions WHERE user_id = ? AND token <> ?', req.user.id, req.user.token);
    A.audit(req, 'تغيير كلمة المرور', req.user.username);
    res.json({ ok: true });
  }));

  r.put('/profile', wrap((req, res) => {
    const { email, phone, bio, office_hours } = req.body;
    db.run('UPDATE users SET email = ?, phone = ?, bio = COALESCE(?, bio), office_hours = COALESCE(?, office_hours) WHERE id = ?',
      email || null, phone || null, req.user.role === 'student' ? null : bio, req.user.role === 'student' ? null : office_hours, req.user.id);
    res.json({ ok: true });
  }));

  // ===================== لوحة البداية لكل دور =====================
  r.get('/dashboard', wrap((req, res) => {
    const u = req.user;
    const s = getSettings();
    const v = L.visibleAnnouncementsSQL(u);
    const announcements = db.all(`SELECT a.*, (SELECT 1 FROM announcement_reads r WHERE r.announcement_id = a.id AND r.user_id = ?) AS is_read
                                    FROM announcements a WHERE ${v.where} ORDER BY a.pinned DESC, a.id DESC LIMIT 5`, u.id, ...v.params);
    const out = { announcements };
    if (u.role === 'student') {
      const courses = L.studentCourses(u).map((c) => ({
        id: c.id, name: c.name, ects: c.ects, faculty_name: c.faculty_name,
        grade: s.students_see_grades === '1' && c.grades_published ? L.computeGrade(c, u.id) : null,
        attendance: (({ log, ...rest }) => rest)(L.computeAttendance(c, u.id)),
      }));
      out.courses = courses;
      out.total_ects = courses.reduce((a, c) => a + c.ects, 0);
      out.unread_dm = db.get(`SELECT COUNT(*) n FROM messages m JOIN users x ON x.id = m.sender_id
                               WHERE m.room = ? AND x.role <> 'student' AND m.seen = 0 AND m.deleted = 0`, `dm:${u.id}`).n;
    } else if (u.role === 'faculty') {
      out.courses = db.all(`SELECT c.*, d.name AS department_name FROM courses c LEFT JOIN departments d ON d.id = c.department_id
                             WHERE c.faculty_id = ? AND c.active = 1 ORDER BY c.stage, c.name`, u.id).map((c) => ({
        ...c, students: L.courseStudents(c.id).length,
        lectures: db.get('SELECT COUNT(*) n FROM lectures WHERE course_id = ?', c.id).n,
        materials: db.get('SELECT COUNT(*) n FROM materials WHERE course_id = ?', c.id).n,
      }));
    } else {
      const n = (sql, ...p) => db.get(sql, ...p).n;
      out.stats = {
        students: n("SELECT COUNT(*) n FROM users WHERE role='student' AND active=1"),
        faculty: n("SELECT COUNT(*) n FROM users WHERE role='faculty' AND active=1"),
        courses: n('SELECT COUNT(*) n FROM courses WHERE active=1'),
        materials: n('SELECT COUNT(*) n FROM materials'),
        lectures: n('SELECT COUNT(*) n FROM lectures'),
        announcements: n('SELECT COUNT(*) n FROM announcements'),
        unread_dm: n("SELECT COUNT(*) n FROM messages m JOIN users x ON x.id=m.sender_id WHERE m.room LIKE 'dm:%' AND x.role='student' AND m.seen=0 AND m.deleted=0"),
        sessions: n('SELECT COUNT(*) n FROM sessions WHERE expires_at > ?', Date.now()),
      };
      out.by_department = db.all(`SELECT d.id, d.name, d.code,
            (SELECT COUNT(*) FROM users u WHERE u.department_id = d.id AND u.role='student' AND u.active=1) AS students,
            (SELECT COUNT(*) FROM users u WHERE u.department_id = d.id AND u.role='faculty' AND u.active=1) AS faculty,
            (SELECT COUNT(*) FROM courses c WHERE c.department_id = d.id AND c.active=1) AS courses
          FROM departments d WHERE d.active = 1 ORDER BY d.sort, d.id`);
      const att = db.get(`SELECT SUM(CASE WHEN status='present' THEN 1 ELSE 0 END) p, SUM(CASE WHEN status='absent' THEN 1 ELSE 0 END) a,
                                 SUM(CASE WHEN status='excused' THEN 1 ELSE 0 END) e FROM attendance`);
      out.attendance = { present: att.p || 0, absent: att.a || 0, excused: att.e || 0 };
      out.at_risk = atRisk().slice(0, 8);
      if (u.role === 'admin') out.recent_audit = db.all('SELECT * FROM audit_log ORDER BY id DESC LIMIT 8');
    }
    res.json(out);
  }));

  function atRisk(filter = {}) {
    const list = [];
    let sql = 'SELECT * FROM courses WHERE active = 1';
    const p = [];
    if (filter.department_id) { sql += ' AND department_id = ?'; p.push(filter.department_id); }
    if (filter.stage) { sql += ' AND stage = ?'; p.push(filter.stage); }
    for (const c of db.all(sql, ...p)) {
      for (const st of L.courseStudents(c.id)) {
        const a = L.computeAttendance(c, st.id);
        if (a.status !== 'ok') list.push({ student_id: st.id, student: st.full_name, username: st.username, course_id: c.id, course: c.name, pct: a.absence_pct, status: a.status, absent: a.absent_count });
      }
    }
    return list.sort((a, b) => b.pct - a.pct);
  }

  // ===================== التبليغات =====================
  r.get('/announcements', wrap((req, res) => {
    const v = L.visibleAnnouncementsSQL(req.user);
    res.json(db.all(`SELECT a.*, u.full_name AS author_name, d.name AS department_name,
                       (SELECT 1 FROM announcement_reads r WHERE r.announcement_id = a.id AND r.user_id = ?) AS is_read,
                       (SELECT COUNT(*) FROM announcement_reads r WHERE r.announcement_id = a.id) AS reads
                       FROM announcements a LEFT JOIN users u ON u.id = a.author_id LEFT JOIN departments d ON d.id = a.target_department_id
                      WHERE ${v.where} ORDER BY a.pinned DESC, a.id DESC`, req.user.id, ...v.params));
  }));
  r.get('/announcements/unread-count', wrap((req, res) => {
    const v = L.visibleAnnouncementsSQL(req.user);
    res.json({ n: db.get(`SELECT COUNT(*) n FROM announcements a WHERE ${v.where}
                          AND NOT EXISTS (SELECT 1 FROM announcement_reads r WHERE r.announcement_id = a.id AND r.user_id = ?)`, ...v.params, req.user.id).n });
  }));
  r.post('/announcements/read-all', wrap((req, res) => {
    const v = L.visibleAnnouncementsSQL(req.user);
    for (const a of db.all(`SELECT a.id FROM announcements a WHERE ${v.where}`, ...v.params)) db.run('INSERT OR IGNORE INTO announcement_reads VALUES (?, ?)', a.id, req.user.id);
    res.json({ ok: true });
  }));
  const annFields = (b) => [b.title, b.content, b.category || 'notice', b.priority || 'normal', b.target_role || 'all',
    int(b.target_department_id), int(b.target_stage), b.target_study_type || null, b.pinned ? 1 : 0];
  r.post('/announcements', A.allow('admin', 'secretary'), wrap((req, res) => {
    if (!req.body.title || !req.body.content) return bad(res, 'العنوان والمحتوى مطلوبان');
    const { lastId } = db.run(`INSERT INTO announcements (title, content, category, priority, target_role, target_department_id, target_stage, target_study_type, pinned, author_id)
                               VALUES (?,?,?,?,?,?,?,?,?,?)`, ...annFields(req.body), req.user.id);
    A.audit(req, 'نشر تبليغ', req.body.title);
    emitSync('announcements', { title: req.body.title, priority: req.body.priority });
    res.json({ id: lastId });
  }));
  r.put('/announcements/:id', A.allow('admin', 'secretary'), wrap((req, res) => {
    db.run(`UPDATE announcements SET title=?, content=?, category=?, priority=?, target_role=?, target_department_id=?, target_stage=?, target_study_type=?, pinned=? WHERE id=?`,
      ...annFields(req.body), req.params.id);
    A.audit(req, 'تعديل تبليغ', req.body.title);
    emitSync('announcements');
    res.json({ ok: true });
  }));
  r.delete('/announcements/:id', A.allow('admin', 'secretary'), wrap((req, res) => {
    db.run('DELETE FROM announcements WHERE id = ?', req.params.id);
    A.audit(req, 'حذف تبليغ', `#${req.params.id}`);
    emitSync('announcements');
    res.json({ ok: true });
  }));

  // ===================== دليل الكادر التدريسي =====================
  r.get('/faculty-directory', wrap((req, res) => {
    const list = db.all(`SELECT u.id, u.full_name, u.academic_title, u.email, u.bio, u.office_hours, d.name AS department_name
                           FROM users u LEFT JOIN departments d ON d.id = u.department_id
                          WHERE u.role = 'faculty' AND u.active = 1 ORDER BY d.sort, u.full_name`);
    for (const f of list) {
      f.courses = db.all(`SELECT c.name, c.stage, d.name AS department_name FROM courses c LEFT JOIN departments d ON d.id = c.department_id
                           WHERE c.faculty_id = ? AND c.active = 1`, f.id);
    }
    res.json(list);
  }));

  // ===================== الطالب =====================
  r.get('/student/courses', A.allow('student'), wrap((req, res) => {
    const s = getSettings();
    res.json(L.studentCourses(req.user).map((c) => ({
      ...c,
      materials_count: db.get('SELECT COUNT(*) n FROM materials WHERE course_id = ? AND visible = 1', c.id).n,
      grade: s.students_see_grades === '1' && c.grades_published ? L.computeGrade(c, req.user.id) : null,
      attendance: (({ log, ...rest }) => rest)(L.computeAttendance(c, req.user.id)),
    })));
  }));
  r.get('/student/courses/:id', A.allow('student'), wrap((req, res) => {
    const c = L.studentCourses(req.user).find((x) => x.id === Number(req.params.id));
    if (!c) return bad(res, 'المادة غير موجودة ضمن موادك', 404);
    const s = getSettings();
    res.json({
      course: c,
      materials: db.all('SELECT id, title, description, category, original_name, size, mime, link_url, created_at FROM materials WHERE course_id = ? AND visible = 1 ORDER BY id DESC', c.id),
      grade: s.students_see_grades === '1' && c.grades_published ? L.computeGrade(c, req.user.id) : null,
      attendance: L.computeAttendance(c, req.user.id),
    });
  }));

  // ===================== صلاحية الوصول لمادة =====================
  function courseFor(req, res, id) {
    const c = db.get(`SELECT c.*, d.name AS department_name, f.full_name AS faculty_name FROM courses c
                        LEFT JOIN departments d ON d.id = c.department_id LEFT JOIN users f ON f.id = c.faculty_id WHERE c.id = ?`, id);
    if (!c) { bad(res, 'المادة غير موجودة', 404); return null; }
    if (req.user.role === 'admin' || (req.user.role === 'faculty' && c.faculty_id === req.user.id)) return c;
    bad(res, 'هذه المادة غير مسندة إليك', 403);
    return null;
  }

  r.get('/teaching/courses', A.allow('faculty', 'admin'), wrap((req, res) => {
    const rows = req.user.role === 'admin'
      ? db.all(`SELECT c.*, d.name AS department_name, f.full_name AS faculty_name FROM courses c LEFT JOIN departments d ON d.id=c.department_id LEFT JOIN users f ON f.id=c.faculty_id ORDER BY d.sort, c.stage, c.name`)
      : db.all(`SELECT c.*, d.name AS department_name, f.full_name AS faculty_name FROM courses c LEFT JOIN departments d ON d.id=c.department_id LEFT JOIN users f ON f.id=c.faculty_id WHERE c.faculty_id = ? ORDER BY c.stage, c.name`, req.user.id);
    res.json(rows.map((c) => ({ ...c, students: L.courseStudents(c.id).length })));
  }));

  r.get('/courses/:id/workspace', A.allow('faculty', 'admin'), wrap((req, res) => {
    const c = courseFor(req, res, req.params.id); if (!c) return;
    const students = L.courseStudents(c.id);
    const items = db.all('SELECT * FROM assessment_items WHERE course_id = ? ORDER BY sort, id', c.id);
    const scoreRows = db.all('SELECT s.item_id, s.student_id, s.score FROM scores s JOIN assessment_items i ON i.id = s.item_id WHERE i.course_id = ?', c.id);
    const map = {};
    for (const s of scoreRows) (map[s.student_id] ||= {})[s.item_id] = s.score;
    res.json({
      course: c, items,
      students: students.map((st) => ({
        ...st, scores: map[st.id] || {},
        grade: L.computeGrade(c, st.id, items, map[st.id] || {}),
        attendance: (({ log, ...rest }) => rest)(L.computeAttendance(c, st.id)),
      })),
      lectures: db.all(`SELECT l.*, (SELECT COUNT(*) FROM attendance a WHERE a.lecture_id = l.id AND a.status='absent') AS absent,
                          (SELECT COUNT(*) FROM attendance a WHERE a.lecture_id = l.id AND a.status='present') AS present,
                          (SELECT COUNT(*) FROM attendance a WHERE a.lecture_id = l.id AND a.status='excused') AS excused
                          FROM lectures l WHERE l.course_id = ? ORDER BY l.lecture_date DESC, l.id DESC`, c.id),
      materials: db.all('SELECT m.*, u.full_name AS uploader FROM materials m LEFT JOIN users u ON u.id = m.uploaded_by WHERE m.course_id = ? ORDER BY m.id DESC', c.id),
      scale: L.gradeScale(),
    });
  }));

  // ---------- الملازم والمصادر ----------
  r.post('/courses/:id/materials', A.allow('faculty', 'admin'), upload.single('file'), wrap((req, res) => {
    const c = courseFor(req, res, req.params.id);
    if (!c) { if (req.file) fs.unlink(req.file.path, () => {}); return; }
    const s = getSettings();
    const { title, description, category, link_url } = req.body;
    if (!title) { if (req.file) fs.unlink(req.file.path, () => {}); return bad(res, 'عنوان الملف مطلوب'); }
    if (!req.file && !link_url) return bad(res, 'اختر ملفاً أو أدخل رابطاً');
    if (req.file) {
      const ext = path.extname(req.file.originalname).slice(1).toLowerCase();
      const allowed = s.allowed_extensions.split(',').map((x) => x.trim().toLowerCase());
      if (!allowed.includes(ext)) { fs.unlink(req.file.path, () => {}); return bad(res, `نوع الملف .${ext} غير مسموح`); }
      if (req.file.size > Number(s.max_upload_mb) * 1024 * 1024) { fs.unlink(req.file.path, () => {}); return bad(res, `حجم الملف يتجاوز ${s.max_upload_mb} ميغابايت`); }
    }
    const { lastId } = db.run(`INSERT INTO materials (course_id, title, description, category, stored_name, original_name, mime, size, link_url, uploaded_by)
                               VALUES (?,?,?,?,?,?,?,?,?,?)`, c.id, title, description || null, category || 'lecture',
      req.file?.filename || null, req.file ? fixName(req.file.originalname) : null, req.file?.mimetype || null, req.file?.size || null, link_url || null, req.user.id);
    A.audit(req, 'رفع ملزمة', `${c.name}: ${title}`);
    emitSync('materials', { course_id: c.id, title, course: c.name });
    res.json({ id: lastId });
  }));
  r.put('/materials/:id', A.allow('faculty', 'admin'), wrap((req, res) => {
    const m = db.get('SELECT * FROM materials WHERE id = ?', req.params.id);
    if (!m) return bad(res, 'الملف غير موجود', 404);
    if (!courseFor(req, res, m.course_id)) return;
    const { title, description, category, visible, link_url } = req.body;
    db.run('UPDATE materials SET title=?, description=?, category=?, visible=?, link_url=COALESCE(?, link_url) WHERE id=?',
      title || m.title, description ?? m.description, category || m.category, visible === undefined ? m.visible : (visible ? 1 : 0), link_url || null, m.id);
    A.audit(req, 'تعديل ملزمة', title || m.title);
    emitSync('materials', { course_id: m.course_id });
    res.json({ ok: true });
  }));
  r.delete('/materials/:id', A.allow('faculty', 'admin'), wrap((req, res) => {
    const m = db.get('SELECT * FROM materials WHERE id = ?', req.params.id);
    if (!m) return bad(res, 'الملف غير موجود', 404);
    if (!courseFor(req, res, m.course_id)) return;
    if (req.user.role === 'faculty' && getSettings().faculty_can_delete_materials !== '1') return bad(res, 'حذف الملفات متاح للإدارة فقط', 403);
    db.run('DELETE FROM materials WHERE id = ?', m.id);
    if (m.stored_name) fs.unlink(path.join(UPLOAD_DIR, m.stored_name), () => {});
    A.audit(req, 'حذف ملزمة', m.title);
    emitSync('materials', { course_id: m.course_id });
    res.json({ ok: true });
  }));
  r.get('/materials/:id/download', wrap((req, res) => {
    const m = db.get('SELECT m.*, c.faculty_id FROM materials m JOIN courses c ON c.id = m.course_id WHERE m.id = ?', req.params.id);
    if (!m) return bad(res, 'الملف غير موجود', 404);
    const u = req.user;
    const ok = u.role === 'admin' || u.role === 'secretary' || (u.role === 'faculty' && m.faculty_id === u.id) ||
      (u.role === 'student' && m.visible && L.isStudentInCourse(u.id, m.course_id));
    if (!ok) return bad(res, 'لا تملك صلاحية تحميل هذا الملف', 403);
    if (m.link_url && !m.stored_name) return res.redirect(m.link_url);
    db.run('UPDATE materials SET downloads = downloads + 1 WHERE id = ?', m.id);
    const inline = req.query.inline === '1';
    res.setHeader('Content-Disposition', `${inline ? 'inline' : 'attachment'}; filename*=UTF-8''${encodeURIComponent(m.original_name || 'file')}`);
    if (m.mime) res.setHeader('Content-Type', m.mime);
    res.sendFile(path.join(UPLOAD_DIR, m.stored_name));
  }));

  // ---------- المحاضرات والحضور (تسجيل يدوي) ----------
  r.post('/courses/:id/lectures', A.allow('faculty', 'admin'), wrap((req, res) => {
    const c = courseFor(req, res, req.params.id); if (!c) return;
    const { lecture_date, topic, hours, kind, attendance = [] } = req.body;
    if (!lecture_date) return bad(res, 'تاريخ المحاضرة مطلوب');
    const valid = new Set(L.courseStudents(c.id).map((s) => s.id));
    const id = db.tx(() => {
      const { lastId } = db.run('INSERT INTO lectures (course_id, lecture_date, topic, hours, kind, created_by) VALUES (?,?,?,?,?,?)',
        c.id, lecture_date, topic || null, int(hours) || 2, kind || 'theory', req.user.id);
      for (const a of attendance) {
        if (!valid.has(Number(a.student_id))) continue;
        db.run('INSERT INTO attendance (lecture_id, student_id, status, note) VALUES (?,?,?,?)', lastId, a.student_id, a.status || 'present', a.note || null);
      }
      return lastId;
    });
    A.audit(req, 'تسجيل حضور', `${c.name} - ${lecture_date}`);
    emitSync('attendance', { course_id: c.id });
    res.json({ id });
  }));
  r.get('/lectures/:id', A.allow('faculty', 'admin'), wrap((req, res) => {
    const l = db.get('SELECT * FROM lectures WHERE id = ?', req.params.id);
    if (!l) return bad(res, 'المحاضرة غير موجودة', 404);
    if (!courseFor(req, res, l.course_id)) return;
    const map = {};
    for (const a of db.all('SELECT * FROM attendance WHERE lecture_id = ?', l.id)) map[a.student_id] = a;
    res.json({ lecture: l, students: L.courseStudents(l.course_id).map((s) => ({ ...s, status: map[s.id]?.status || null, note: map[s.id]?.note || '' })) });
  }));
  r.put('/lectures/:id', A.allow('faculty', 'admin'), wrap((req, res) => {
    const l = db.get('SELECT * FROM lectures WHERE id = ?', req.params.id);
    if (!l) return bad(res, 'المحاضرة غير موجودة', 404);
    if (!courseFor(req, res, l.course_id)) return;
    const { lecture_date, topic, hours, kind, attendance = [] } = req.body;
    db.tx(() => {
      db.run('UPDATE lectures SET lecture_date=?, topic=?, hours=?, kind=? WHERE id=?', lecture_date || l.lecture_date, topic ?? l.topic, int(hours) || l.hours, kind || l.kind, l.id);
      for (const a of attendance) {
        db.run(`INSERT INTO attendance (lecture_id, student_id, status, note) VALUES (?,?,?,?)
                ON CONFLICT(lecture_id, student_id) DO UPDATE SET status = excluded.status, note = excluded.note`, l.id, a.student_id, a.status || 'present', a.note || null);
      }
    });
    A.audit(req, 'تعديل حضور', `محاضرة #${l.id} (${l.lecture_date})`);
    emitSync('attendance', { course_id: l.course_id });
    res.json({ ok: true });
  }));
  r.delete('/lectures/:id', A.allow('faculty', 'admin'), wrap((req, res) => {
    const l = db.get('SELECT * FROM lectures WHERE id = ?', req.params.id);
    if (!l) return bad(res, 'المحاضرة غير موجودة', 404);
    if (!courseFor(req, res, l.course_id)) return;
    db.run('DELETE FROM lectures WHERE id = ?', l.id);
    A.audit(req, 'حذف محاضرة', `${l.lecture_date}`);
    emitSync('attendance', { course_id: l.course_id });
    res.json({ ok: true });
  }));

  // ---------- مكونات التقييم والدرجات ----------
  r.post('/courses/:id/items', A.allow('faculty', 'admin'), wrap((req, res) => {
    const c = courseFor(req, res, req.params.id); if (!c) return;
    if (c.grades_locked && req.user.role !== 'admin') return bad(res, 'الدرجات مقفلة من قبل الإدارة', 403);
    const { title, kind, max_score } = req.body;
    if (!title || !['formative', 'final', 'resit'].includes(kind) || !(Number(max_score) > 0)) return bad(res, 'بيانات المكوّن غير صحيحة');
    const sort = (db.get('SELECT MAX(sort) m FROM assessment_items WHERE course_id = ?', c.id).m || 0) + 1;
    db.run('INSERT INTO assessment_items (course_id, title, kind, max_score, sort) VALUES (?,?,?,?,?)', c.id, title, kind, Number(max_score), sort);
    A.audit(req, 'إضافة مكون تقييم', `${c.name}: ${title}`);
    res.json({ ok: true });
  }));
  r.put('/items/:id', A.allow('faculty', 'admin'), wrap((req, res) => {
    const it = db.get('SELECT * FROM assessment_items WHERE id = ?', req.params.id);
    if (!it) return bad(res, 'غير موجود', 404);
    const c = courseFor(req, res, it.course_id); if (!c) return;
    if (c.grades_locked && req.user.role !== 'admin') return bad(res, 'الدرجات مقفلة من قبل الإدارة', 403);
    db.run('UPDATE assessment_items SET title=?, max_score=?, kind=? WHERE id=?', req.body.title || it.title, Number(req.body.max_score) || it.max_score, req.body.kind || it.kind, it.id);
    res.json({ ok: true });
  }));
  r.delete('/items/:id', A.allow('faculty', 'admin'), wrap((req, res) => {
    const it = db.get('SELECT * FROM assessment_items WHERE id = ?', req.params.id);
    if (!it) return bad(res, 'غير موجود', 404);
    const c = courseFor(req, res, it.course_id); if (!c) return;
    if (c.grades_locked && req.user.role !== 'admin') return bad(res, 'الدرجات مقفلة من قبل الإدارة', 403);
    db.run('DELETE FROM assessment_items WHERE id = ?', it.id);
    A.audit(req, 'حذف مكون تقييم', `${c.name}: ${it.title}`);
    res.json({ ok: true });
  }));
  r.put('/courses/:id/scores', A.allow('faculty', 'admin'), wrap((req, res) => {
    const c = courseFor(req, res, req.params.id); if (!c) return;
    if (c.grades_locked && req.user.role !== 'admin') return bad(res, 'الدرجات مقفلة من قبل الإدارة ولا يمكن تعديلها', 403);
    const items = new Map(db.all('SELECT * FROM assessment_items WHERE course_id = ?', c.id).map((i) => [i.id, i]));
    const valid = new Set(L.courseStudents(c.id).map((s) => s.id));
    const changes = req.body.scores || [];
    const touched = new Set();
    let n = 0;
    db.tx(() => {
      for (const ch of changes) {
        const it = items.get(Number(ch.item_id));
        if (!it || !valid.has(Number(ch.student_id))) continue;
        const v = ch.score === '' || ch.score === null || ch.score === undefined ? null : Number(ch.score);
        if (v !== null && (Number.isNaN(v) || v < 0 || v > it.max_score)) throw Object.assign(new Error(`الدرجة ${ch.score} خارج الحد المسموح (0 - ${it.max_score}) في "${it.title}"`), { status: 400 });
        const old = db.get('SELECT score FROM scores WHERE item_id = ? AND student_id = ?', it.id, ch.student_id);
        db.run(`INSERT INTO scores (item_id, student_id, score, updated_by, updated_at) VALUES (?,?,?,?, datetime('now','localtime'))
                ON CONFLICT(item_id, student_id) DO UPDATE SET score = excluded.score, updated_by = excluded.updated_by, updated_at = excluded.updated_at`,
          it.id, ch.student_id, v, req.user.id);
        if (!old || old.score !== v) {
          n++; touched.add(Number(ch.student_id));
          if (old) A.audit(req, 'تعديل درجة', `${c.name} / ${it.title} / طالب #${ch.student_id}: ${old.score ?? '-'} ← ${v ?? '-'}`);
        }
      }
    });
    if (n) A.audit(req, 'رصد درجات', `${c.name}: ${n} تغيير`);
    for (const sid of touched) emitToUser(sid, 'sync', { type: 'grades', course_id: c.id });
    emitSync('grades-staff', { course_id: c.id });
    res.json({ ok: true, changed: n });
  }));

  // ---------- تصدير CSV ----------
  const csv = (rows) => '\uFEFF' + rows.map((r) => r.map((v) => `"${String(v ?? '').replace(/"/g, '""')}"`).join(',')).join('\r\n');
  r.get('/courses/:id/export/:kind', A.allow('faculty', 'admin'), wrap((req, res) => {
    const c = courseFor(req, res, req.params.id); if (!c) return;
    const items = db.all('SELECT * FROM assessment_items WHERE course_id = ? ORDER BY sort, id', c.id);
    const students = L.courseStudents(c.id);
    let rows;
    if (req.params.kind === 'grades') {
      rows = [['الرقم الجامعي', 'الاسم', ...items.map((i) => `${i.title} (${i.max_score})`), 'التقييم المستمر', 'الامتحان', 'المجموع', 'التقدير']];
      for (const s of students) {
        const g = L.computeGrade(c, s.id, items);
        rows.push([s.username, s.full_name, ...g.breakdown.map((b) => b.score ?? ''), g.formative, g.exam, g.total ?? '', g.letter ? `${g.letter} - ${g.letter_ar}` : '']);
      }
    } else {
      const lectures = db.all('SELECT * FROM lectures WHERE course_id = ? ORDER BY lecture_date, id', c.id);
      const map = {};
      for (const a of db.all('SELECT a.* FROM attendance a JOIN lectures l ON l.id = a.lecture_id WHERE l.course_id = ?', c.id)) map[`${a.lecture_id}:${a.student_id}`] = a.status;
      const lbl = { present: 'ح', absent: 'غ', excused: 'م' };
      rows = [['الرقم الجامعي', 'الاسم', ...lectures.map((l) => l.lecture_date), 'ساعات الغياب', 'النسبة %', 'الحالة']];
      for (const s of students) {
        const a = L.computeAttendance(c, s.id);
        rows.push([s.username, s.full_name, ...lectures.map((l) => lbl[map[`${l.id}:${s.id}`]] || ''), a.absent_hours, a.absence_pct,
          a.status === 'banned' ? 'محروم' : a.status === 'warning' ? 'إنذار' : 'سليم']);
      }
    }
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename*=UTF-8''${encodeURIComponent(`${c.name}-${req.params.kind === 'grades' ? 'الدرجات' : 'الحضور'}.csv`)}`);
    res.send(csv(rows));
  }));

  // ===================== الشات =====================
  r.get('/chat/rooms', wrap((req, res) => {
    const s = getSettings();
    if (s.batch_chat_enabled !== '1' && req.user.role !== 'admin') return res.json([]);
    const rooms = L.allowedBatchRooms(req.user).map((room) => {
      const last = db.get('SELECT m.content, m.created_at, u.full_name FROM messages m LEFT JOIN users u ON u.id = m.sender_id WHERE m.room = ? AND m.deleted = 0 ORDER BY m.id DESC LIMIT 1', room);
      const p = L.parseRoom(room);
      const members = db.get("SELECT COUNT(*) n FROM users WHERE role='student' AND active=1 AND department_id=? AND stage=? AND study_type=?", p.dept, p.stage, p.study).n;
      return { room, label: L.roomLabel(room), last, members };
    });
    res.json(req.user.role === 'admin' ? rooms.filter((x) => x.members > 0 || x.last) : rooms);
  }));
  function canRoom(user, room) {
    const p = L.parseRoom(room);
    if (!p) return false;
    if (p.type === 'dm') return user.role === 'admin' || user.role === 'secretary' || (user.role === 'student' && user.id === p.student);
    return L.allowedBatchRooms(user).includes(room);
  }
  r.get('/chat/messages', wrap((req, res) => {
    const room = String(req.query.room || '');
    if (!canRoom(req.user, room)) return bad(res, 'لا تملك صلاحية دخول هذه المحادثة', 403);
    const rows = db.all(`SELECT m.id, m.room, m.sender_id, m.content, m.created_at, m.seen, u.full_name AS sender_name, u.role AS sender_role
                           FROM messages m LEFT JOIN users u ON u.id = m.sender_id WHERE m.room = ? AND m.deleted = 0 ORDER BY m.id DESC LIMIT 300`, room).reverse();
    const p = L.parseRoom(room);
    if (p.type === 'dm') {
      if (req.user.role === 'student') db.run("UPDATE messages SET seen = 1 WHERE room = ? AND sender_id IN (SELECT id FROM users WHERE role <> 'student')", room);
      else db.run("UPDATE messages SET seen = 1 WHERE room = ? AND sender_id IN (SELECT id FROM users WHERE role = 'student')", room);
    }
    res.json({ room, label: L.roomLabel(room), messages: rows });
  }));
  r.delete('/chat/messages/:id', wrap((req, res) => {
    const m = db.get('SELECT * FROM messages WHERE id = ?', req.params.id);
    if (!m) return bad(res, 'غير موجودة', 404);
    if (req.user.role !== 'admin' && m.sender_id !== req.user.id) return bad(res, 'لا يمكنك حذف رسالة غيرك', 403);
    db.run('UPDATE messages SET deleted = 1 WHERE id = ?', m.id);
    if (req.user.role === 'admin' && m.sender_id !== req.user.id) A.audit(req, 'حذف رسالة', `${L.roomLabel(m.room)}: ${m.content.slice(0, 60)}`);
    io.to(m.room).emit('chat:deleted', { id: m.id, room: m.room });
    res.json({ ok: true });
  }));
  r.post('/chat/clear', A.allow('admin'), wrap((req, res) => {
    db.run('UPDATE messages SET deleted = 1 WHERE room = ?', req.body.room);
    A.audit(req, 'مسح محادثة', L.roomLabel(req.body.room));
    io.to(req.body.room).emit('chat:cleared', { room: req.body.room });
    res.json({ ok: true });
  }));

  // السكرتارية: قائمة المحادثات
  r.get('/dm/threads', A.allow('admin', 'secretary'), wrap((req, res) => {
    res.json(db.all(`SELECT CAST(substr(m.room, 4) AS INTEGER) AS student_id, MAX(m.id) AS last_id,
                       SUM(CASE WHEN u.role='student' AND m.seen=0 THEN 1 ELSE 0 END) AS unread
                       FROM messages m JOIN users u ON u.id = m.sender_id WHERE m.room LIKE 'dm:%' AND m.deleted = 0 GROUP BY m.room ORDER BY last_id DESC`).map((t) => {
      const st = db.get('SELECT u.full_name, u.username, u.stage, d.name AS department_name FROM users u LEFT JOIN departments d ON d.id=u.department_id WHERE u.id = ?', t.student_id) || {};
      const last = db.get('SELECT content, created_at FROM messages WHERE id = ?', t.last_id);
      return { ...t, ...st, last };
    }));
  }));

  // ===================== المساعد الذكي =====================
  r.post('/bot', wrap(async (req, res) => {
    const msg = String(req.body.message || '').slice(0, 2000);
    const history = Array.isArray(req.body.history) ? req.body.history.filter((h) => h && ['user', 'assistant'].includes(h.role)).map((h) => ({ role: h.role, content: String(h.content).slice(0, 2000) })) : [];
    res.json(await bot.answer(req.user, msg, history));
  }));

  // =====================================================================
  //                    الإدارة (رئيس القسم) - صلاحيات شاملة
  // =====================================================================
  const adm = A.allow('admin');
  const staff = A.allow('admin', 'secretary');

  // ---------- المستخدمون ----------
  r.get('/admin/users', staff, wrap((req, res) => {
    const { role, department_id, stage, q, study_type, active } = req.query;
    let sql = `SELECT ${A.PUBLIC_USER_FIELDS}, d.name AS department_name FROM users u LEFT JOIN departments d ON d.id = u.department_id WHERE 1=1`;
    const p = [];
    if (role) { sql += ' AND u.role = ?'; p.push(role); }
    if (department_id) { sql += ' AND u.department_id = ?'; p.push(department_id); }
    if (stage) { sql += ' AND u.stage = ?'; p.push(stage); }
    if (study_type) { sql += ' AND u.study_type = ?'; p.push(study_type); }
    if (active === '0' || active === '1') { sql += ' AND u.active = ?'; p.push(active); }
    if (q) { sql += ' AND (u.full_name LIKE ? OR u.username LIKE ?)'; p.push(`%${q}%`, `%${q}%`); }
    sql += " ORDER BY CASE u.role WHEN 'admin' THEN 0 WHEN 'secretary' THEN 1 WHEN 'faculty' THEN 2 ELSE 3 END, d.sort, u.stage, u.full_name";
    res.json(db.all(sql, ...p));
  }));
  const userFields = (b) => [b.full_name, b.role, int(b.department_id), b.role === 'student' ? int(b.stage) : null,
    b.study_type || 'morning', b.batch || null, b.section || null, b.academic_title || null, b.email || null, b.phone || null,
    b.bio || null, b.office_hours || null, b.active === undefined ? 1 : (b.active ? 1 : 0)];
  function validateUser(b) {
    if (!b.full_name || !String(b.full_name).trim()) return 'الاسم الكامل مطلوب';
    if (!['admin', 'secretary', 'faculty', 'student'].includes(b.role)) return 'الدور غير صحيح';
    if (b.role === 'student' && (!b.department_id || !b.stage)) return 'القسم والمرحلة مطلوبان للطالب';
    return null;
  }
  r.post('/admin/users', adm, wrap((req, res) => {
    const b = req.body;
    const err = validateUser(b); if (err) return bad(res, err);
    const username = String(b.username || '').trim();
    if (!/^[A-Za-z0-9_.\-]{3,40}$/.test(username)) return bad(res, 'اسم المستخدم يجب أن يكون 3 أحرف أو أكثر (أحرف إنجليزية/أرقام)');
    if (db.get('SELECT id FROM users WHERE username = ?', username)) return bad(res, 'اسم المستخدم مستخدم مسبقاً');
    const password = b.password || A.generatePassword();
    const { lastId } = db.run(`INSERT INTO users (full_name, role, department_id, stage, study_type, batch, section, academic_title, email, phone, bio, office_hours, active, username, password_hash, must_change_password)
                               VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`, ...userFields(b), username, A.hash(password), b.must_change_password ? 1 : 0);
    A.audit(req, 'إنشاء حساب', `${username} (${b.role})`);
    emitSync('users');
    res.json({ id: lastId, username, password });
  }));
  r.put('/admin/users/:id', adm, wrap((req, res) => {
    const u = db.get('SELECT * FROM users WHERE id = ?', req.params.id);
    if (!u) return bad(res, 'المستخدم غير موجود', 404);
    const b = { ...u, ...req.body };
    const err = validateUser(b); if (err) return bad(res, err);
    if (u.role === 'admin' && b.role !== 'admin' && db.get("SELECT COUNT(*) n FROM users WHERE role='admin' AND active=1").n <= 1) return bad(res, 'لا يمكن إزالة صلاحية آخر حساب إدارة');
    if (u.id === req.user.id && !b.active) return bad(res, 'لا يمكنك تعطيل حسابك الحالي');
    const username = String(b.username || u.username).trim();
    if (username !== u.username) {
      if (!/^[A-Za-z0-9_.\-]{3,40}$/.test(username)) return bad(res, 'اسم المستخدم غير صالح');
      if (db.get('SELECT id FROM users WHERE username = ? AND id <> ?', username, u.id)) return bad(res, 'اسم المستخدم مستخدم مسبقاً');
    }
    db.run(`UPDATE users SET full_name=?, role=?, department_id=?, stage=?, study_type=?, batch=?, section=?, academic_title=?, email=?, phone=?, bio=?, office_hours=?, active=?, username=? WHERE id=?`,
      ...userFields(b), username, u.id);
    if (req.body.password) db.run('UPDATE users SET password_hash = ? WHERE id = ?', A.hash(req.body.password), u.id);
    if (!b.active) db.run('DELETE FROM sessions WHERE user_id = ?', u.id);
    A.audit(req, 'تعديل حساب', username);
    emitSync('users');
    res.json({ ok: true });
  }));
  r.delete('/admin/users/:id', adm, wrap((req, res) => {
    const u = db.get('SELECT * FROM users WHERE id = ?', req.params.id);
    if (!u) return bad(res, 'المستخدم غير موجود', 404);
    if (u.id === req.user.id) return bad(res, 'لا يمكنك حذف حسابك الحالي');
    if (u.role === 'admin' && db.get("SELECT COUNT(*) n FROM users WHERE role='admin'").n <= 1) return bad(res, 'لا يمكن حذف آخر حساب إدارة');
    db.run('DELETE FROM users WHERE id = ?', u.id);
    A.audit(req, 'حذف حساب', `${u.username} - ${u.full_name}`);
    emitSync('users');
    res.json({ ok: true });
  }));
  r.post('/admin/users/:id/reset-password', adm, wrap((req, res) => {
    const u = db.get('SELECT * FROM users WHERE id = ?', req.params.id);
    if (!u) return bad(res, 'المستخدم غير موجود', 404);
    const password = req.body.password || A.generatePassword();
    db.run('UPDATE users SET password_hash = ?, must_change_password = ? WHERE id = ?', A.hash(password), req.body.force_change ? 1 : 0, u.id);
    db.run('DELETE FROM sessions WHERE user_id = ?', u.id);
    A.audit(req, 'إعادة تعيين كلمة مرور', u.username);
    res.json({ username: u.username, password });
  }));
  // إنشاء جماعي: كل سطر = اسم كامل، [اسم مستخدم]، [كلمة مرور]
  r.post('/admin/users/bulk', adm, wrap((req, res) => {
    const { rows = [], role = 'student', department_id, stage, study_type, batch, prefix } = req.body;
    if (role === 'student' && (!department_id || !stage)) return bad(res, 'حدد القسم والمرحلة');
    const created = [], skipped = [];
    const dept = db.get('SELECT code FROM departments WHERE id = ?', department_id);
    let seq = db.get("SELECT COUNT(*) n FROM users WHERE role = ?", role).n + 1;
    db.tx(() => {
      for (const row of rows) {
        const full_name = String(row.full_name || '').trim();
        if (!full_name) continue;
        let username = String(row.username || '').trim();
        if (!username) {
          do { username = `${prefix || (role === 'student' ? `${(dept?.code || 'st').toLowerCase()}${stage || ''}` : 'staff')}${String(seq++).padStart(3, '0')}`; }
          while (db.get('SELECT id FROM users WHERE username = ?', username));
        }
        if (db.get('SELECT id FROM users WHERE username = ?', username)) { skipped.push({ full_name, username, reason: 'اسم المستخدم موجود' }); continue; }
        const password = row.password || A.generatePassword();
        db.run(`INSERT INTO users (username, password_hash, role, full_name, department_id, stage, study_type, batch, must_change_password) VALUES (?,?,?,?,?,?,?,?,0)`,
          username, A.hash(password), role, full_name, int(department_id), role === 'student' ? int(stage) : null, study_type || 'morning', batch || null);
        created.push({ full_name, username, password });
      }
    });
    A.audit(req, 'إنشاء حسابات جماعي', `${created.length} حساب`);
    emitSync('users');
    res.json({ created, skipped });
  }));
  r.post('/admin/users/bulk-action', adm, wrap((req, res) => {
    const ids = (req.body.ids || []).map(Number).filter((id) => id && id !== req.user.id);
    const action = req.body.action;
    let n = 0;
    db.tx(() => {
      for (const id of ids) {
        const u = db.get('SELECT * FROM users WHERE id = ?', id);
        if (!u || u.role === 'admin') continue;
        if (action === 'activate') n += db.run('UPDATE users SET active = 1 WHERE id = ?', id).changes;
        else if (action === 'deactivate') { n += db.run('UPDATE users SET active = 0 WHERE id = ?', id).changes; db.run('DELETE FROM sessions WHERE user_id = ?', id); }
        else if (action === 'delete') n += db.run('DELETE FROM users WHERE id = ?', id).changes;
        else if (action === 'promote' && u.role === 'student') n += db.run('UPDATE users SET stage = stage + 1 WHERE id = ? AND stage < ?', id, Number(getSettings().stages_count)).changes;
        else if (action === 'demote' && u.role === 'student') n += db.run('UPDATE users SET stage = stage - 1 WHERE id = ? AND stage > 1', id).changes;
        else if (action === 'move' && req.body.department_id) n += db.run('UPDATE users SET department_id = ? WHERE id = ?', int(req.body.department_id), id).changes;
      }
    });
    A.audit(req, 'إجراء جماعي على الحسابات', `${action}: ${n}`);
    emitSync('users');
    res.json({ changed: n });
  }));
  r.post('/admin/impersonate/:id', adm, wrap((req, res) => {
    const u = db.get('SELECT * FROM users WHERE id = ?', req.params.id);
    if (!u || !u.active) return bad(res, 'الحساب غير متاح');
    const token = A.createSession(u.id, req, req.user.id);
    A.audit(req, 'الدخول بحساب مستخدم', `${u.username} - ${u.full_name}`);
    res.json({ token });
  }));

  // ---------- الجلسات والأجهزة المتصلة ----------
  r.get('/admin/sessions', adm, wrap((req, res) => {
    res.json(db.all(`SELECT s.token, s.ip, s.user_agent, s.created_at, s.impersonated_by, u.full_name, u.username, u.role
                       FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.expires_at > ? ORDER BY s.created_at DESC`, Date.now())
      .map((s) => ({ ...s, id: s.token.slice(0, 12), current: s.token === req.user.token, token: undefined })));
  }));
  r.delete('/admin/sessions/:id', adm, wrap((req, res) => {
    const n = db.run('DELETE FROM sessions WHERE substr(token, 1, 12) = ? AND token <> ?', req.params.id, req.user.token).changes;
    A.audit(req, 'إنهاء جلسة جهاز', req.params.id);
    res.json({ changed: n });
  }));

  // ---------- الأقسام ----------
  r.get('/departments', wrap((req, res) => res.json(db.all('SELECT * FROM departments ORDER BY sort, id'))));
  r.post('/admin/departments', adm, wrap((req, res) => {
    const b = req.body;
    if (!b.name) return bad(res, 'اسم القسم مطلوب');
    const { lastId } = db.run('INSERT INTO departments (name, name_en, code, description, established, head_name, active, sort) VALUES (?,?,?,?,?,?,?,?)',
      b.name, b.name_en || null, b.code || null, b.description || null, b.established || null, b.head_name || null, b.active === false ? 0 : 1, int(b.sort) || 0);
    A.audit(req, 'إضافة قسم', b.name);
    res.json({ id: lastId });
  }));
  r.put('/admin/departments/:id', adm, wrap((req, res) => {
    const d = db.get('SELECT * FROM departments WHERE id = ?', req.params.id);
    if (!d) return bad(res, 'غير موجود', 404);
    const b = { ...d, ...req.body };
    db.run('UPDATE departments SET name=?, name_en=?, code=?, description=?, established=?, head_name=?, active=?, sort=? WHERE id=?',
      b.name, b.name_en, b.code, b.description, b.established, b.head_name, b.active ? 1 : 0, int(b.sort) || 0, d.id);
    A.audit(req, 'تعديل قسم', b.name);
    res.json({ ok: true });
  }));
  r.delete('/admin/departments/:id', adm, wrap((req, res) => {
    const d = db.get('SELECT * FROM departments WHERE id = ?', req.params.id);
    if (!d) return bad(res, 'غير موجود', 404);
    const users = db.get('SELECT COUNT(*) n FROM users WHERE department_id = ?', d.id).n;
    if (users && !req.query.force) return bad(res, `يوجد ${users} مستخدم مرتبط بهذا القسم. انقلهم أو عطّل القسم بدلاً من حذفه.`);
    db.run('DELETE FROM departments WHERE id = ?', d.id);
    A.audit(req, 'حذف قسم', d.name);
    res.json({ ok: true });
  }));

  // ---------- المواد ----------
  const courseFields = (b) => [b.name, b.name_en || null, b.code || null, int(b.department_id), int(b.stage), int(b.semester) || 1,
    b.study_type || 'both', Number(b.ects) || 5, int(b.total_hours) || 30, int(b.faculty_id), int(b.formative_weight) ?? 50,
    100 - (int(b.formative_weight) ?? 50), b.description || null, b.active === undefined ? 1 : (b.active ? 1 : 0),
    b.grades_published === undefined ? 1 : (b.grades_published ? 1 : 0)];
  r.post('/admin/courses', adm, wrap((req, res) => {
    const b = req.body;
    if (!b.name || !b.department_id || !b.stage) return bad(res, 'اسم المادة والقسم والمرحلة مطلوبة');
    const fw = int(b.formative_weight) ?? Number(getSettings().default_formative_weight);
    b.formative_weight = fw;
    if (fw < 0 || fw > 100) return bad(res, 'وزن التقييم المستمر بين 0 و100');
    const id = db.tx(() => {
      const { lastId } = db.run(`INSERT INTO courses (name, name_en, code, department_id, stage, semester, study_type, ects, total_hours, faculty_id, formative_weight, exam_weight, description, active, grades_published)
                                 VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`, ...courseFields(b));
      L.defaultAssessmentItems(lastId, fw);
      return lastId;
    });
    A.audit(req, 'إضافة مادة', b.name);
    emitSync('courses');
    res.json({ id });
  }));
  r.put('/admin/courses/:id', adm, wrap((req, res) => {
    const c = db.get('SELECT * FROM courses WHERE id = ?', req.params.id);
    if (!c) return bad(res, 'غير موجودة', 404);
    const b = { ...c, ...req.body };
    db.run(`UPDATE courses SET name=?, name_en=?, code=?, department_id=?, stage=?, semester=?, study_type=?, ects=?, total_hours=?, faculty_id=?, formative_weight=?, exam_weight=?, description=?, active=?, grades_published=? WHERE id=?`,
      ...courseFields(b), c.id);
    A.audit(req, 'تعديل مادة', b.name);
    emitSync('courses');
    res.json({ ok: true });
  }));
  r.post('/admin/courses/:id/lock', adm, wrap((req, res) => {
    db.run('UPDATE courses SET grades_locked = ? WHERE id = ?', req.body.locked ? 1 : 0, req.params.id);
    A.audit(req, req.body.locked ? 'قفل الدرجات' : 'فتح الدرجات', `مادة #${req.params.id}`);
    emitSync('courses');
    res.json({ ok: true });
  }));
  r.post('/admin/courses/lock-all', adm, wrap((req, res) => {
    const n = db.run('UPDATE courses SET grades_locked = ?', req.body.locked ? 1 : 0).changes;
    A.audit(req, req.body.locked ? 'قفل درجات جميع المواد' : 'فتح درجات جميع المواد', `${n}`);
    emitSync('courses');
    res.json({ changed: n });
  }));
  r.delete('/admin/courses/:id', adm, wrap((req, res) => {
    const c = db.get('SELECT * FROM courses WHERE id = ?', req.params.id);
    if (!c) return bad(res, 'غير موجودة', 404);
    for (const m of db.all('SELECT stored_name FROM materials WHERE course_id = ? AND stored_name IS NOT NULL', c.id)) fs.unlink(path.join(UPLOAD_DIR, m.stored_name), () => {});
    db.run('DELETE FROM courses WHERE id = ?', c.id);
    A.audit(req, 'حذف مادة', c.name);
    emitSync('courses');
    res.json({ ok: true });
  }));
  r.get('/admin/courses/:id/enrollments', adm, wrap((req, res) => {
    res.json(db.all(`SELECT e.id, e.kind, u.id AS student_id, u.full_name, u.username, u.stage, d.name AS department_name FROM enrollments e
                       JOIN users u ON u.id = e.student_id LEFT JOIN departments d ON d.id = u.department_id WHERE e.course_id = ?`, req.params.id));
  }));
  r.post('/admin/courses/:id/enrollments', adm, wrap((req, res) => {
    const st = db.get("SELECT * FROM users WHERE (id = ? OR username = ?) AND role = 'student'", int(req.body.student_id), String(req.body.username || ''));
    if (!st) return bad(res, 'الطالب غير موجود');
    db.run('INSERT OR IGNORE INTO enrollments (student_id, course_id, kind) VALUES (?,?,?)', st.id, req.params.id, req.body.kind || 'carry');
    A.audit(req, 'تسجيل طالب في مادة', `${st.full_name} → مادة #${req.params.id}`);
    res.json({ ok: true });
  }));
  r.delete('/admin/enrollments/:id', adm, wrap((req, res) => {
    db.run('DELETE FROM enrollments WHERE id = ?', req.params.id);
    res.json({ ok: true });
  }));

  // ---------- متابعة الحضور ----------
  r.get('/admin/attendance', staff, wrap((req, res) => {
    const department_id = int(req.query.department_id), stage = int(req.query.stage);
    let sql = `SELECT c.*, d.name AS department_name, f.full_name AS faculty_name FROM courses c LEFT JOIN departments d ON d.id=c.department_id
               LEFT JOIN users f ON f.id=c.faculty_id WHERE c.active = 1`;
    const p = [];
    if (department_id) { sql += ' AND c.department_id = ?'; p.push(department_id); }
    if (stage) { sql += ' AND c.stage = ?'; p.push(stage); }
    const courses = db.all(sql + ' ORDER BY d.sort, c.stage, c.name', ...p).map((c) => {
      const students = L.courseStudents(c.id);
      const stats = students.map((s) => L.computeAttendance(c, s.id));
      const lectures = db.get('SELECT COUNT(*) n, COALESCE(SUM(hours),0) h FROM lectures WHERE course_id = ?', c.id);
      const avg = stats.length ? stats.reduce((a, x) => a + x.absence_pct, 0) / stats.length : 0;
      return { id: c.id, name: c.name, department_name: c.department_name, stage: c.stage, faculty_name: c.faculty_name,
        students: students.length, lectures: lectures.n, hours_done: lectures.h, total_hours: c.total_hours,
        avg_absence: Math.round(avg * 10) / 10, warnings: stats.filter((x) => x.status === 'warning').length, banned: stats.filter((x) => x.status === 'banned').length };
    });
    res.json({ courses, at_risk: atRisk({ department_id, stage }) });
  }));

  // ---------- الإعدادات ----------
  r.get('/admin/settings', adm, wrap((req, res) => res.json(getSettings())));
  r.put('/admin/settings', adm, wrap((req, res) => {
    const allowed = Object.keys(DEFAULT_SETTINGS);
    const changed = [];
    for (const [k, v] of Object.entries(req.body || {})) {
      if (!allowed.includes(k)) continue;
      if (k === 'grade_scale') { try { JSON.parse(v); } catch { return bad(res, 'سلم التقديرات غير صالح'); } }
      setSetting(k, v); changed.push(k);
    }
    A.audit(req, 'تعديل إعدادات النظام', changed.join('، '));
    emitSync('settings');
    res.json({ ok: true });
  }));
  r.post('/admin/branding/:which', adm, upload.single('file'), wrap((req, res) => {
    const which = req.params.which === 'university' ? 'university' : 'college';
    if (!req.file || !/^image\//.test(req.file.mimetype)) { if (req.file) fs.unlink(req.file.path, () => {}); return bad(res, 'اختر صورة صالحة'); }
    const name = `${which}-logo-${Date.now()}${path.extname(req.file.originalname).toLowerCase()}`;
    fs.renameSync(req.file.path, path.join(BRAND_DIR, name));
    setSetting(`${which}_logo`, `api/branding/${name}`);
    A.audit(req, 'تغيير الشعار', which);
    emitSync('settings');
    res.json({ ok: true });
  }));
  r.post('/admin/branding/:which/reset', adm, wrap((req, res) => {
    db.run('DELETE FROM settings WHERE key = ?', `${req.params.which === 'university' ? 'university' : 'college'}_logo`);
    emitSync('settings');
    res.json({ ok: true });
  }));

  // ---------- الأسئلة الشائعة للمساعد ----------
  r.get('/admin/faq', adm, wrap((req, res) => res.json(db.all('SELECT * FROM faq ORDER BY id'))));
  r.post('/admin/faq', adm, wrap((req, res) => {
    if (!req.body.question || !req.body.answer) return bad(res, 'السؤال والجواب مطلوبان');
    db.run('INSERT INTO faq (question, answer, keywords) VALUES (?,?,?)', req.body.question, req.body.answer, req.body.keywords || '');
    A.audit(req, 'إضافة سؤال للمساعد', req.body.question);
    res.json({ ok: true });
  }));
  r.put('/admin/faq/:id', adm, wrap((req, res) => {
    db.run('UPDATE faq SET question=?, answer=?, keywords=? WHERE id=?', req.body.question, req.body.answer, req.body.keywords || '', req.params.id);
    res.json({ ok: true });
  }));
  r.delete('/admin/faq/:id', adm, wrap((req, res) => { db.run('DELETE FROM faq WHERE id = ?', req.params.id); res.json({ ok: true }); }));

  // ---------- سجل العمليات ----------
  r.get('/admin/audit', adm, wrap((req, res) => {
    const q = req.query.q ? `%${req.query.q}%` : null;
    res.json(q
      ? db.all('SELECT * FROM audit_log WHERE action LIKE ? OR details LIKE ? OR user_name LIKE ? ORDER BY id DESC LIMIT 500', q, q, q)
      : db.all('SELECT * FROM audit_log ORDER BY id DESC LIMIT 500'));
  }));
  r.delete('/admin/audit', adm, wrap((req, res) => {
    db.run("DELETE FROM audit_log WHERE created_at < datetime('now','localtime', ?)", `-${int(req.query.days) || 90} days`);
    A.audit(req, 'تنظيف سجل العمليات', `أقدم من ${int(req.query.days) || 90} يوم`);
    res.json({ ok: true });
  }));

  // ---------- النسخ الاحتياطي والاستعادة ----------
  r.get('/admin/backup', adm, wrap((req, res) => {
    const name = `backup-${new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-')}.db`;
    const file = path.join(DATA_DIR, name);
    db.backupTo(file);
    A.audit(req, 'تنزيل نسخة احتياطية', name);
    res.download(file, name, () => fs.unlink(file, () => {}));
  }));
  r.post('/admin/restore', adm, upload.single('file'), wrap((req, res) => {
    if (!req.file) return bad(res, 'اختر ملف النسخة الاحتياطية (.db)');
    const head = Buffer.alloc(16);
    const fd = fs.openSync(req.file.path, 'r'); fs.readSync(fd, head, 0, 16, 0); fs.closeSync(fd);
    if (!head.toString('latin1').startsWith('SQLite format 3')) { fs.unlink(req.file.path, () => {}); return bad(res, 'الملف ليس نسخة احتياطية صالحة'); }
    const safety = path.join(DATA_DIR, `before-restore-${Date.now()}.db`);
    db.backupTo(safety);
    db.restoreFrom(req.file.path);
    fs.unlink(req.file.path, () => {});
    res.json({ ok: true, safety_copy: path.basename(safety) });
    emitSync('restored');
  }));

  // ---------- بيانات تجريبية / تصفير ----------
  r.post('/admin/demo-data', adm, wrap((req, res) => {
    const out = require('../scripts/demo-data').seed();
    A.audit(req, 'تحميل بيانات تجريبية', JSON.stringify(out));
    emitSync('restored');
    res.json(out);
  }));
  r.post('/admin/reset-system', adm, wrap((req, res) => {
    if (req.body.confirm !== 'تصفير') return bad(res, 'اكتب كلمة "تصفير" للتأكيد');
    db.tx(() => {
      for (const t of ['messages', 'announcement_reads', 'announcements', 'scores', 'assessment_items', 'attendance', 'lectures', 'materials', 'enrollments', 'courses']) db.run(`DELETE FROM ${t}`);
      db.run("DELETE FROM users WHERE role <> 'admin'");
    });
    for (const f of fs.readdirSync(UPLOAD_DIR)) if (f !== 'branding' && f !== '.gitkeep') fs.unlink(path.join(UPLOAD_DIR, f), () => {});
    A.audit(req, 'تصفير النظام', 'حذف جميع البيانات عدا حسابات الإدارة');
    emitSync('restored');
    res.json({ ok: true });
  }));

  // ---------- معلومات الشبكة المحلية (LAN) ----------
  r.get('/admin/network', staff, wrap(async (req, res) => {
    const port = req.app.get('port');
    const ips = [];
    for (const [name, list] of Object.entries(os.networkInterfaces())) {
      for (const n of list || []) if (n.family === 'IPv4' && !n.internal) ips.push({ name, address: n.address, url: `http://${n.address}:${port}` });
    }
    for (const ip of ips) ip.qr = await QRCode.toDataURL(ip.url, { margin: 1, width: 220, color: { dark: '#0F1A36', light: '#FFFFFF' } });
    res.json({ port, hostname: os.hostname(), ips, online: io ? io.engine.clientsCount : 0, db_engine: db.kind, node: process.version });
  }));

  // معالج الأخطاء
  r.use((err, req, res, next) => {
    if (err.code === 'LIMIT_FILE_SIZE') return bad(res, 'حجم الملف كبير جداً');
    if (err.status === 400) return bad(res, err.message);
    if (String(err.message).includes('UNIQUE')) return bad(res, 'هذا السجل موجود مسبقاً');
    console.error('[API]', err);
    res.status(500).json({ error: 'حدث خطأ في السيرفر: ' + err.message });
  });

  return r;
};
