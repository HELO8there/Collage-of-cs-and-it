// =====================================================================
// منطق نظام بولونيا: الطلبة المسجلون، احتساب الدرجات والتقديرات، الغياب
// =====================================================================
const { db, getSettings } = require('./db');

const STUDY_TYPES = { morning: 'صباحي', evening: 'مسائي' };

function gradeScale() {
  try { return JSON.parse(getSettings().grade_scale); } catch { return []; }
}

function letterFor(total, scale = gradeScale()) {
  if (total === null || total === undefined || Number.isNaN(total)) return null;
  const sorted = [...scale].sort((a, b) => b.min - a.min);
  return sorted.find((g) => total >= g.min) || sorted[sorted.length - 1] || null;
}

// طلبة المادة = طلبة القسم والمرحلة (وحسب نوع الدراسة) + المسجلون إضافياً (المحمّلون)
function courseStudents(courseId) {
  const c = db.get('SELECT * FROM courses WHERE id = ?', courseId);
  if (!c) return [];
  const typeFilter = c.study_type === 'both' ? '' : ' AND u.study_type = ? ';
  const params = [c.department_id, c.stage];
  if (c.study_type !== 'both') params.push(c.study_type);
  params.push(courseId);
  return db.all(`
    SELECT u.id, u.username, u.full_name, u.stage, u.study_type, u.batch, u.section, 0 AS carried
      FROM users u
     WHERE u.role = 'student' AND u.active = 1 AND u.department_id = ? AND u.stage = ? ${typeFilter}
    UNION
    SELECT u.id, u.username, u.full_name, u.stage, u.study_type, u.batch, u.section, 1 AS carried
      FROM enrollments e JOIN users u ON u.id = e.student_id
     WHERE e.course_id = ? AND u.active = 1
     ORDER BY full_name`, ...params);
}

function studentCourses(student) {
  return db.all(`
    SELECT c.*, f.full_name AS faculty_name, f.academic_title AS faculty_title, d.name AS department_name, 0 AS carried
      FROM courses c
      LEFT JOIN users f ON f.id = c.faculty_id
      LEFT JOIN departments d ON d.id = c.department_id
     WHERE c.active = 1 AND c.department_id = ? AND c.stage = ?
       AND (c.study_type = 'both' OR c.study_type = ?)
    UNION
    SELECT c.*, f.full_name AS faculty_name, f.academic_title AS faculty_title, d.name AS department_name, 1 AS carried
      FROM enrollments e JOIN courses c ON c.id = e.course_id
      LEFT JOIN users f ON f.id = c.faculty_id
      LEFT JOIN departments d ON d.id = c.department_id
     WHERE e.student_id = ? AND c.active = 1
     ORDER BY semester, name`, student.department_id, student.stage, student.study_type || 'morning', student.id);
}

function isStudentInCourse(studentId, courseId) {
  return courseStudents(courseId).some((s) => s.id === Number(studentId));
}

// احتساب الدرجة النهائية لطالب في مادة
function computeGrade(course, studentId, items, scoreMap) {
  items = items || db.all('SELECT * FROM assessment_items WHERE course_id = ? ORDER BY sort, id', course.id);
  if (!scoreMap) {
    scoreMap = {};
    for (const s of db.all(`SELECT s.item_id, s.score FROM scores s JOIN assessment_items i ON i.id = s.item_id
                            WHERE i.course_id = ? AND s.student_id = ?`, course.id, studentId)) scoreMap[s.item_id] = s.score;
  }
  const form = items.filter((i) => i.kind === 'formative');
  const fin = items.filter((i) => i.kind === 'final');
  const resit = items.filter((i) => i.kind === 'resit');
  const sumMax = (arr) => arr.reduce((a, i) => a + Number(i.max_score || 0), 0);
  const sumScore = (arr) => arr.reduce((a, i) => a + (scoreMap[i.id] != null ? Number(scoreMap[i.id]) : 0), 0);
  const hasAny = (arr) => arr.some((i) => scoreMap[i.id] != null && scoreMap[i.id] !== '');

  const fw = Number(course.formative_weight), ew = Number(course.exam_weight);
  const formMax = sumMax(form);
  const formative = formMax ? (sumScore(form) / formMax) * fw : 0;
  const finMax = sumMax(fin);
  let exam = finMax ? (sumScore(fin) / finMax) * ew : 0;
  let usedResit = false;
  const firstTotal = formative + exam;
  const pass = Number(getSettings().pass_mark || 50);
  if (hasAny(resit) && firstTotal < pass) {
    const rMax = sumMax(resit);
    const rExam = rMax ? (sumScore(resit) / rMax) * ew : 0;
    if (rExam > exam) { exam = rExam; usedResit = true; }
  }
  const started = hasAny(form) || hasAny(fin) || hasAny(resit);
  const total = Math.round(formative + exam); // تقريب: 54.5 تصبح 55
  const examDone = hasAny(fin) || hasAny(resit);
  const g = examDone ? letterFor(total) : null;
  return {
    formative: round1(formative), formative_max: fw,
    exam: round1(exam), exam_max: ew,
    total: started ? total : null,
    final: examDone,
    letter: g ? g.letter : null, letter_ar: g ? g.ar : null,
    passed: examDone ? total >= pass : null,
    used_resit: usedResit,
    breakdown: items.map((i) => ({ id: i.id, title: i.title, kind: i.kind, max: i.max_score, score: scoreMap[i.id] ?? null })),
  };
}
const round1 = (n) => Math.round(n * 10) / 10;

// احتساب الغياب لطالب في مادة
function computeAttendance(course, studentId) {
  const s = getSettings();
  const rows = db.all(`SELECT l.id, l.lecture_date, l.topic, l.hours, a.status, a.note
                         FROM lectures l LEFT JOIN attendance a ON a.lecture_id = l.id AND a.student_id = ?
                        WHERE l.course_id = ? ORDER BY l.lecture_date DESC, l.id DESC`, studentId, course.id);
  let absentHours = 0, excusedHours = 0, presentHours = 0, absentCount = 0, excusedCount = 0;
  for (const r of rows) {
    if (r.status === 'absent') { absentHours += r.hours; absentCount++; }
    else if (r.status === 'excused') { excusedHours += r.hours; excusedCount++; }
    else if (r.status === 'present') presentHours += r.hours;
  }
  const total = Math.max(Number(course.total_hours) || 0, 1);
  const pct = round1((absentHours / total) * 100);
  const warn = Number(s.absence_warning_pct), ban = Number(s.absence_ban_pct);
  return {
    lectures: rows.length, absent_count: absentCount, excused_count: excusedCount,
    absent_hours: absentHours, excused_hours: excusedHours, present_hours: presentHours,
    total_hours: course.total_hours, absence_pct: pct,
    status: pct >= ban ? 'banned' : pct >= warn ? 'warning' : 'ok',
    warn_pct: warn, ban_pct: ban,
    log: rows,
  };
}

function batchRoom(deptId, stage, studyType) {
  return `batch:${deptId}:${stage}:${studyType || 'morning'}`;
}

function parseRoom(room) {
  const m = /^batch:(\d+):(\d+):(morning|evening)$/.exec(room || '');
  if (m) return { type: 'batch', dept: Number(m[1]), stage: Number(m[2]), study: m[3] };
  const d = /^dm:(\d+)$/.exec(room || '');
  if (d) return { type: 'dm', student: Number(d[1]) };
  return null;
}

// الغرف المسموحة للمستخدم
function allowedBatchRooms(user) {
  const s = getSettings();
  if (user.role === 'student') return [batchRoom(user.department_id, user.stage, user.study_type)];
  if (user.role === 'admin') {
    const rooms = [];
    const n = Number(s.stages_count || 4);
    for (const d of db.all('SELECT id FROM departments WHERE active = 1')) {
      for (let st = 1; st <= n; st++) for (const t of ['morning', 'evening']) rooms.push(batchRoom(d.id, st, t));
    }
    return rooms;
  }
  if (user.role === 'faculty' && s.faculty_in_batch_chat === '1') {
    const rooms = new Set();
    for (const c of db.all('SELECT department_id, stage, study_type FROM courses WHERE faculty_id = ? AND active = 1', user.id)) {
      if (c.study_type === 'both' || c.study_type === 'morning') rooms.add(batchRoom(c.department_id, c.stage, 'morning'));
      if (c.study_type === 'both' || c.study_type === 'evening') rooms.add(batchRoom(c.department_id, c.stage, 'evening'));
    }
    return [...rooms];
  }
  return [];
}

function roomLabel(room) {
  const p = parseRoom(room);
  if (!p) return room;
  if (p.type === 'batch') {
    const d = db.get('SELECT name FROM departments WHERE id = ?', p.dept);
    return `${d ? d.name : 'قسم'} - المرحلة ${p.stage} - ${STUDY_TYPES[p.study]}`;
  }
  const u = db.get('SELECT full_name FROM users WHERE id = ?', p.student);
  return u ? u.full_name : 'طالب';
}

// التبليغات المرئية للمستخدم
function visibleAnnouncementsSQL(user) {
  if (user.role === 'admin' || user.role === 'secretary') return { where: '1=1', params: [] };
  const role = user.role;
  const where = `(a.target_role = 'all' OR a.target_role = ?)
     AND (a.target_department_id IS NULL OR a.target_department_id = ?)
     AND (a.target_stage IS NULL OR a.target_stage = ?)
     AND (a.target_study_type IS NULL OR a.target_study_type = '' OR a.target_study_type = ?)`;
  if (role === 'student') return { where, params: [role, user.department_id, user.stage, user.study_type] };
  // التدريسي يرى تبليغات التدريسيين والعامة + قسمه
  return {
    where: `(a.target_role = 'all' OR a.target_role = 'faculty') AND (a.target_department_id IS NULL OR a.target_department_id = ?) AND a.target_stage IS NULL`,
    params: [user.department_id],
  };
}

function defaultAssessmentItems(courseId, formativeWeight = 50) {
  const fw = Number(formativeWeight);
  const parts = [
    ['الاختبارات القصيرة (Quizzes)', 0.2],
    ['الواجبات والتقارير', 0.2],
    ['العملي / المختبر', 0.2],
    ['امتحان منتصف الفصل', 0.4],
  ];
  let sort = 1;
  for (const [title, ratio] of parts) {
    db.run("INSERT INTO assessment_items (course_id, title, kind, max_score, sort) VALUES (?,?, 'formative', ?, ?)", courseId, title, Math.round(fw * ratio), sort++);
  }
  db.run("INSERT INTO assessment_items (course_id, title, kind, max_score, sort) VALUES (?, 'الامتحان النهائي', 'final', ?, ?)", courseId, 100 - fw, sort++);
  db.run("INSERT INTO assessment_items (course_id, title, kind, max_score, sort) VALUES (?, 'امتحان الدور الثاني', 'resit', ?, ?)", courseId, 100 - fw, sort++);
}

module.exports = {
  STUDY_TYPES, gradeScale, letterFor, courseStudents, studentCourses, isStudentInCourse,
  computeGrade, computeAttendance, batchRoom, parseRoom, allowedBatchRooms, roomLabel,
  visibleAnnouncementsSQL, defaultAssessmentItems,
};
