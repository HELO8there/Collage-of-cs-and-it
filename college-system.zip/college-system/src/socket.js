// =====================================================================
// التزامن الفوري عبر الشبكة المحلية (Socket.io)
// كل مستخدم يدخل فقط الغرف المسموحة له - لا يوجد بث عام للرسائل الخاصة
// =====================================================================
const { db, getSettings } = require('./db');
const A = require('./auth');
const L = require('./logic');

module.exports = function attachSocket(io) {
  const online = new Map(); // userId -> count

  io.use((socket, next) => {
    const token = socket.handshake.auth?.token || A.tokenFrom({ headers: socket.handshake.headers, query: {} });
    const user = A.userByToken(token);
    if (!user) return next(new Error('unauthorized'));
    socket.user = user;
    next();
  });

  io.on('connection', (socket) => {
    const u = socket.user;
    socket.join(`user:${u.id}`);
    socket.join(`role:${u.role}`);
    if (u.role === 'admin' || u.role === 'secretary') socket.join('staff');
    if (u.role === 'student') socket.join(`dm:${u.id}`);
    for (const room of L.allowedBatchRooms(u)) socket.join(room);

    online.set(u.id, (online.get(u.id) || 0) + 1);
    io.to('staff').emit('presence', { online: online.size, devices: io.engine.clientsCount });

    socket.on('chat:send', (data, ack) => {
      try {
        const s = getSettings();
        const room = String(data?.room || '');
        const content = String(data?.content || '').trim().slice(0, 2000);
        if (!content) return ack && ack({ error: 'الرسالة فارغة' });
        const p = L.parseRoom(room);
        if (!p) return ack && ack({ error: 'محادثة غير صالحة' });
        if (p.type === 'batch') {
          if (s.batch_chat_enabled !== '1' && u.role !== 'admin') return ack && ack({ error: 'شات الدفعة متوقف حالياً' });
          if (!L.allowedBatchRooms(u).includes(room)) return ack && ack({ error: 'غير مسموح' });
        } else {
          if (s.secretary_chat_enabled !== '1' && u.role === 'student') return ack && ack({ error: 'مراسلة السكرتارية متوقفة حالياً' });
          const ok = u.role === 'admin' || u.role === 'secretary' || (u.role === 'student' && u.id === p.student);
          if (!ok) return ack && ack({ error: 'غير مسموح' });
        }
        // الهوية تؤخذ من الجلسة في السيرفر وليس من المتصفح (منع الانتحال)
        const { lastId } = db.run('INSERT INTO messages (room, sender_id, content) VALUES (?,?,?)', room, u.id, content);
        const msg = db.get(`SELECT m.id, m.room, m.sender_id, m.content, m.created_at, m.seen, x.full_name AS sender_name, x.role AS sender_role
                              FROM messages m LEFT JOIN users x ON x.id = m.sender_id WHERE m.id = ?`, lastId);
        if (p.type === 'batch') io.to(room).emit('chat:message', msg);
        else {
          io.to(`dm:${p.student}`).to('staff').emit('chat:message', msg);
          if (u.role === 'student') io.to('staff').emit('dm:new', { student_id: u.id, name: u.full_name, content });
        }
        ack && ack({ ok: true, message: msg });
      } catch (e) {
        ack && ack({ error: e.message });
      }
    });

    socket.on('chat:typing', (data) => {
      const room = String(data?.room || '');
      if (socket.rooms.has(room) || (L.parseRoom(room)?.type === 'dm' && (u.role !== 'student' || room === `dm:${u.id}`))) {
        socket.to(room).to(L.parseRoom(room)?.type === 'dm' ? 'staff' : room).emit('chat:typing', { room, name: u.full_name, id: u.id });
      }
    });

    socket.on('disconnect', () => {
      const c = (online.get(u.id) || 1) - 1;
      if (c <= 0) online.delete(u.id); else online.set(u.id, c);
      io.to('staff').emit('presence', { online: online.size, devices: io.engine.clientsCount });
    });
  });

  return { onlineCount: () => online.size };
};
