// =====================================================================
// المصادقة والجلسات والصلاحيات
// =====================================================================
const crypto = require('crypto');
const bcrypt = require('bcryptjs');
const { db, getSettings } = require('./db');

const COOKIE = 'csit_sid';

function parseCookies(header) {
  const out = {};
  (header || '').split(';').forEach((p) => {
    const i = p.indexOf('=');
    if (i > 0) out[p.slice(0, i).trim()] = decodeURIComponent(p.slice(i + 1).trim());
  });
  return out;
}

function tokenFrom(req) {
  const h = req.headers.authorization || '';
  if (h.startsWith('Bearer ')) return h.slice(7).trim();
  if (req.query && req.query.t) return String(req.query.t);
  return parseCookies(req.headers.cookie)[COOKIE] || null;
}

const PUBLIC_USER_FIELDS = `u.id, u.username, u.role, u.full_name, u.department_id, u.stage, u.study_type, u.batch, u.section,
  u.academic_title, u.email, u.phone, u.bio, u.office_hours, u.active, u.must_change_password, u.last_login, u.created_at`;

function userByToken(token) {
  if (!token) return null;
  const row = db.get(`SELECT s.token, s.expires_at, s.impersonated_by, ${PUBLIC_USER_FIELDS}, d.name AS department_name
                        FROM sessions s JOIN users u ON u.id = s.user_id
                        LEFT JOIN departments d ON d.id = u.department_id
                       WHERE s.token = ?`, token);
  if (!row) return null;
  if (row.expires_at < Date.now() || !row.active) {
    db.run('DELETE FROM sessions WHERE token = ?', token);
    return null;
  }
  return row;
}

function createSession(userId, req, impersonatedBy = null) {
  const token = crypto.randomBytes(32).toString('hex');
  const hours = Number(getSettings().session_hours || 12);
  db.run('INSERT INTO sessions (token, user_id, impersonated_by, ip, user_agent, expires_at) VALUES (?,?,?,?,?,?)',
    token, userId, impersonatedBy, clientIp(req), String(req.headers['user-agent'] || '').slice(0, 200), Date.now() + hours * 3600e3);
  return token;
}

function clientIp(req) {
  return String(req.headers['x-forwarded-for'] || req.socket?.remoteAddress || '').split(',')[0].replace('::ffff:', '').trim();
}

function setCookie(res, token) {
  const hours = Number(getSettings().session_hours || 12);
  res.setHeader('Set-Cookie', `${COOKIE}=${token}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${hours * 3600}`);
}
function clearCookie(res) {
  res.setHeader('Set-Cookie', `${COOKIE}=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0`);
}

function auth(req, res, next) {
  const user = userByToken(tokenFrom(req));
  if (!user) return res.status(401).json({ error: 'انتهت الجلسة، يرجى تسجيل الدخول مجدداً' });
  if (getSettings().maintenance_mode === '1' && user.role !== 'admin') {
    return res.status(403).json({ error: 'النظام في وضع الصيانة حالياً' });
  }
  req.user = user;
  next();
}

const allow = (...roles) => (req, res, next) =>
  roles.includes(req.user.role) ? next() : res.status(403).json({ error: 'ليست لديك صلاحية لهذا الإجراء' });

// حماية من محاولات التخمين: 5 محاولات خاطئة = إيقاف 5 دقائق
const attempts = new Map();
function loginBlocked(key) {
  const a = attempts.get(key);
  return a && a.count >= 5 && Date.now() - a.last < 5 * 60e3;
}
function loginFailed(key) {
  const a = attempts.get(key) || { count: 0, last: 0 };
  if (Date.now() - a.last > 5 * 60e3) a.count = 0;
  a.count++; a.last = Date.now();
  attempts.set(key, a);
}
function loginOk(key) { attempts.delete(key); }

function hash(pw) { return bcrypt.hashSync(String(pw), 10); }
function verify(pw, h) { return bcrypt.compareSync(String(pw || ''), h); }

function generatePassword(len = 8) {
  const chars = 'abcdefghjkmnpqrstuvwxyz23456789';
  let s = '';
  const bytes = crypto.randomBytes(len);
  for (let i = 0; i < len; i++) s += chars[bytes[i] % chars.length];
  return s;
}

function audit(req, action, details) {
  try {
    const u = req.user || {};
    db.run('INSERT INTO audit_log (user_id, user_name, action, details, ip) VALUES (?,?,?,?,?)',
      u.id || null, u.full_name || u.username || 'نظام', action,
      typeof details === 'string' ? details : JSON.stringify(details || ''), clientIp(req));
  } catch (_) {}
}

module.exports = {
  auth, allow, tokenFrom, userByToken, createSession, setCookie, clearCookie, clientIp,
  loginBlocked, loginFailed, loginOk, hash, verify, generatePassword, audit, PUBLIC_USER_FIELDS,
};
