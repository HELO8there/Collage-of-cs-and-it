// =====================================================================
// النظام الأكاديمي والإداري الموحد
// كلية علوم الحاسوب وتكنولوجيا المعلومات - جامعة كركوك
// تشغيل: node server.js   ثم افتح  http://localhost:3000
// =====================================================================
const path = require('path');
const os = require('os');
const http = require('http');
const express = require('express');
const { Server } = require('socket.io');
const { init } = require('./src/db');

const db = init();
const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: true, credentials: true }, maxHttpBufferSize: 1e6 });
const PORT = Number(process.env.PORT || 3000);
app.set('port', PORT);
app.disable('x-powered-by');

app.use(express.json({ limit: '5mb' }));
app.use(express.urlencoded({ extended: true }));
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'same-origin');
  next();
});

require('./src/socket')(io);
app.use('/api', require('./src/api')(io));
app.use(express.static(path.join(__dirname, 'public'), { extensions: ['html'] }));
app.get('*', (req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));

server.listen(PORT, '0.0.0.0', () => {
  const ips = [];
  for (const list of Object.values(os.networkInterfaces())) for (const n of list || []) if (n.family === 'IPv4' && !n.internal) ips.push(n.address);
  console.log('\n==============================================================');
  console.log('  النظام الأكاديمي الموحد - كلية علوم الحاسوب وتكنولوجيا المعلومات');
  console.log('==============================================================');
  console.log(`  قاعدة البيانات: ${db.kind}  |  Node ${process.version}`);
  console.log(`  على هذا الجهاز:   http://localhost:${PORT}`);
  for (const ip of ips) console.log(`  على الشبكة (LAN): http://${ip}:${PORT}`);
  console.log('  حساب الإدارة الافتراضي: admin / m1m2m3m4m');
  console.log('==============================================================\n');
});

process.on('uncaughtException', (e) => console.error('[خطأ غير متوقع]', e));
process.on('unhandledRejection', (e) => console.error('[خطأ غير متوقع]', e));
