// في حال نسيان كلمة مرور الإدارة: npm run reset-admin  [-- كلمة_جديدة]
// يعيد كلمة مرور حساب admin إلى m1m2m3m4m (أو الكلمة المحددة) ويفعّله
const { init, db } = require('../src/db');
const A = require('../src/auth');
init();
const pw = process.argv[2] || 'm1m2m3m4m';
const u = db.get("SELECT id FROM users WHERE username = 'admin'");
if (u) db.run("UPDATE users SET password_hash = ?, active = 1, role = 'admin' WHERE id = ?", A.hash(pw), u.id);
else db.run("INSERT INTO users (username, password_hash, role, full_name) VALUES ('admin', ?, 'admin', 'رئيس القسم')", A.hash(pw));
db.run("DELETE FROM sessions WHERE user_id = (SELECT id FROM users WHERE username = 'admin')");
console.log(`تمت إعادة تعيين حساب الإدارة: admin / ${pw}`);
