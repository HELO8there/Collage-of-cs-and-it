// بيانات تجريبية للعرض والتقديم (يمكن تحميلها من لوحة الإدارة أو بالأمر npm run seed-demo)
const path = require('path');
const fs = require('fs');
const { db, getSettings, setSetting } = require('../src/db');
const A = require('../src/auth');
const L = require('../src/logic');

const UPLOAD_DIR = path.join(__dirname, '..', 'uploads');
const DEMO_FILES = path.join(__dirname, 'demo-files');

function rng(seed) { return () => { seed = (seed * 16807) % 2147483647; return (seed - 1) / 2147483646; }; }

const FIRST = ['أحمد', 'محمد', 'علي', 'حسين', 'عمر', 'يوسف', 'زيد', 'مصطفى', 'كرار', 'سيف', 'مريم', 'زينب', 'فاطمة', 'نور', 'سارة', 'رقية', 'آية', 'هبة', 'دعاء', 'شيماء', 'إبراهيم', 'عبدالله', 'حيدر', 'ياسر', 'بنين'];
const LAST = ['عبدالرحمن', 'صالح', 'جاسم', 'حسن', 'كريم', 'خليل', 'عزيز', 'نوري', 'طه', 'إسماعيل', 'رشيد', 'ولي', 'شكور', 'قادر', 'توفيق', 'عمران'];

const FACULTY = [
  ['f.ahmed', 'أ.م.د.', 'أحمد خالد العبيدي', 'CS'], ['f.sara', 'م.د.', 'سارة محمود البياتي', 'CS'],
  ['f.omar', 'م.د.', 'عمر عادل الجبوري', 'IT'], ['f.huda', 'م.م.', 'هدى ياسين الصالحي', 'IT'],
  ['f.karim', 'أ.د.', 'كريم حسن التركماني', 'SW'], ['f.noor', 'م.د.', 'نور صباح الداوودي', 'SW'],
  ['f.ali', 'م.د.', 'علي جمال الحمداني', 'AI'], ['f.zainab', 'م.م.', 'زينب فاضل العزاوي', 'AI'],
];

const COURSES = {
  CS: { 1: ['أساسيات البرمجة', 'الرياضيات المتقطعة', 'مقدمة في علوم الحاسوب'], 2: ['هياكل البيانات', 'البرمجة الكيانية', 'نظرية الاحتسابية'], 3: ['تحليل وتصميم الخوارزميات', 'نظم التشغيل', 'قواعد البيانات'], 4: ['المترجمات', 'الحوسبة المتوازية', 'مشروع التخرج'] },
  IT: { 1: ['أساسيات تكنولوجيا المعلومات', 'البرمجة المهيكلة', 'الدوائر المنطقية'], 2: ['شبكات الحاسوب', 'نظم قواعد البيانات', 'برمجة الويب'], 3: ['أمن المعلومات', 'الشبكات اللاسلكية', 'إدارة الشبكات'], 4: ['الحوسبة السحابية', 'إنترنت الأشياء', 'مشروع التخرج'] },
  SW: { 1: ['مبادئ البرمجة', 'الرياضيات للبرمجيات', 'مقدمة هندسة البرمجيات'], 2: ['البرمجة الكيانية المتقدمة', 'تصميم واجهات المستخدم', 'هياكل البيانات'], 3: ['تطوير تطبيقات الويب', 'اختبار البرمجيات', 'إدارة المشاريع البرمجية'], 4: ['تطبيقات الهاتف المحمول', 'هندسة المتطلبات', 'مشروع التخرج'] },
  AI: { 1: ['البرمجة بلغة بايثون', 'الجبر الخطي', 'مقدمة في الذكاء الاصطناعي'], 2: ['الإحصاء والاحتمالات', 'هياكل البيانات', 'أساسيات تعلم الآلة'] },
};

function seed() {
  if (getSettings().demo_loaded === '1') return { skipped: true, message: 'البيانات التجريبية محمّلة مسبقاً' };
  const R = rng(20262027);
  const pick = (arr) => arr[Math.floor(R() * arr.length)];
  const pw = A.hash('123456');
  const depts = {};
  for (const d of db.all('SELECT * FROM departments')) depts[d.code] = d;
  const counts = { faculty: 0, students: 0, courses: 0, lectures: 0, materials: 0 };

  db.tx(() => {
    if (!db.get("SELECT id FROM users WHERE username = 'secretary'")) {
      db.run("INSERT INTO users (username, password_hash, role, full_name, phone) VALUES ('secretary', ?, 'secretary', 'سكرتارية القسم', '07700000000')", pw);
    }
    const fac = {};
    for (const [username, title, name, code] of FACULTY) {
      if (!depts[code]) continue;
      let u = db.get('SELECT id FROM users WHERE username = ?', username);
      if (!u) {
        const { lastId } = db.run(`INSERT INTO users (username, password_hash, role, full_name, academic_title, department_id, email, bio, office_hours)
          VALUES (?, ?, 'faculty', ?, ?, ?, ?, ?, ?)`, username, pw, name, title, depts[code].id, `${username.replace('f.', '')}@uokirkuk.edu.iq`,
          `تدريسي في قسم ${depts[code].name}، مهتم بالبحث العلمي والتعليم التطبيقي.`, 'الأحد والثلاثاء 10:00 - 12:00');
        u = { id: lastId }; counts.faculty++;
      }
      (fac[code] ||= []).push(u.id);
    }
    // الطلبة
    let n = 1;
    for (const [code, stages] of Object.entries(COURSES)) {
      const d = depts[code]; if (!d) continue;
      for (const stage of Object.keys(stages).map(Number)) {
        const howMany = code === 'CS' && stage === 1 ? 14 : 8;
        for (let i = 0; i < howMany; i++) {
          const study = i >= howMany - 3 ? 'evening' : 'morning';
          const username = `${code.toLowerCase()}${stage}${String(i + 1).padStart(3, '0')}`;
          if (db.get('SELECT id FROM users WHERE username = ?', username)) continue;
          db.run(`INSERT INTO users (username, password_hash, role, full_name, department_id, stage, study_type, batch)
                  VALUES (?, ?, 'student', ?, ?, ?, ?, ?)`, username, pw, `${pick(FIRST)} ${pick(FIRST)} ${pick(LAST)}`, d.id, stage, study, `${2027 - stage}-${2028 - stage}`);
          counts.students++; n++;
        }
      }
      // المواد
      for (const [stage, names] of Object.entries(stages)) {
        names.forEach((name, idx) => {
          const fid = fac[code][idx % fac[code].length];
          const { lastId: cid } = db.run(`INSERT INTO courses (name, code, department_id, stage, semester, ects, total_hours, faculty_id, formative_weight, exam_weight)
            VALUES (?, ?, ?, ?, 1, ?, ?, ?, 50, 50)`, name, `${code}${stage}0${idx + 1}`, d.id, Number(stage), name === 'مشروع التخرج' ? 8 : [5, 6, 4][idx % 3], 30, fid);
          L.defaultAssessmentItems(cid, 50);
          counts.courses++;
          const students = L.courseStudents(cid);
          const items = db.all("SELECT * FROM assessment_items WHERE course_id = ? AND kind = 'formative' ORDER BY sort", cid);
          // محاضرات وحضور
          const lectureCount = 6 + Math.floor(R() * 4);
          for (let k = 0; k < lectureCount; k++) {
            const date = new Date(2026, 9, 4 + k * 4); // تشرين الأول 2026
            const { lastId: lid } = db.run('INSERT INTO lectures (course_id, lecture_date, topic, hours, created_by) VALUES (?,?,?,?,?)',
              cid, date.toISOString().slice(0, 10), `المحاضرة ${k + 1}`, 2, fid);
            counts.lectures++;
            students.forEach((s, si) => {
              const weak = si % 7 === 3; // بعض الطلبة كثيرو الغياب لعرض الإنذار والحرمان
              const r = R();
              const status = weak ? (r < 0.35 ? 'absent' : r < 0.45 ? 'excused' : 'present') : (r < 0.07 ? 'absent' : r < 0.1 ? 'excused' : 'present');
              db.run('INSERT INTO attendance (lecture_id, student_id, status) VALUES (?,?,?)', lid, s.id, status);
            });
          }
          // درجات التقييم المستمر (السعي) - مكونات أولى فقط لتبدو كفصل جارٍ
          students.forEach((s, si) => {
            const level = 0.45 + R() * 0.55;
            items.slice(0, 3).forEach((it) => {
              db.run('INSERT INTO scores (item_id, student_id, score, updated_by) VALUES (?,?,?,?)', it.id, s.id, Math.round(it.max_score * Math.min(1, level + (R() - 0.5) * 0.2) * 2) / 2, fid);
            });
          });
          // ملازم
          const files = fs.readdirSync(DEMO_FILES).filter((f) => f.endsWith('.pdf'));
          files.slice(0, 2 + (idx % 2)).forEach((f, fi) => {
            const stored = `demo-${cid}-${fi}-${f}`;
            fs.copyFileSync(path.join(DEMO_FILES, f), path.join(UPLOAD_DIR, stored));
            const titles = { 'lecture-01-introduction.pdf': 'المحاضرة الأولى - مقدمة المادة', 'lecture-02-fundamentals.pdf': 'المحاضرة الثانية - المفاهيم الأساسية', 'lab-sheet-01.pdf': 'ورقة العمل المختبرية الأولى', 'course-syllabus.pdf': 'مفردات المادة ووصف المقرر (بولونيا)' };
            db.run(`INSERT INTO materials (course_id, title, category, stored_name, original_name, mime, size, uploaded_by) VALUES (?,?,?,?,?,?,?,?)`,
              cid, titles[f] || f, f.startsWith('lab') ? 'lab' : f.startsWith('course') ? 'syllabus' : 'lecture', stored, f, 'application/pdf', fs.statSync(path.join(DEMO_FILES, f)).size, fid);
            counts.materials++;
          });
        });
      }
    }
    // تبليغات
    const admin = db.get("SELECT id FROM users WHERE role = 'admin' ORDER BY id LIMIT 1");
    const ann = [
      ['جدول امتحانات منتصف الفصل الأول', 'تعلن إدارة القسم عن جدول امتحانات منتصف الفصل الأول للعام الدراسي 2026-2027. يرجى من جميع الطلبة الالتزام بالمواعيد والحضور قبل 15 دقيقة من بدء الامتحان.', 'exam', 'important', 'student', null, null, 1],
      ['تعليمات الغياب وفق مسار بولونيا', 'نذكّر الطلبة بأن تجاوز نسبة الغياب المحددة من ساعات المادة يؤدي إلى الحرمان. يُرجى تقديم الأعذار الرسمية إلى السكرتارية خلال 3 أيام من الغياب.', 'rules', 'urgent', 'student', null, null, 1],
      ['اجتماع مجلس القسم', 'يُعقد اجتماع مجلس القسم يوم الأحد القادم الساعة 10 صباحاً في قاعة الاجتماعات لمناقشة خطة الفصل الدراسي.', 'meeting', 'normal', 'faculty', null, null, 0],
      ['ورشة عمل: مقدمة في تعلم الآلة', `ينظم قسم الذكاء الاصطناعي ورشة عمل لطلبة المرحلة الأولى حول أساسيات تعلم الآلة.`, 'event', 'normal', 'student', depts.AI?.id, 1, 0],
      ['مباشرة الدوام الرسمي', 'تبارك عمادة الكلية للطلبة بدء العام الدراسي الجديد وتتمنى للجميع عاماً دراسياً موفقاً.', 'notice', 'normal', 'all', null, null, 0],
    ];
    for (const a of ann) db.run(`INSERT INTO announcements (title, content, category, priority, target_role, target_department_id, target_stage, pinned, author_id) VALUES (?,?,?,?,?,?,?,?,?)`, ...a, admin.id);
    // شات الدفعة ومراسلة السكرتارية
    const cs1 = db.all("SELECT id FROM users WHERE username LIKE 'cs1%' AND study_type='morning' ORDER BY id LIMIT 4");
    const room = L.batchRoom(depts.CS.id, 1, 'morning');
    const lines = ['السلام عليكم، منو عنده ملزمة المحاضرة الثانية؟', 'نزلها الدكتور على النظام، من صفحة موادي', 'شكراً، وامتحان القصير يوم الخميس صح؟', 'إي نعم، الساعة 10'];
    lines.forEach((t, i) => cs1[i % cs1.length] && db.run('INSERT INTO messages (room, sender_id, content) VALUES (?,?,?)', room, cs1[i % cs1.length].id, t));
    if (cs1[0]) {
      const sec = db.get("SELECT id FROM users WHERE username = 'secretary'");
      db.run('INSERT INTO messages (room, sender_id, content, seen) VALUES (?,?,?,1)', `dm:${cs1[0].id}`, cs1[0].id, 'مرحباً، أحتاج تأييد استمرار بالدوام، شنو المطلوب؟');
      db.run('INSERT INTO messages (room, sender_id, content, seen) VALUES (?,?,?,0)', `dm:${cs1[0].id}`, sec.id, 'أهلاً بك، راجعنا بالهوية الجامعية وصورة شخصية، ويكون جاهز خلال يومين.');
      if (cs1[1]) db.run('INSERT INTO messages (room, sender_id, content) VALUES (?,?,?)', `dm:${cs1[1].id}`, cs1[1].id, 'كلمة المرور مالتي ما تشتغل، ممكن إعادة تعيين؟');
    }
  });
  setSetting('demo_loaded', '1');
  return counts;
}

module.exports = { seed };
