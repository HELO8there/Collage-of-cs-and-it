// تحميل البيانات التجريبية: npm run seed-demo
const { init } = require('../src/db');
init();
const out = require('./demo-data').seed();
console.log('البيانات التجريبية:', out);
console.log('كلمة مرور جميع الحسابات التجريبية: 123456  (مثال طالب: cs1001 - تدريسي: f.ahmed - سكرتارية: secretary)');
